package InitialPassword;

import CommonOperation.BaseOpenBrowser;
import CommonOperation.Log;
import CommonOperation.LoginOperation;
import CommonOperation.PerformOperation;
import ElementXPath.CommonElementXpath;
import ElementXPath.InitialPasswordXpath;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.*;


public class CreatePWD04 {
    WebDriver webDriver;

    @Parameters({"url", "userName", "passWord"})
    @Test
    public void create(String url, String userName, String passWord) {
        try {
            BaseOpenBrowser baseOpenBrowser = new BaseOpenBrowser();
            webDriver = baseOpenBrowser.OpenChrome();
            LoginOperation loginUrl = new LoginOperation(webDriver, url, userName, passWord);
            Log.info("在Chrome浏览器中输入URL");
            loginUrl.GetUrl();
            Log.info("输入用户名和密码");
            loginUrl.InputUserInfoAndSubmit();
            PerformOperation performOperation = new PerformOperation(webDriver);
            Log.info("进入后台管理");
            performOperation.clickObject(CommonElementXpath.BUTTON_BACKSTAGEMANAGEMENT);
            performOperation.clickObject(CommonElementXpath.BUTTON_TACTICALMANAGEMENT);
            Thread.sleep(1000);
            Log.info("进入初始密码菜单");
            performOperation.clickObject(CommonElementXpath.BUTTON_IN_PWD);
            Log.info("点击新建按钮");
            performOperation.clickObject(InitialPasswordXpath.BUTTON_CREATE);
            performOperation.clickObject(InitialPasswordXpath.SAVE);
            Log.info("策略、分组、密码生成策略必填");
            boolean result = performOperation.IsDisplayed(InitialPasswordXpath.NAME_K);
            if (!result) {
                Assert.assertTrue(result, "策略没有必填提示");
            }
            result = performOperation.IsDisplayed(InitialPasswordXpath.GROUP);
            if (!result) {
                Assert.assertTrue(result, "分组没有必填提示");
            }
            result = performOperation.IsDisplayed(InitialPasswordXpath.PROPERTY);
            if (!result) {
                Assert.assertTrue(result, "密码生成策略没有必填提示");
            }
            baseOpenBrowser.CloseChrome();
        } catch (InterruptedException e) {
            Log.error(e.toString());
        }
    }
}
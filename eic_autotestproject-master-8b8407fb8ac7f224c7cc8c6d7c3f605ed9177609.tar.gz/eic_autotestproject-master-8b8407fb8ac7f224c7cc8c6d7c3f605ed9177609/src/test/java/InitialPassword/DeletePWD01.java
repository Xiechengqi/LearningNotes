package InitialPassword;

import Base.Case;
import CommonOperation.BaseOpenBrowser;
import CommonOperation.Log;
import CommonOperation.LoginOperation;
import CommonOperation.PerformOperation;
import ElementXPath.CommonElementXpath;
import ElementXPath.InitialPasswordXpath;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.*;


public class DeletePWD01 extends Case {
    WebDriver webDriver;

    @Parameters({"url", "userName", "passWord"})
    @Test
    public void delete(String url, String userName, String passWord) {
        try {
            BaseOpenBrowser baseOpenBrowser = new BaseOpenBrowser();
            webDriver = baseOpenBrowser.OpenChrome();
            LoginOperation loginUrl = new LoginOperation(webDriver, url, userName, passWord);
            Log.info("在Chrome浏览器中输入URL");
            loginUrl.GetUrl();
            Log.info("输入用户名和密码");
            loginUrl.InputUserInfoAndSubmit();
            PerformOperation performOperation = new PerformOperation(webDriver);
            Log.info("进入后台管理");
            performOperation.clickObject(CommonElementXpath.BUTTON_BACKSTAGEMANAGEMENT);
            performOperation.clickObject(CommonElementXpath.BUTTON_TACTICALMANAGEMENT);
            Thread.sleep(1000);
            Log.info("进入初始密码菜单");
            performOperation.clickObject(CommonElementXpath.BUTTON_IN_PWD);
            Log.info("点击新建按钮");
            performOperation.clickObject(InitialPasswordXpath.BUTTON_CREATE);
            Log.info("输入名称，备注");
            performOperation.inputObject(InitialPasswordXpath.NAME, performOperation.getStringRandom(10) + "@LN");
            performOperation.inputObject(InitialPasswordXpath.REMARK, performOperation.getStringRandom(10) + "@LN");
            Log.info("选择分组");
            performOperation.clickObject(InitialPasswordXpath.GROUP_CLASSSIFY);
            performOperation.clickObject(InitialPasswordXpath.GROUP_CLASSSIFY1);
            Log.info("选择固定生成密码");
            performOperation.clickObject(InitialPasswordXpath.FIXED_PWD);
            performOperation.inputObject(InitialPasswordXpath.PWD_INPUT, performOperation.getStringRandom(6));
            performOperation.clickObject(InitialPasswordXpath.SAVE);
            Log.info("保存成功");
            boolean result = performOperation.IsDisplayed(CommonElementXpath.CREATE_SUCCESS);
            if (!result) {
                Assert.assertTrue(result, "新建失败");
            }
            Log.info("固定密码初始密码新建成功");
            result = performOperation.IsDisplayed(InitialPasswordXpath.SELECTK);
            if (!result) {
                Assert.assertTrue(result, "策略名称不存在");
            }
            performOperation.inputObject(InitialPasswordXpath.SELECTK, "@LN");
            performOperation.clickObject(InitialPasswordXpath.SELECT);
            Thread.sleep(1000);
            performOperation.clickObject(InitialPasswordXpath.CHECK1);
            performOperation.clickObject(InitialPasswordXpath.DEL);
            performOperation.clickObject(InitialPasswordXpath.AFFIRM);
            result = performOperation.IsDisplayed(CommonElementXpath.DISABLE_SUCCESS);
            if (!result) {
                Assert.assertTrue(result, "停用失败");
            }
            Log.info("删除成功");
            baseOpenBrowser.CloseChrome();
        } catch (InterruptedException e) {
            Log.error(e.toString());
        }
    }
}
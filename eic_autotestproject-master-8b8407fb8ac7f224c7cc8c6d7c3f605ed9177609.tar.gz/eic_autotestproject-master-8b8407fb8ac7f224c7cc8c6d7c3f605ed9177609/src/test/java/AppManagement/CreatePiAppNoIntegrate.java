package AppManagement;

import Base.Case;
import CommonOperation.BaseOpenBrowser;
import CommonOperation.Log;
import ElementXPath.AppManagementXpath;
import CommonOperation.LoginOperation;
import CommonOperation.PerformOperation;
import ElementXPath.CommonElementXpath;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.*;

// 不集成
public class CreatePiAppNoIntegrate extends Case {

    WebDriver webDriver;
    BaseOpenBrowser baseOpenBrowser;
    String appName ="CreatePiAppNoIntegrateUI2020";

    @Parameters({"url","userName","passWord"})
    @Test
    public void CreatePiApp(String url, String userName, String passWord){

        try {
            baseOpenBrowser = new BaseOpenBrowser();
            webDriver = baseOpenBrowser.OpenChrome();
            LoginOperation loginUrl = new LoginOperation(webDriver, url, userName, passWord);
            Log.info("在Chrome浏览器中输入URL");
            loginUrl.GetUrl();
            Log.info("输入用户名和密码");
            loginUrl.InputUserInfoAndSubmit();

            PerformOperation performOperation = new PerformOperation(webDriver);
            Log.info("点击后台管理按钮");
            performOperation.clickObject(CommonElementXpath.BUTTON_BACKSTAGEMANAGEMENT);
            Log.info("点击应用管理按钮");
            performOperation.clickObject(CommonElementXpath.SPAN_APPMANAGEMENT);
            Log.info("点击应用配置按钮");
            performOperation.clickObject(CommonElementXpath.SPAN_APPCONFIG);

            Log.info("点击新建按钮");
            performOperation.clickObject(CommonElementXpath.BUTTON_IDM_ACTION("新建"));
            Log.info("输入应用名称和应用编码");
            performOperation.inputObject(AppManagementXpath.BUTTON_APPNAME, appName);
            performOperation.inputObject(AppManagementXpath.BUTTON_APPCODE, appName);
            Log.info("输入备注");
            performOperation.inputObject(AppManagementXpath.BUTTON_APPREMARK, "通过UI自动化创建 不集成");
            Log.info("点击CS");
            performOperation.clickObject(AppManagementXpath.BUTTON_APPRESTYPE_CS);
            Log.info("点击下一步");
            performOperation.clickObject(AppManagementXpath.BUTTON_NEXTSTEP);
            Log.info("选择二次开发接口类");
            performOperation.clickObject(AppManagementXpath.BUTTON_APICLASS);
            Log.info("选择DemoPushEntityDataServiceImpl");
            performOperation.clickObject(AppManagementXpath.BUTTON_APICLASS_SELECTAPICLASS("DemoPushEntityDataServiceImpl"));
            Log.info("点击下一步");
            performOperation.clickObject(AppManagementXpath.BUTTON_NEXTSTEP);
            Log.info("点击保存");
            performOperation.clickObject(AppManagementXpath.BUTTON_APPSAVE);
            Log.info("检查数据是否创建成功");
            Boolean isDisplay = performOperation.IsDisplayed(CommonElementXpath.CREATE_SUCCESS);
            if (!isDisplay) {
                Assert.assertTrue(isDisplay, "新建失败");
            }
            Thread.sleep(2000);
        }
        catch (InterruptedException ex){
            Log.error(ex.toString());
        }
        baseOpenBrowser.CloseChrome();
    }
}

package AppManagement;

import Base.Case;
import CommonOperation.BaseOpenBrowser;
import CommonOperation.Log;
import CommonOperation.LoginOperation;
import CommonOperation.PerformOperation;
import ElementXPath.AppManagementXpath;
import ElementXPath.CommonElementXpath;
import ElementXPath.GroupManagementXpath;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.*;

// 新建供应策略
public class CreateAccountSupply extends Case {

    WebDriver webDriver;
    BaseOpenBrowser baseOpenBrowser;
    PerformOperation performOperation ;
    String appName = "CreateAccountSupplyUI2020";
    String groupName ="CreateGroupForAccountSupply_UI2020";
    String accountSupplyName = "CreateAccountSupply_UI";

    @Test (dependsOnMethods = {"CreatePiAppForEdit"})
    public void EditPiApp() {
        try {
            Log.info("应用配置页面搜索应用名称");
            performOperation.inputObject(AppManagementXpath.INPUT_APP_SEARCH, appName);
            Log.info("点击搜索按钮");
            performOperation.clickObject(AppManagementXpath.BUTTON_APP_SEARCH("应用名称/备注/应用编码/应用地址"));
            // 点击搜索后，页面会刷新，立即点击编辑图标，会抛StaleElementReferenceException异常(element “stale”)意思是该元素已过时
            // 所以这里加上2秒等待时间
            Thread.sleep(2000);
            Log.info("点击供应策略图标");
            performOperation.clickObject(AppManagementXpath.SPAN_ACCOUNTSUPPLY);
            Log.info("点击新建供应策略");
            performOperation.clickObject(CommonElementXpath.BUTTON_IDM_ACTION("新建"));
            Log.info("输入策略名称");
            performOperation.inputObject(AppManagementXpath.BUTTON_ACCOUNTSUPPLY_POLICYNAME, accountSupplyName);
            Log.info("点击用户分组");
            performOperation.clickObject(AppManagementXpath.BUTTON_DEFAULTORACCOUNTSUPPLY_GROUP("用户分组*"));
            Log.info("选择用户分组");
            performOperation.clickObject(AppManagementXpath.BUTTON_DEFAULTORACCOUNTSUPPLY_GROUP_SELECT(groupName));
            Log.info("开启帐号同步");
            performOperation.clickObject(AppManagementXpath.BUTTON_ACCOUNTSUPPLY_SYNCONOFF("帐号同步", "开启"));
            Log.info("切换到供应策略Tab");
            performOperation.clickObject(AppManagementXpath.BUTTON_ACCOUNTSUPPLY_TAB("供应策略"));
            Log.info("开启帐号创建开关");
            performOperation.clickObject(AppManagementXpath.BUTTON_ACCOUNTSUPPLY_SYNCONOFF("帐号创建", "是"));
            Log.info("开启帐号删除开关");
            performOperation.clickObject(AppManagementXpath.BUTTON_ACCOUNTSUPPLY_SYNCONOFF("帐号删除", "是"));
            Log.info("开启帐号启用开关");
            performOperation.clickObject(AppManagementXpath.BUTTON_ACCOUNTSUPPLY_SYNCONOFF("帐号启用", "是"));
            Log.info("开启帐号停用开关");
            performOperation.clickObject(AppManagementXpath.BUTTON_ACCOUNTSUPPLY_SYNCONOFF("帐号停用", "是"));
            Log.info("开启帐号修改开关");
            performOperation.clickObject(AppManagementXpath.BUTTON_ACCOUNTSUPPLY_SYNCONOFF("帐号修改", "是"));
            Log.info("开启密码修改开关");
            performOperation.clickObject(AppManagementXpath.BUTTON_ACCOUNTSUPPLY_SYNCONOFF("密码修改", "是"));
            Log.info("点击保存");
            performOperation.clickObject(AppManagementXpath.BUTTON_ACCOUNTSUPPLY_SAVE);
            Log.info("检查供应策略是否创建成功");
            Log.info("应用配置页面搜索供应策略");
            performOperation.inputObject(AppManagementXpath.INPUT_APP_SEARCH, accountSupplyName);
            Log.info("点击搜索按钮");
            performOperation.clickObject(AppManagementXpath.BUTTON_APP_SEARCH("搜索"));
            // 点击搜索后，页面会刷新，立即点击编辑图标，会抛StaleElementReferenceException异常(element “stale”)意思是该元素已过时
            // 所以这里加上2秒等待时间
            Thread.sleep(2000);
            Boolean isDisplay = performOperation.IsDisplayed(accountSupplyName);
            if (!isDisplay) {
                Assert.assertTrue(isDisplay, "新建" + accountSupplyName + "供应策略失败");
            }
        }catch (InterruptedException e){
            Log.error(e.toString());
        }
        baseOpenBrowser.CloseChrome();
    }

    @Test (dependsOnMethods = {"CreateGroup"})
    public void CreatePiAppForEdit(){

        Log.info("点击应用管理按钮");
        performOperation.clickObject(CommonElementXpath.SPAN_APPMANAGEMENT);
        Log.info("点击应用配置按钮");
        performOperation.clickObject(CommonElementXpath.SPAN_APPCONFIG);
        Log.info("点击新建按钮");
        performOperation.clickObject(CommonElementXpath.BUTTON_IDM_ACTION("新建"));
        Log.info("输入应用名称和应用编码");
        performOperation.inputObject(AppManagementXpath.BUTTON_APPNAME, appName);
        performOperation.inputObject(AppManagementXpath.BUTTON_APPCODE, appName);
        Log.info("点击CS");
        performOperation.clickObject(AppManagementXpath.BUTTON_APPRESTYPE_CS);
        Log.info("点击下一步");
        performOperation.clickObject(AppManagementXpath.BUTTON_NEXTSTEP);
        Log.info("选择二次开发接口类");
        performOperation.clickObject(AppManagementXpath.BUTTON_APICLASS);
        Log.info("选择DemoPushEntityDataServiceImpl");
        performOperation.clickObject(AppManagementXpath.BUTTON_APICLASS_SELECTAPICLASS("DemoPushEntityDataServiceImpl"));
        Log.info("开启集成");
        performOperation.clickObject(AppManagementXpath.BUTTON_ACCINTEGRATE);
        Log.info("点击主推");
        performOperation.clickObject(AppManagementXpath.BUTTON_PUSH);
        Log.info("同步方式：api");
        performOperation.clickObject(AppManagementXpath.BUTTON_PUSHSYNCTYPE("api"));
        Log.info("api url前缀");
        performOperation.inputObject(AppManagementXpath.BUTTON_PUSHAPI_APIURL, "http://baidu.com");
        Log.info("点击下一步");
        performOperation.clickObject(AppManagementXpath.BUTTON_NEXTSTEP);
        Log.info("点击保存");
        performOperation.clickObject(AppManagementXpath.BUTTON_APPSAVE);
        Log.info("新建应用配置成功！");
    }

    @Parameters({"url", "userName", "passWord"})
    @Test
    public void CreateGroup(String url, String userName, String passWord){

        baseOpenBrowser = new BaseOpenBrowser();
        webDriver = baseOpenBrowser.OpenChrome();
        LoginOperation loginUrl = new LoginOperation(webDriver, url, userName, passWord);
        Log.info("在Chrome浏览器中输入URL");
        loginUrl.GetUrl();
        Log.info("输入用户名和密码");
        loginUrl.InputUserInfoAndSubmit();
        PerformOperation performOperation = new PerformOperation(webDriver);
        Log.info("点击后台管理按钮");
        performOperation.clickObject(CommonElementXpath.BUTTON_BACKSTAGEMANAGEMENT);
        Log.info("点击策略管理按钮");
        performOperation.clickObject(CommonElementXpath.BUTTON_TACTICALMANAGEMENT);
        Log.info("进入分组策略菜单");
        performOperation.clickObject(CommonElementXpath.BUTTON_GROUPMANAGEMENT);
        Log.info("点击新建按钮");
        performOperation.clickObject(GroupManagementXpath.BUTTON_CREATE);
        Log.info("输入名称，备注");
        performOperation.inputObject(GroupManagementXpath.GROUP_NAME, groupName);
        performOperation.inputObject(GroupManagementXpath.GROUP_REMARK, groupName);
        Log.info("选择动态分组，用户分组");
        performOperation.clickObject(GroupManagementXpath.GROUP_CLASSSIFY);
        performOperation.clickObject(GroupManagementXpath.GROUP_DYNAMIC);
        performOperation.clickObject(GroupManagementXpath.GROUP_TYPE);
        performOperation.clickObject(GroupManagementXpath.GROUP_USER);
        Log.info("点击保存");
        performOperation.clickObject(GroupManagementXpath.GROUP_SAVE);
        Log.info("新建动态岗位分组成功");
    }

}

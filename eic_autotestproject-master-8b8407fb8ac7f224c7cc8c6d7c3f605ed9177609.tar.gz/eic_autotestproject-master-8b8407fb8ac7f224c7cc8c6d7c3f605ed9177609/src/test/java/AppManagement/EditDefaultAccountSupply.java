package AppManagement;

import Base.Case;
import CommonOperation.*;
import ElementXPath.AppManagementXpath;
import ElementXPath.CommonElementXpath;
import ElementXPath.GroupManagementXpath;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.*;

import java.sql.SQLException;

public class EditDefaultAccountSupply extends Case {

    WebDriver webDriver;
    BaseOpenBrowser baseOpenBrowser;
    PerformOperation performOperation;

    @Test(dependsOnMethods = {"CreatePiAppForEdit"})
    public void EditPiApp() {
        try {
            Log.info("应用配置页面搜索应用名称");
            performOperation.inputObject(AppManagementXpath.INPUT_APP_SEARCH, "EditDefaultAccountSupplyUI2020");
            Log.info("点击搜索按钮");
            performOperation.clickObject(AppManagementXpath.BUTTON_APP_SEARCH("应用名称/备注/应用编码/应用地址"));
            // 点击搜索后，页面会刷新，立即点击编辑图标，会抛StaleElementReferenceException异常(element “stale”)意思是该元素已过时
            // 所以这里加上2秒等待时间
            Thread.sleep(2000);
            Log.info("点击供应策略图标");
            performOperation.clickObject(AppManagementXpath.SPAN_ACCOUNTSUPPLY);
            Log.info("供应策略页面搜索默认同步策略");
            performOperation.inputObject(AppManagementXpath.INPUT_APP_SEARCH, "默认同步策略");
            Log.info("点击搜索按钮");
            performOperation.clickObject(AppManagementXpath.BUTTON_APP_SEARCH("搜索"));
            // 点击搜索后，页面会刷新，立即点击编辑图标，会抛StaleElementReferenceException异常(element “stale”)意思是该元素已过时
            // 所以这里加上2秒等待时间
            Thread.sleep(2000);
            Log.info("编辑默认同步策略");
            performOperation.clickObject(AppManagementXpath.SPAN_APPEDIT);
            Log.info("关闭帐号同步");
            performOperation.clickObject(AppManagementXpath.BUTTON_ACCOUNTSUPPLY_SYNCONOFF("帐号同步", "关闭"));
            Log.info("开启组织同步");
            performOperation.clickObject(AppManagementXpath.BUTTON_ACCOUNTSUPPLY_SYNCONOFF("组织同步", "开启"));
            Log.info("开启岗位同步");
            performOperation.clickObject(AppManagementXpath.BUTTON_ACCOUNTSUPPLY_SYNCONOFF("岗位同步", "开启"));
            Log.info("关闭异动策略");
            performOperation.clickObject(AppManagementXpath.BUTTON_ACCOUNTSUPPLY_SYNCONOFF("异动策略", "关闭"));
            Log.info("切换到组织同步Tab");
            performOperation.clickObject(AppManagementXpath.BUTTON_ACCOUNTSUPPLY_TAB("组织同步策略"));
            Log.info("点击组织分组");
            performOperation.clickObject(AppManagementXpath.BUTTON_DEFAULTORACCOUNTSUPPLY_GROUP("组织分组"));
            Log.info("选择组织分组");
            performOperation.clickObject(AppManagementXpath.BUTTON_DEFAULTORACCOUNTSUPPLY_GROUP_SELECT("EditDefaultAccountSupply_UI2020"));
            Log.info("开启组织创建开关");
            performOperation.clickObject(AppManagementXpath.BUTTON_ACCOUNTSUPPLY_SYNCONOFF("组织创建", "是"));
            Log.info("开启组织删除开关");
            performOperation.clickObject(AppManagementXpath.BUTTON_ACCOUNTSUPPLY_SYNCONOFF("组织删除", "否"));
            Log.info("开启组织启用开关");
            performOperation.clickObject(AppManagementXpath.BUTTON_ACCOUNTSUPPLY_SYNCONOFF("组织启用", "是"));
            Log.info("开启组织停用开关");
            performOperation.clickObject(AppManagementXpath.BUTTON_ACCOUNTSUPPLY_SYNCONOFF("组织停用", "是"));
            Log.info("开启组织修改开关");
            performOperation.clickObject(AppManagementXpath.BUTTON_ACCOUNTSUPPLY_SYNCONOFF("组织修改", "是"));
            Log.info("切换到岗位同步Tab");
            performOperation.clickObject(AppManagementXpath.BUTTON_ACCOUNTSUPPLY_TAB("岗位同步策略"));
            Log.info("点击岗位分组");
            performOperation.clickObject(AppManagementXpath.BUTTON_DEFAULTORACCOUNTSUPPLY_GROUP("岗位分组"));
            Log.info("选择岗位分组");
            performOperation.clickObject(AppManagementXpath.BUTTON_DEFAULTORACCOUNTSUPPLY_GROUP_SELECT("EditDefaultAccountSupplyJob_UI2020"));
            Log.info("开启岗位创建开关");
            performOperation.clickObject(AppManagementXpath.BUTTON_ACCOUNTSUPPLY_SYNCONOFF("岗位创建", "开启"));
            Log.info("开启岗位删除开关");
            performOperation.clickObject(AppManagementXpath.BUTTON_ACCOUNTSUPPLY_SYNCONOFF("岗位删除", "开启"));
            Log.info("删除策略选择自定义项");
            performOperation.clickObject(AppManagementXpath.BUTTON_ACCOUNTSUPPLY_SYNCONOFF("删除策略", "自定义"));
            Log.info("点击自定义选项");
            performOperation.clickObject(AppManagementXpath.BUTTON_DEFAULTORACCOUNTSUPPLY_DELETESELF);
            Log.info("选择自定义选项");
            performOperation.clickObject(AppManagementXpath.BUTTON_DEFAULTORACCOUNTSUPPLY_GROUP_SELECT("DemoPushEntityDataServiceImpl#accountManager"));
            Log.info("开启岗位启用开关");
            performOperation.clickObject(AppManagementXpath.BUTTON_ACCOUNTSUPPLY_SYNCONOFF("岗位启用", "否"));
            Log.info("开启岗位停用开关");
            performOperation.clickObject(AppManagementXpath.BUTTON_ACCOUNTSUPPLY_SYNCONOFF("岗位停用", "否"));
            Log.info("开启岗位修改开关");
            performOperation.clickObject(AppManagementXpath.BUTTON_ACCOUNTSUPPLY_SYNCONOFF("岗位修改", "否"));
            Log.info("点击保存");
            performOperation.clickObject(AppManagementXpath.BUTTON_ACCOUNTSUPPLY_SAVE);
            boolean result = performOperation.IsDisplayed(CommonElementXpath.OPERATE_SUCCESS);
            if (!result) {
                Assert.assertTrue(result, "编辑默认同步策略失败");
            }
            Thread.sleep(3000);
        } catch (InterruptedException ex) {
            Log.error(ex.toString());
        }
        baseOpenBrowser.CloseChrome();
    }

    @Test(dependsOnMethods = {"CreateJobGroup"})
    public void CreatePiAppForEdit() {

        Log.info("点击应用管理按钮");
        performOperation.clickObject(CommonElementXpath.BUTTON_BACKSTAGEMANAGEMENT);
        Log.info("点击应用配置按钮");
        performOperation.clickObject(CommonElementXpath.SPAN_APPCONFIG);
        Log.info("点击新建按钮");
        performOperation.clickObject(CommonElementXpath.BUTTON_IDM_ACTION("新建"));
        Log.info("输入应用名称和应用编码");
        performOperation.inputObject(AppManagementXpath.BUTTON_APPNAME, "EditDefaultAccountSupplyUI2020");
        performOperation.inputObject(AppManagementXpath.BUTTON_APPCODE, "EditDefaultAccountSupplyUI2020");
        Log.info("点击CS");
        performOperation.clickObject(AppManagementXpath.BUTTON_APPRESTYPE_CS);
        Log.info("点击下一步");
        performOperation.clickObject(AppManagementXpath.BUTTON_NEXTSTEP);
        Log.info("选择二次开发接口类");
        performOperation.clickObject(AppManagementXpath.BUTTON_APICLASS);
        Log.info("选择DemoPushEntityDataServiceImpl");
        performOperation.clickObject(AppManagementXpath.BUTTON_APICLASS_SELECTAPICLASS("DemoPushEntityDataServiceImpl"));
        Log.info("开启集成");
        performOperation.clickObject(AppManagementXpath.BUTTON_ACCINTEGRATE);
        Log.info("点击主推");
        performOperation.clickObject(AppManagementXpath.BUTTON_PUSH);
        Log.info("同步方式：api");
        performOperation.clickObject(AppManagementXpath.BUTTON_PUSHSYNCTYPE("api"));
        Log.info("api url前缀");
        performOperation.inputObject(AppManagementXpath.BUTTON_PUSHAPI_APIURL, "http://baidu.com");
        Log.info("点击下一步");
        performOperation.clickObject(AppManagementXpath.BUTTON_NEXTSTEP);
        Log.info("点击保存");
        performOperation.clickObject(AppManagementXpath.BUTTON_APPSAVE);
        Log.info("新建应用配置成功！");
    }

    @Parameters({"url", "userName", "passWord"})
    @Test
    public void CreateOrgGroup(String url, String userName, String passWord) {

        baseOpenBrowser = new BaseOpenBrowser();
        webDriver = baseOpenBrowser.OpenChrome();
        LoginOperation loginUrl = new LoginOperation(webDriver, url, userName, passWord);
        Log.info("在Chrome浏览器中输入URL");
        loginUrl.GetUrl();
        Log.info("输入用户名和密码");
        loginUrl.InputUserInfoAndSubmit();
        performOperation = new PerformOperation(webDriver);
        Log.info("点击后台管理按钮");
        performOperation.clickObject(CommonElementXpath.BUTTON_BACKSTAGEMANAGEMENT);
        performOperation.clickObject(CommonElementXpath.BUTTON_TACTICALMANAGEMENT);
        Log.info("进入分组策略菜单");
        performOperation.clickObject(CommonElementXpath.BUTTON_GROUPMANAGEMENT);
        Log.info("点击新建按钮");
        performOperation.clickObject(GroupManagementXpath.BUTTON_CREATE);
        Log.info("输入名称，备注");
        performOperation.inputObject(GroupManagementXpath.GROUP_NAME, "EditDefaultAccountSupply_UI2020");
        performOperation.inputObject(GroupManagementXpath.GROUP_REMARK, "EditDefaultAccountSupply_UI2020");
        Log.info("选择动态分组，组织分组");
        performOperation.clickObject(GroupManagementXpath.GROUP_CLASSSIFY);
        performOperation.clickObject(GroupManagementXpath.GROUP_DYNAMIC);
        performOperation.clickObject(GroupManagementXpath.GROUP_TYPE);
        performOperation.clickObject(GroupManagementXpath.GROUP_ORG);
        Log.info("点击保存");
        performOperation.clickObject(GroupManagementXpath.GROUP_SAVE);
        Log.info("新建动态组织分组成功");
    }

    @Test(dependsOnMethods = {"CreateOrgGroup"})
    public void CreateJobGroup() {

        Log.info("点击新建按钮");
        performOperation.clickObject(GroupManagementXpath.BUTTON_CREATE);
        Log.info("输入名称，备注");
        performOperation.inputObject(GroupManagementXpath.GROUP_NAME, "EditDefaultAccountSupplyJob_UI2020");
        performOperation.inputObject(GroupManagementXpath.GROUP_REMARK, "EditDefaultAccountSupplyJob_UI2020");
        Log.info("选择动态分组，岗位分组");
        performOperation.clickObject(GroupManagementXpath.GROUP_CLASSSIFY);
        performOperation.clickObject(GroupManagementXpath.GROUP_DYNAMIC);
        performOperation.clickObject(GroupManagementXpath.GROUP_TYPE);
        performOperation.clickObject(GroupManagementXpath.GROUP_JOB);
        Log.info("点击保存");
        performOperation.clickObject(GroupManagementXpath.GROUP_SAVE);
        Log.info("新建动态岗位分组成功");
    }
}

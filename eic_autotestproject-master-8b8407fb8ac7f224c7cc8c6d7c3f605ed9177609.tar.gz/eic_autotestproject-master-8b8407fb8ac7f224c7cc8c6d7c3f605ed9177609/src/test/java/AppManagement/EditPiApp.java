package AppManagement;

import Base.Case;
import CommonOperation.BaseOpenBrowser;
import CommonOperation.Log;
import CommonOperation.LoginOperation;
import CommonOperation.PerformOperation;
import ElementXPath.AppManagementXpath;
import ElementXPath.CommonElementXpath;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.*;

public class EditPiApp extends Case {

    WebDriver webDriver;
    BaseOpenBrowser baseOpenBrowser;
    PerformOperation performOperation;
    String appName = "EditPiAppUI2020";

    @Parameters({"url","userName","password"})
    @Test
    public void CreatePiApp(String url, String userName, String passWord) {

        baseOpenBrowser = new BaseOpenBrowser();
        webDriver = baseOpenBrowser.OpenChrome();
        LoginOperation loginUrl = new LoginOperation(webDriver, url, userName, passWord);
        Log.info("在Chrome浏览器中输入URL");
        loginUrl.GetUrl();
        Log.info("输入用户名和密码");
        loginUrl.InputUserInfoAndSubmit();
        performOperation = new PerformOperation(webDriver);
        Log.info("点击后台管理按钮");
        performOperation.clickObject(CommonElementXpath.BUTTON_BACKSTAGEMANAGEMENT);
        Log.info("点击应用管理按钮");
        performOperation.clickObject(CommonElementXpath.SPAN_APPMANAGEMENT);
        Log.info("点击应用配置按钮");
        performOperation.clickObject(CommonElementXpath.SPAN_APPCONFIG);
        Log.info("点击新建按钮");
        performOperation.clickObject(CommonElementXpath.BUTTON_IDM_ACTION("新建"));
        Log.info("输入应用名称和应用编码");
        performOperation.inputObject(AppManagementXpath.BUTTON_APPNAME, appName);
        performOperation.inputObject(AppManagementXpath.BUTTON_APPCODE, appName);
        Log.info("输入备注");
        performOperation.inputObject(AppManagementXpath.BUTTON_APPREMARK, "编辑");
        Log.info("点击CS");
        performOperation.clickObject(AppManagementXpath.BUTTON_APPRESTYPE_CS);
        Log.info("点击下一步");
        performOperation.clickObject(AppManagementXpath.BUTTON_NEXTSTEP);
        Log.info("选择二次开发接口类");
        performOperation.clickObject(AppManagementXpath.BUTTON_APICLASS);
        Log.info("选择DemoPushEntityDataServiceImpl");
        performOperation.clickObject(AppManagementXpath.BUTTON_APICLASS_SELECTAPICLASS("DemoPushEntityDataServiceImpl"));
        Log.info("点击下一步");
        performOperation.clickObject(AppManagementXpath.BUTTON_NEXTSTEP);
        Log.info("点击保存");
        performOperation.clickObject(AppManagementXpath.BUTTON_APPSAVE);
    }

    @Test (dependsOnMethods = {"CreatePiApp"})
    public void EditPiApp() {
        try {
            Log.info("应用配置页面搜索应用名称");
            performOperation.inputObject(AppManagementXpath.INPUT_APP_SEARCH, appName);
            Log.info("点击搜索按钮");
            performOperation.clickObject(AppManagementXpath.BUTTON_APP_SEARCH("应用名称/备注/应用编码/应用地址"));
            // 点击搜索后，页面会刷新，立即点击编辑图标，会抛StaleElementReferenceException异常(element “stale”)意思是该元素已过时
            // 所以这里加上2秒等待时间
            Thread.sleep(2000);
            Log.info("点击编辑图标");
            performOperation.clickObject(AppManagementXpath.SPAN_APPEDIT);
            Log.info("点击选择负责人");
            performOperation.clickObject(AppManagementXpath.BUTTON_SELECTUSERS);
            Log.info("搜索选择的用户");
            performOperation.inputObject(AppManagementXpath.BUTTON_SELECTUSERS_SEARCHCONTENT, "quhongying");
            Log.info("点击搜索图标");
            performOperation.clickObject(AppManagementXpath.BUTTON_SELECTUSERS_SEARCH);
            Log.info("勾选搜索到的用户");
            performOperation.clickObject(AppManagementXpath.BUTTON_SELECTUSERS_SELECT);
            Log.info("保存选择负责人");
            performOperation.clickObject(AppManagementXpath.BUTTON_SELECTUSER_SAVE);
            Log.info("点击下一步");
            performOperation.clickObject(AppManagementXpath.BUTTON_NEXTSTEP);
            Log.info("开启集成");
            performOperation.clickObject(AppManagementXpath.BUTTON_ACCINTEGRATE);
            Log.info("点击主推");
            performOperation.clickObject(AppManagementXpath.BUTTON_PUSH);
            Log.info("同步方式：api");
            performOperation.clickObject(AppManagementXpath.BUTTON_PUSHSYNCTYPE("api"));
            Log.info("api url前缀");
            performOperation.inputObject(AppManagementXpath.BUTTON_PUSHAPI_APIURL, "http://baidu.com");
            Log.info("点击下一步");
            performOperation.clickObject(AppManagementXpath.BUTTON_NEXTSTEP);
            Log.info("点击保存");
            Thread.sleep(2000);
            performOperation.clickObject(AppManagementXpath.BUTTON_APPSAVE);
            Log.info("编辑应用成功！");
            Log.info("检查提示语：操作成功");
            Boolean isDisplay = performOperation.IsDisplayed(CommonElementXpath.OPERATE_SUCCESS);
            if (!isDisplay) {
                Assert.assertTrue(isDisplay, "编辑默认同步策略失败");
            }
        } catch (InterruptedException e) {
            Log.error(e.toString());
        }
    }

}

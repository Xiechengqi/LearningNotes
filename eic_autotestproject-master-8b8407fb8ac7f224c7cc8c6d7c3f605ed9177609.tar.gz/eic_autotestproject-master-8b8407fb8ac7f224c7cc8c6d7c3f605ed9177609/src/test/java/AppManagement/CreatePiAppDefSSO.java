package AppManagement;

import Base.Case;
import CommonOperation.BaseOpenBrowser;
import CommonOperation.Log;
import CommonOperation.LoginOperation;
import CommonOperation.PerformOperation;
import ElementXPath.AppManagementXpath;
import ElementXPath.CommonElementXpath;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.*;

// 单点协议：预定义
public class CreatePiAppDefSSO extends Case {

    WebDriver webDriver;
    BaseOpenBrowser baseOpenBrowser;
    String appName = "CreatePiAppDefSSOUI2020";

    @Parameters({"url", "userName", "passWord"})
    @Test
    public void CreatePiApp(String url, String userName, String passWord) {
        try {
            baseOpenBrowser = new BaseOpenBrowser();
            webDriver = baseOpenBrowser.OpenChrome();
            LoginOperation loginUrl = new LoginOperation(webDriver, url, userName, passWord);
            Log.info("在Chrome浏览器中输入URL");
            loginUrl.GetUrl();
            Log.info("输入用户名和密码");
            loginUrl.InputUserInfoAndSubmit();
            PerformOperation performOperation = new PerformOperation(webDriver);
            Log.info("点击后台管理按钮");
            performOperation.clickObject(CommonElementXpath.BUTTON_BACKSTAGEMANAGEMENT);
            Log.info("点击应用管理按钮");
            performOperation.clickObject(CommonElementXpath.SPAN_APPMANAGEMENT);
            Log.info("点击应用配置按钮");
            performOperation.clickObject(CommonElementXpath.SPAN_APPCONFIG);
            Log.info("点击新建按钮");
            performOperation.clickObject(CommonElementXpath.BUTTON_IDM_ACTION("新建"));
            Log.info("输入应用名称和应用编码");
            performOperation.inputObject(AppManagementXpath.BUTTON_APPNAME, appName);
            performOperation.inputObject(AppManagementXpath.BUTTON_APPCODE, appName);
            Log.info("输入备注");
            performOperation.inputObject(AppManagementXpath.BUTTON_APPREMARK, "通过UI自动化创建 单点协议：预定义");
            Log.info("点击CS");
            performOperation.clickObject(AppManagementXpath.BUTTON_APPRESTYPE_CS);
            Log.info("点击下一步");
            performOperation.clickObject(AppManagementXpath.BUTTON_NEXTSTEP);
            Log.info("二次开发接口类");
            performOperation.clickObject(AppManagementXpath.BUTTON_APICLASS);
            Log.info("选择DemoPushEntityDataServiceImpl");
            performOperation.clickObject(AppManagementXpath.BUTTON_APICLASS_SELECTAPICLASS("DemoPushEntityDataServiceImpl"));
            Log.info("开启集成");
            performOperation.clickObject(AppManagementXpath.BUTTON_ACCINTEGRATE);
            Log.info("点击主推");
            performOperation.clickObject(AppManagementXpath.BUTTON_PUSH);
            Log.info("同步方式：api");
            performOperation.clickObject(AppManagementXpath.BUTTON_PUSHSYNCTYPE("api"));
            Log.info("api url前缀");
            performOperation.inputObject(AppManagementXpath.BUTTON_PUSHAPI_APIURL, "http://baidu.com");
            Log.info("点击下一步");
            performOperation.clickObject(AppManagementXpath.BUTTON_NEXTSTEP);
            Log.info("单点协议：选择预定义");
            performOperation.clickObject(AppManagementXpath.BUTTON_SINGLEPROTOCOL("预定义"));
            Log.info("点击预定义协议");
            performOperation.clickObject(AppManagementXpath.BUTTON_DEFSSOTYPE);
            Log.info("选择预定义协议");
            performOperation.clickObject(AppManagementXpath.BUTTON_DEFSSOTYPE_SELECT("163邮箱"));
            Log.info("自动生成协议参数");
            Log.info("点击认证等级");
            performOperation.clickObject(AppManagementXpath.BUTTON_DEFSSO_AUTHLEVEL);
            Log.info("选择认证等级：静态密码");
            performOperation.clickObject(AppManagementXpath.BUTTON_DEFSSO_AUTHLEVEL_SELECT("静态密码"));
            Log.info("点击保存");
            performOperation.clickObject(AppManagementXpath.BUTTON_APPSAVE);
            Log.info("选择认证等级后，有选择弹框，点击保存有延时，所以加上时间等待：2s");
            Thread.sleep(2000);
            Log.info("检查数据是否创建成功");
            Log.info("应用配置页面搜索应用名称");
            performOperation.inputObject(AppManagementXpath.INPUT_APP_SEARCH, appName);
            Log.info("点击搜索按钮");
            performOperation.clickObject(AppManagementXpath.BUTTON_APP_SEARCH("应用名称/备注/应用编码/应用地址"));
            // 点击搜索后，页面会刷新，立即点击编辑图标，会抛StaleElementReferenceException异常(element “stale”)意思是该元素已过时
            // 所以这里加上2秒等待时间
            Thread.sleep(2000);
            Boolean isDisplay = performOperation.IsDisplayed(appName);
            if (!isDisplay) {
                Assert.assertTrue(isDisplay, "新建" + appName + "失败");
            }
        } catch (InterruptedException e) {
            Log.error(e.toString());
        }
        baseOpenBrowser.CloseChrome();
    }
}

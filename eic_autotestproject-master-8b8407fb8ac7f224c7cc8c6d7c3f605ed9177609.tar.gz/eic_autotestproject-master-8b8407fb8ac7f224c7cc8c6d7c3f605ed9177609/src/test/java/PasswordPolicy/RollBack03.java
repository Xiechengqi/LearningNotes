package PasswordPolicy;

import Base.Case;
import CommonOperation.BaseOpenBrowser;
import CommonOperation.Log;
import CommonOperation.LoginOperation;
import CommonOperation.PerformOperation;

import ElementXPath.CommonElementXpath;
import ElementXPath.PasswordPolicyXpath;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;

import java.awt.*;
import java.awt.event.KeyEvent;

public class RollBack03 extends Case {
    WebDriver webDriver;

    @Parameters({"url", "userName", "passWord"})
    @Test
    public void create(String url, String userName, String passWord) {
        try {
            BaseOpenBrowser baseOpenBrowser = new BaseOpenBrowser();
            webDriver = baseOpenBrowser.OpenChrome();
            LoginOperation loginUrl = new LoginOperation(webDriver, url, userName, passWord);
            Log.info("在Chrome浏览器中输入URL");
            loginUrl.GetUrl();
            Log.info("输入用户名和密码");
            loginUrl.InputUserInfoAndSubmit();
            PerformOperation performOperation = new PerformOperation(webDriver);
            Log.info("进入后台管理");
            performOperation.clickObject(CommonElementXpath.BUTTON_BACKSTAGEMANAGEMENT);
            performOperation.clickObject(CommonElementXpath.BUTTON_TACTICALMANAGEMENT);
            Thread.sleep(1000);
            Log.info("进入密码策略菜单");
            performOperation.clickObject(CommonElementXpath.BUTTON_PWD);
            performOperation.clickObject(PasswordPolicyXpath.ROLLBACK);
            performOperation.clickObject(PasswordPolicyXpath.ORG_EXECUTE);
            Log.info("选择组织");
            performOperation.clickObject(PasswordPolicyXpath.SELECT_ORG);
            performOperation.clickObject(PasswordPolicyXpath.SUBMIT);
            performOperation.IsDisplayed(PasswordPolicyXpath.SUBMIT_SUCCESS);
            Log.info("按组织执行提交成功");
            Log.info("点击执行记录");
            performOperation.clickObject(PasswordPolicyXpath.ROLLBACK);
            performOperation.clickObject(PasswordPolicyXpath.EXECUTE_RECORD);
            performOperation.clickObject(PasswordPolicyXpath.CLASSIFY_ILTRATE);
            performOperation.clickObject(PasswordPolicyXpath.FAIL);
            performOperation.clickObject(PasswordPolicyXpath.FAIL);
            performOperation.clickObject(PasswordPolicyXpath.SUCCESS);
            performOperation.clickObject(PasswordPolicyXpath.SUCCESS);
            performOperation.clickObject(PasswordPolicyXpath.SERVICE);
            performOperation.clickObject(PasswordPolicyXpath.WAIT);
            Robot robot = new Robot();
            robot.keyPress(KeyEvent.VK_ESCAPE);
            performOperation.clickObject(PasswordPolicyXpath.RETURN);
            performOperation.IsDisplayed(PasswordPolicyXpath.BUTTON_CREATE);
            Log.info("查看记录完成");
            baseOpenBrowser.CloseChrome();
        } catch (AWTException e) {
            Log.error(e.toString());
        } catch (InterruptedException ex) {
            Log.error(ex.toString());
        }
    }
}
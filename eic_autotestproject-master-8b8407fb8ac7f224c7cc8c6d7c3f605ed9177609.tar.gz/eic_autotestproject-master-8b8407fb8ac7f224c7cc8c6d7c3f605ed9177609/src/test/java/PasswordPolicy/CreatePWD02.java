package PasswordPolicy;

import Base.Case;
import CommonOperation.BaseOpenBrowser;
import CommonOperation.Log;
import CommonOperation.LoginOperation;
import CommonOperation.PerformOperation;

import ElementXPath.CommonElementXpath;
import ElementXPath.PasswordPolicyXpath;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;

public class CreatePWD02 extends Case {
    WebDriver webDriver;
    
    @Parameters({"url", "userName", "passWord"})
    @Test
    public void create(String url, String userName, String passWord) {
        try {
            BaseOpenBrowser baseOpenBrowser = new BaseOpenBrowser();
            webDriver = baseOpenBrowser.OpenChrome();
            LoginOperation loginUrl = new LoginOperation(webDriver, url, userName, passWord);
            Log.info("在Chrome浏览器中输入URL");
            loginUrl.GetUrl();
            Log.info("输入用户名和密码");
            loginUrl.InputUserInfoAndSubmit();
            PerformOperation performOperation = new PerformOperation(webDriver);
            Log.info("进入后台管理");
            performOperation.clickObject(CommonElementXpath.BUTTON_BACKSTAGEMANAGEMENT);
            performOperation.clickObject(CommonElementXpath.BUTTON_TACTICALMANAGEMENT);
            Thread.sleep(1000);
            Log.info("进入密码策略菜单");
            performOperation.clickObject(CommonElementXpath.BUTTON_PWD);
            Log.info("点击新建按钮");
            performOperation.clickObject(PasswordPolicyXpath.BUTTON_CREATE);
            performOperation.clickObject(PasswordPolicyXpath.SAVE);
            performOperation.IsDisplayed(PasswordPolicyXpath.NAME_K);
            performOperation.IsDisplayed(PasswordPolicyXpath.MUST);
            Log.info("必填校验验证成功");
            baseOpenBrowser.CloseChrome();
        } catch (InterruptedException ex) {
            Log.error(ex.toString());
        }
    }
}
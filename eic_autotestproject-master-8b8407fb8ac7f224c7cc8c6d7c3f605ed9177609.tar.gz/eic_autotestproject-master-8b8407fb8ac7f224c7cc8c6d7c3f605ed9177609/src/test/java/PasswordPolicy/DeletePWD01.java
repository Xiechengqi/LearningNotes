package PasswordPolicy;

import Base.Case;
import CommonOperation.BaseOpenBrowser;
import CommonOperation.Log;
import CommonOperation.LoginOperation;
import CommonOperation.PerformOperation;

import ElementXPath.CommonElementXpath;
import ElementXPath.InitialPasswordXpath;
import ElementXPath.PasswordPolicyXpath;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;

public class DeletePWD01 extends Case {
    WebDriver webDriver;
  
    @Parameters({"url", "userName", "passWord"})
    @Test
    public void create(String url, String userName, String passWord) {
        try {
            BaseOpenBrowser baseOpenBrowser = new BaseOpenBrowser();
            webDriver = baseOpenBrowser.OpenChrome();
            LoginOperation loginUrl = new LoginOperation(webDriver, url, userName, passWord);
            Log.info("在Chrome浏览器中输入URL");
            loginUrl.GetUrl();
            Log.info("输入用户名和密码");
            loginUrl.InputUserInfoAndSubmit();
            PerformOperation performOperation = new PerformOperation(webDriver);
            Log.info("进入后台管理");
            performOperation.clickObject(CommonElementXpath.BUTTON_BACKSTAGEMANAGEMENT);
            performOperation.clickObject(CommonElementXpath.BUTTON_TACTICALMANAGEMENT);
            Thread.sleep(1000);
            Log.info("进入密码策略菜单");
            performOperation.clickObject(CommonElementXpath.BUTTON_PWD);
        /*Log.info("点击新建按钮");
        performOperation.clickObject(PasswordStrategyXpath.BUTTON_CREATE);
        Log.info("输入名称，备注");
        performOperation.inputObject(PasswordStrategyXpath.NAME, performOperation.getStringRandom(10)+"@LN");
        performOperation.inputObject(PasswordStrategyXpath.REMARK, performOperation.getStringRandom(10)+"@LN");
        Log.info("选择分组");
        performOperation.clickObject(PasswordStrategyXpath.GROUP_CLASSSIFY);
        performOperation.clickObject(PasswordStrategyXpath.GROUP_CLASSSIFY1);
        performOperation.inputObject(PasswordStrategyXpath.MIN_LENGTH,"6");
        performOperation.inputObject(PasswordStrategyXpath.MAX_LENGTH,"16");
        performOperation.inputObject(PasswordStrategyXpath.EFF_DAY,"6");
        performOperation.inputObject(PasswordStrategyXpath.REMIND_DAY,"6");
        performOperation.inputObject(PasswordStrategyXpath.REMIND_TIME,"6");
        performOperation.inputObject(PasswordStrategyXpath.LETTER,"1");
        performOperation.inputObject(PasswordStrategyXpath.LETTER1,"1");
        performOperation.inputObject(PasswordStrategyXpath.NUMBER,"1");
        performOperation.inputObject(PasswordStrategyXpath.SPECAIL,"0");
        performOperation.inputObject(PasswordStrategyXpath.HISTORY,"1");
        performOperation.inputObject(PasswordStrategyXpath.LOCK,"1");
        performOperation.inputObject(PasswordStrategyXpath.LOCK_MINS,"1");
        performOperation.clickObject(PasswordStrategyXpath.SAVE);
        Log.info("保存成功");
        performOperation.IsDisplayed(CommonElementXpath.CREATE_SUCCESS);
        Log.info("固定密码初始密码新建成功");
        Thread.sleep(1000);
        performOperation.inputObject(PasswordStrategyXpath.SELECTK,"@LN");
        performOperation.clickObject(PasswordStrategyXpath.SELECT);
        Thread.sleep(1000);*/
            performOperation.clickObject(InitialPasswordXpath.CHECK1);
            performOperation.clickObject(InitialPasswordXpath.DEL);
            performOperation.clickObject(InitialPasswordXpath.AFFIRM);
            performOperation.IsDisplayed(CommonElementXpath.DISABLE_SUCCESS);
            Log.info("删除成功");
            baseOpenBrowser.CloseChrome();
        } catch (InterruptedException ex) {
            Log.error(ex.toString());
        }
    }
}
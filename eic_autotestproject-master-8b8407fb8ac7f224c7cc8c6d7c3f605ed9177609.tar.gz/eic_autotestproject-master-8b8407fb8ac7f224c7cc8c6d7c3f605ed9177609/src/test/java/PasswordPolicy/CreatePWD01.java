package PasswordPolicy;

import Base.Case;
import CommonOperation.BaseOpenBrowser;
import CommonOperation.Log;
import CommonOperation.LoginOperation;
import CommonOperation.PerformOperation;

import ElementXPath.CommonElementXpath;
import ElementXPath.PasswordPolicyXpath;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;

public class CreatePWD01 extends Case {
    WebDriver webDriver;
   
    @Parameters({"url", "userName", "passWord"})
    @Test
    public void create(String url, String userName, String passWord) {
        try {
            BaseOpenBrowser baseOpenBrowser = new BaseOpenBrowser();
            webDriver = baseOpenBrowser.OpenChrome();
            LoginOperation loginUrl = new LoginOperation(webDriver, url, userName, passWord);
            Log.info("在Chrome浏览器中输入URL");
            loginUrl.GetUrl();
            Log.info("输入用户名和密码");
            loginUrl.InputUserInfoAndSubmit();
            PerformOperation performOperation = new PerformOperation(webDriver);
            Log.info("进入后台管理");
            performOperation.clickObject(CommonElementXpath.BUTTON_BACKSTAGEMANAGEMENT);
            performOperation.clickObject(CommonElementXpath.BUTTON_TACTICALMANAGEMENT);
            Thread.sleep(1000);
            Log.info("进入密码策略菜单");
            performOperation.clickObject(CommonElementXpath.BUTTON_PWD);
            Log.info("点击新建按钮");
            performOperation.clickObject(PasswordPolicyXpath.BUTTON_CREATE);
            Log.info("输入名称，备注");
            performOperation.inputObject(PasswordPolicyXpath.NAME, performOperation.getStringRandom(10) + "@LN");
            performOperation.inputObject(PasswordPolicyXpath.REMARK, performOperation.getStringRandom(10) + "@LN");
            Log.info("选择分组");
            performOperation.clickObject(PasswordPolicyXpath.GROUP_CLASSSIFY);
            performOperation.clickObject(PasswordPolicyXpath.GROUP_CLASSSIFY1);
            performOperation.inputObject(PasswordPolicyXpath.MIN_LENGTH, "6");
            performOperation.inputObject(PasswordPolicyXpath.MAX_LENGTH, "16");
            performOperation.inputObject(PasswordPolicyXpath.EFF_DAY, "6");
            performOperation.inputObject(PasswordPolicyXpath.REMIND_DAY, "6");
            performOperation.inputObject(PasswordPolicyXpath.REMIND_TIME, "6");
            performOperation.inputObject(PasswordPolicyXpath.LETTER, "1");
            performOperation.inputObject(PasswordPolicyXpath.LETTER1, "1");
            performOperation.inputObject(PasswordPolicyXpath.NUMBER, "1");
            performOperation.inputObject(PasswordPolicyXpath.SPECAIL, "0");
            performOperation.inputObject(PasswordPolicyXpath.HISTORY, "1");
            performOperation.inputObject(PasswordPolicyXpath.LOCK, "1");
            performOperation.inputObject(PasswordPolicyXpath.LOCK_MINS, "1");
            performOperation.clickObject(PasswordPolicyXpath.SAVE);
            Log.info("保存成功");
            performOperation.IsDisplayed(CommonElementXpath.CREATE_SUCCESS);
            Log.info("固定密码初始密码新建成功");
            baseOpenBrowser.CloseChrome();
        } catch (InterruptedException ex) {
            Log.error(ex.toString());
        }
    }
}
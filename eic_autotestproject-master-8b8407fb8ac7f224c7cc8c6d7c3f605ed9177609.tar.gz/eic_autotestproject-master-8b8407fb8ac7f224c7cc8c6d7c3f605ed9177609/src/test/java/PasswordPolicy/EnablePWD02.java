package PasswordPolicy;

import Base.Case;
import CommonOperation.BaseOpenBrowser;
import CommonOperation.Log;
import CommonOperation.LoginOperation;
import CommonOperation.PerformOperation;

import ElementXPath.CommonElementXpath;
import ElementXPath.InitialPasswordXpath;
import ElementXPath.PasswordPolicyXpath;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;

public class EnablePWD02 extends Case {
    WebDriver webDriver;

    @Parameters({"url", "userName", "passWord"})
    @Test
    public void create(String url, String userName, String passWord) {
        try {
            BaseOpenBrowser baseOpenBrowser = new BaseOpenBrowser();
            webDriver = baseOpenBrowser.OpenChrome();
            LoginOperation loginUrl = new LoginOperation(webDriver, url, userName, passWord);
            Log.info("在Chrome浏览器中输入URL");
            loginUrl.GetUrl();
            Log.info("输入用户名和密码");
            loginUrl.InputUserInfoAndSubmit();
            PerformOperation performOperation = new PerformOperation(webDriver);
            Log.info("进入后台管理");
            performOperation.clickObject(CommonElementXpath.BUTTON_BACKSTAGEMANAGEMENT);
            performOperation.clickObject(CommonElementXpath.BUTTON_TACTICALMANAGEMENT);
            Thread.sleep(1000);
            Log.info("进入密码策略菜单");
            performOperation.clickObject(CommonElementXpath.BUTTON_PWD);
            performOperation.clickObject(InitialPasswordXpath.ALL);
            performOperation.clickObject(InitialPasswordXpath.DISABLE);
            performOperation.clickObject(InitialPasswordXpath.AFFIRM);
            performOperation.IsDisplayed(CommonElementXpath.DISABLE_SUCCESS);
            performOperation.IsDisplayed(InitialPasswordXpath.DISABLE_STATUS);
            Log.info("停用成功");
            performOperation.clickObject(InitialPasswordXpath.ALL);
            performOperation.clickObject(InitialPasswordXpath.ENABLE);
            performOperation.clickObject(InitialPasswordXpath.AFFIRM);
            performOperation.IsDisplayed(CommonElementXpath.ENABLE_SUCCESS);
            performOperation.IsDisplayed(InitialPasswordXpath.ENABLE_STATUS);
            Log.info("启用成功");
            baseOpenBrowser.CloseChrome();
        } catch (InterruptedException ex) {
            Log.error(ex.toString());
        }
    }
}
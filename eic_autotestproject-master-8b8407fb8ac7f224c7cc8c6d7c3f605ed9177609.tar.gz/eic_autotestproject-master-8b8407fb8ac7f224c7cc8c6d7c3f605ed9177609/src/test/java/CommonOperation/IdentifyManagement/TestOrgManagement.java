package CommonOperation.IdentifyManagement;

import CommonOperation.BaseOpenBrowser;
import CommonOperation.LoginOperation;
import CommonOperation.PerformOperation;
import ElementXPath.CommonElementXpath;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;


public class TestOrgManagement extends BaseOpenBrowser {
    WebDriver driver;

    @Parameters({"url", "userName", "passWord"})
    @Test
    public void LoginSystem(String url, String userName, String passWord) throws InterruptedException {

        BaseOpenBrowser baseOpenBrowser = new BaseOpenBrowser();
        this.driver = baseOpenBrowser.OpenChrome();
        this.driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

        LoginOperation loginUrl = new LoginOperation(this.driver, url, userName, passWord);

        loginUrl.GetUrl();

        loginUrl.InputUserInfoAndSubmit();

        PerformOperation performOperation = new PerformOperation(this.driver);
        performOperation.clickObject(CommonElementXpath.BUTTON_BACKSTAGEMANAGEMENT);
    }

    @Test
    public void OpenOrgMgmtPage() throws InterruptedException {

        // 后台管理页 进入 身份管理-用户分类页
        IdentifyManagementUtils utils = new IdentifyManagementUtils(this.driver);
        utils.OpenIdentifyMgmtPage(IdentifyManagementUtils.PAGE_IDENTIFY_MGMT.PAGE_ORG_MANAGEMENT);

        OrgManagementPageOperation orgMgmtOps = new OrgManagementPageOperation(this.driver);
        orgMgmtOps.OpenCreatePage();
        orgMgmtOps.CreateOrgInfo("test_test_org", "sc_name", "sc_code");
        orgMgmtOps.DisableRecord("sc_name");
        orgMgmtOps.DelRecord("sc_name");

        Thread.sleep(5000);
    }


    @AfterTest
    public void CloseChrome() {
        this.driver.close();
    }

}
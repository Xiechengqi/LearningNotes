package CommonOperation.IdentifyManagement;

import CommonOperation.BaseOpenBrowser;
import CommonOperation.LoginOperation;
import CommonOperation.PerformOperation;
import ElementXPath.CommonElementXpath;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

public class TestUserManagement extends BaseOpenBrowser {
    WebDriver driver;

    @Parameters({"url", "userName", "passWord"})
    @Test
    public void LoginSystem(String url, String userName, String passWord) throws InterruptedException {

        BaseOpenBrowser baseOpenBrowser = new BaseOpenBrowser();
        this.driver = baseOpenBrowser.OpenChrome();
        this.driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

        LoginOperation loginUrl = new LoginOperation(this.driver, url, userName, passWord);

        loginUrl.GetUrl();

        loginUrl.InputUserInfoAndSubmit();

        PerformOperation performOperation = new PerformOperation(this.driver);
        performOperation.clickObject(CommonElementXpath.BUTTON_BACKSTAGEMANAGEMENT);
    }

    @Test
    public void OpenUserMgmtPage() throws InterruptedException {

        // 后台管理页 进入 身份管理-用户分类页
        IdentifyManagementUtils utils = new IdentifyManagementUtils(this.driver);
        utils.OpenIdentifyMgmtPage(IdentifyManagementUtils.PAGE_IDENTIFY_MGMT.PAGE_USER_MANAGEMENT);


        UserManagementPageOperation userMgmtOps = new UserManagementPageOperation(this.driver);
//        userMgmtOps.OpenCreatePage();
//        userMgmtOps.CreateUserInfo("sc_uid", "sc_name");
//        userMgmtOps.OperateRecord(UserMgmtPageOperation.OPS_RECORD_STAT.OPS_RECORD_DEL,"sc_uid");
//        userMgmtOps.ResetPassword("sc_uid");
        userMgmtOps.InitPagingInfo();

        Thread.sleep(5000);
    }


    @AfterTest
    public void CloseChrome() {
        this.driver.close();
    }

}
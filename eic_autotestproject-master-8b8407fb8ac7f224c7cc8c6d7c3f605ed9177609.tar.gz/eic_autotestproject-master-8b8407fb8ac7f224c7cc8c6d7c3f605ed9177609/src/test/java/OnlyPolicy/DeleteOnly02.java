package OnlyPolicy;

import Base.Case;
import CommonOperation.BaseOpenBrowser;
import CommonOperation.Log;
import CommonOperation.LoginOperation;
import CommonOperation.PerformOperation;
import ElementXPath.CommonElementXpath;
import ElementXPath.OnlyPolicyXpath;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.*;

import java.awt.*;
import java.awt.event.KeyEvent;


public class DeleteOnly02 extends Case {
    WebDriver webDriver;

    @Parameters({"url", "userName", "passWord"})
    @Test
    public void create(String url, String userName, String passWord) {

        try {
            BaseOpenBrowser baseOpenBrowser = new BaseOpenBrowser();
            webDriver = baseOpenBrowser.OpenChrome();
            LoginOperation loginUrl = new LoginOperation(webDriver, url, userName, passWord);
            Log.info("在Chrome浏览器中输入URL");
            loginUrl.GetUrl();
            Log.info("输入用户名和密码");
            loginUrl.InputUserInfoAndSubmit();
            PerformOperation performOperation = new PerformOperation(webDriver);
            Log.info("进入后台管理");
            performOperation.clickObject(CommonElementXpath.BUTTON_BACKSTAGEMANAGEMENT);
            performOperation.clickObject(CommonElementXpath.BUTTON_TACTICALMANAGEMENT);
            boolean result = performOperation.IsDisplayed(CommonElementXpath.BUTTON_ONLY);
            if (!result) {
                Assert.assertTrue(result, "进入唯一策略菜单失败");
            } else {
                Log.info("进入唯一策略菜单");
            }
            performOperation.clickObject(CommonElementXpath.BUTTON_ONLY);
            Log.info("点击新建按钮");
            performOperation.clickObject(OnlyPolicyXpath.BUTTON_CREATE);
            Log.info("输入名称，备注");
            performOperation.inputObject(OnlyPolicyXpath.ONLY_NAME, performOperation.getStringRandom(10) + "@LNDL");
            performOperation.inputObject(OnlyPolicyXpath.ONLY_REMARK, performOperation.getStringRandom(10) + "@LNDL");
            Log.info("选择用户分组");
            performOperation.clickObject(OnlyPolicyXpath.GROUP_CLASSSIFY);
            performOperation.clickObject(OnlyPolicyXpath.GROUP_CLASSSIFY1);
            Log.info("选择属性");
            performOperation.clickObject(OnlyPolicyXpath.PROPERTY);
            performOperation.clickObject(OnlyPolicyXpath.PROPERTY_NAME);
            Robot robot = new Robot();
            robot.keyPress(KeyEvent.VK_ESCAPE);
            Log.info("点击追加");
            performOperation.clickObject(OnlyPolicyXpath.PROPERTY_ADD);
            performOperation.clickObject(OnlyPolicyXpath.PROPERTY_SAVE);
            Log.info("新建唯一策略成功");
            result = performOperation.IsDisplayed(OnlyPolicyXpath.ONLY_SELECTK);
            if (!result) {
                Assert.assertTrue(result, "必填校验失败");
            }
            performOperation.inputObject(OnlyPolicyXpath.ONLY_SELECTK, "@LNDL");
            performOperation.clickObject(OnlyPolicyXpath.ONLY_SELECT);
            Thread.sleep(1000);
            performOperation.clickObject(OnlyPolicyXpath.ALL);
            Log.info("点击删除");
            performOperation.clickObject(OnlyPolicyXpath.ONLY_DEL);
            performOperation.clickObject(OnlyPolicyXpath.ONLY_AFFIRM);
            result = performOperation.IsDisplayed(CommonElementXpath.DELETE_SUCCESS);
            if (!result) {
                Assert.assertTrue(result, "删除失败");
            }
            else {
                Log.info("删除成功");
            }
            baseOpenBrowser.CloseChrome();
        }
        catch (AWTException e){
            Log.error(e.toString());
        }
        catch (InterruptedException ex){
            Log.error(ex.toString());
        }
    }
}
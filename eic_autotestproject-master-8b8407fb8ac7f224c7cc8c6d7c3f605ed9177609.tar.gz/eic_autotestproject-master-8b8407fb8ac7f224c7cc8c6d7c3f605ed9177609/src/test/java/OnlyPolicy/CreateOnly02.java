package OnlyPolicy;

import Base.Case;
import CommonOperation.BaseOpenBrowser;
import CommonOperation.Log;
import CommonOperation.LoginOperation;
import CommonOperation.PerformOperation;
import ElementXPath.CommonElementXpath;
import ElementXPath.OnlyPolicyXpath;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.*;


public class CreateOnly02 extends Case {
    WebDriver webDriver;

    @Parameters({"url", "userName", "passWord"})
    @Test
    public void create(String url, String userName, String passWord) {

        BaseOpenBrowser baseOpenBrowser = new BaseOpenBrowser();
        webDriver = baseOpenBrowser.OpenChrome();
        LoginOperation loginUrl = new LoginOperation(webDriver, url, userName, passWord);
        Log.info("在Chrome浏览器中输入URL");
        loginUrl.GetUrl();
        Log.info("输入用户名和密码");
        loginUrl.InputUserInfoAndSubmit();
        PerformOperation performOperation = new PerformOperation(webDriver);
        System.out.println("进入后台管理");
        performOperation.clickObject(CommonElementXpath.BUTTON_BACKSTAGEMANAGEMENT);
        performOperation.clickObject(CommonElementXpath.BUTTON_TACTICALMANAGEMENT);
        boolean result = performOperation.IsDisplayed(CommonElementXpath.BUTTON_ONLY);
        if (!result) {
            Assert.assertTrue(result, "进入唯一策略菜单失败");
        } else {
            System.out.println("进入唯一策略菜单");
        }
        performOperation.clickObject(CommonElementXpath.BUTTON_ONLY);
        System.out.println("点击新建按钮");
        performOperation.clickObject(OnlyPolicyXpath.BUTTON_CREATE);
        performOperation.clickObject(OnlyPolicyXpath.PROPERTY_SAVE);
        System.out.println("名称，分组，已选属性为必填校验成功");
        result = performOperation.IsDisplayed(OnlyPolicyXpath.ONLY_NAME_K);
        if (!result) {
            Assert.assertTrue(result, "名称必填校验失败");
        }
        result = performOperation.IsDisplayed(OnlyPolicyXpath.ONLY_GROUP);
        if (!result) {
            Assert.assertTrue(result, "分组必填校验失败");
        }
        result = performOperation.IsDisplayed(OnlyPolicyXpath.ONLY_PROPERTY);
        if (!result) {
            Assert.assertTrue(result, "已选属性必填校验失败");
        }
        baseOpenBrowser.CloseChrome();
    }
}
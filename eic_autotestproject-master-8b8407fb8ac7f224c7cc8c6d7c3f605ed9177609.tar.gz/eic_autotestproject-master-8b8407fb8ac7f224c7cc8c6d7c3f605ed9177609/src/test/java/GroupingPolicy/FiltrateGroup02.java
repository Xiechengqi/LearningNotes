package GroupingPolicy;

import Base.Case;
import CommonOperation.BaseOpenBrowser;
import CommonOperation.Log;
import CommonOperation.LoginOperation;
import CommonOperation.PerformOperation;
import ElementXPath.CommonElementXpath;
import ElementXPath.GroupManagementXpath;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.*;

public class FiltrateGroup02 extends Case {
    WebDriver webDriver;

    @Parameters({"url", "userName", "passWord"})
    @Test
    public void filtrateGroup(String url, String userName, String passWord) {

        BaseOpenBrowser baseOpenBrowser = new BaseOpenBrowser();
        webDriver = baseOpenBrowser.OpenChrome();
        LoginOperation loginUrl = new LoginOperation(webDriver, url, userName, passWord);
        Log.info("在Chrome浏览器中输入URL");
        loginUrl.GetUrl();
        Log.info("输入用户名和密码");
        loginUrl.InputUserInfoAndSubmit();
        PerformOperation performOperation = new PerformOperation(webDriver);
        Log.info("进入后台管理");
        performOperation.clickObject(CommonElementXpath.BUTTON_BACKSTAGEMANAGEMENT);
        performOperation.clickObject(CommonElementXpath.BUTTON_TACTICALMANAGEMENT);
        Log.info("进入分组策略菜单");
        performOperation.clickObject(CommonElementXpath.BUTTON_GROUPMANAGEMENT);
        performOperation.clickObject(GroupManagementXpath.CLASSIFY_ILTRATE);
        Log.info("点击静态分组");
        performOperation.clickObject(GroupManagementXpath.GROUP_STATIC_F);
        boolean result = performOperation.IsDisplayed(GroupManagementXpath.GROUP_STATIC_F1);
        if (!result) {
            Assert.assertTrue(result, "静态分组过滤失败");
        }
        else {
            Log.info("静态分组过滤成功");
        }
        performOperation.clickObject(GroupManagementXpath.GROUP_STATIC_F);
        Log.info("点击动态分组");
        performOperation.clickObject(GroupManagementXpath.GROUP_DYNAMIC_F);
        result = performOperation.IsDisplayed(GroupManagementXpath.GROUP_DYNAMIC_F1);
        if (!result) {
            Assert.assertTrue(result, "动态分组过滤失败");
        }
        else {
            Log.info("动态分组过滤成功");
        }
        baseOpenBrowser.CloseChrome();
    }
}
package GroupingPolicy;

import Base.Case;
import CommonOperation.BaseOpenBrowser;
import CommonOperation.Log;
import CommonOperation.LoginOperation;
import CommonOperation.PerformOperation;
import ElementXPath.CommonElementXpath;
import ElementXPath.GroupManagementXpath;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.*;

public class EditGroup02 extends Case {
    WebDriver webDriver;

    @Parameters({"url", "userName", "passWord"})
    @Test
    public void editGroup(String url, String userName, String passWord) {

        try {
            BaseOpenBrowser baseOpenBrowser = new BaseOpenBrowser();
            webDriver = baseOpenBrowser.OpenChrome();
            LoginOperation loginUrl = new LoginOperation(webDriver, url, userName, passWord);
            Log.info("在Chrome浏览器中输入URL");
            loginUrl.GetUrl();
            Log.info("输入用户名和密码");
            loginUrl.InputUserInfoAndSubmit();
            PerformOperation performOperation = new PerformOperation(webDriver);
            Log.info("进入后台管理");
            performOperation.clickObject(CommonElementXpath.BUTTON_BACKSTAGEMANAGEMENT);
            performOperation.clickObject(CommonElementXpath.BUTTON_TACTICALMANAGEMENT);
            Log.info("进入分组策略菜单");
            performOperation.clickObject(CommonElementXpath.BUTTON_GROUPMANAGEMENT);
            Log.info("点击新建按钮");
            performOperation.clickObject(GroupManagementXpath.BUTTON_CREATE);
            Log.info("输入名称，备注");
            performOperation.inputObject(GroupManagementXpath.GROUP_NAME, performOperation.getStringRandom(10) + "@LND");
            performOperation.inputObject(GroupManagementXpath.GROUP_REMARK, performOperation.getStringRandom(10) + "@LND");
            Log.info("选择动态分组，用户分组");
            performOperation.clickObject(GroupManagementXpath.GROUP_CLASSSIFY);
            performOperation.clickObject(GroupManagementXpath.GROUP_DYNAMIC);
            performOperation.clickObject(GroupManagementXpath.GROUP_TYPE);
            performOperation.clickObject(GroupManagementXpath.GROUP_USER);
            Log.info("点击保存");
            performOperation.clickObject(GroupManagementXpath.GROUP_SAVE);
            Log.info("新建动态用户分组成功");
            Thread.sleep(1000);
            performOperation.inputObject(GroupManagementXpath.GROUP_SELECTK, "@LND");
            performOperation.clickObject(GroupManagementXpath.GROUP_SELECT);
            Log.info("点击编辑");
            Thread.sleep(1000);
            performOperation.clickObject(GroupManagementXpath.GROUP_EDIT);
            Log.info("加入动态表达式");
            performOperation.clickObject(GroupManagementXpath.GROUP_OR);
            performOperation.clickObject(GroupManagementXpath.GROUP_PROPERTY_C);
            performOperation.clickObject(GroupManagementXpath.GROUP_IDT_USER);
            performOperation.clickObject(GroupManagementXpath.GROUP_PROPERTY);
            performOperation.clickObject(GroupManagementXpath.GROUP_UID);
            performOperation.clickObject(GroupManagementXpath.GROUP_OPERA);
            performOperation.clickObject(GroupManagementXpath.GROUP_EQUALS);
            performOperation.inputObject(GroupManagementXpath.GROUP_VALUE, "LPP");
            performOperation.clickObject(GroupManagementXpath.GROUP_ADD);
            performOperation.clickObject(GroupManagementXpath.GROUP_SAVE_D);
            Log.info("动态表达式保存成功");
            Log.info("编辑成功");
            boolean result = performOperation.IsDisplayed(CommonElementXpath.EDIT_SUCCESS);
            if (!result) {
                Assert.assertTrue(result, "编辑分组失败");
            }

            baseOpenBrowser.CloseChrome();
        } catch (InterruptedException e) {
            Log.error(e.toString());
        }
    }
}
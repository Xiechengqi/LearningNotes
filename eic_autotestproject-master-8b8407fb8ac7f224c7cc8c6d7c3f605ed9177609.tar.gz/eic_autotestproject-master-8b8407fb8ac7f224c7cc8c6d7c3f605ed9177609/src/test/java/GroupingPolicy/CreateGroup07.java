package GroupingPolicy;

import Base.Case;
import CommonOperation.BaseOpenBrowser;
import CommonOperation.Log;
import CommonOperation.LoginOperation;
import CommonOperation.PerformOperation;
import ElementXPath.CommonElementXpath;
import ElementXPath.GroupManagementXpath;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.*;

public class CreateGroup07 extends Case {

    WebDriver webDriver;

    @Parameters({"url", "userName", "passWord"})
    @Test
    public void createGroup07(String url, String userName, String passWord) {

        BaseOpenBrowser baseOpenBrowser = new BaseOpenBrowser();
        webDriver = baseOpenBrowser.OpenChrome();
        LoginOperation loginUrl = new LoginOperation(webDriver, url, userName, passWord);
        Log.info("在Chrome浏览器中输入URL");
        loginUrl.GetUrl();
        Log.info("输入用户名和密码");
        loginUrl.InputUserInfoAndSubmit();
        PerformOperation performOperation = new PerformOperation(webDriver);
        Log.info("进入后台管理");
        performOperation.clickObject(CommonElementXpath.BUTTON_BACKSTAGEMANAGEMENT);
        performOperation.clickObject(CommonElementXpath.BUTTON_TACTICALMANAGEMENT);
        Log.info("进入分组策略菜单");
        performOperation.clickObject(CommonElementXpath.BUTTON_GROUPMANAGEMENT);
        Log.info("点击新建按钮");
        performOperation.clickObject(GroupManagementXpath.BUTTON_CREATE);
        Log.info("点击保存");
        performOperation.clickObject(GroupManagementXpath.GROUP_SAVE);
        Log.info("检查必填");
        boolean result = performOperation.IsDisplayed(GroupManagementXpath.GROUP_CREATEINFO);
        if (!result) {
            Assert.assertTrue(result, "名称没有提示必填");
        }
        boolean result1 = performOperation.IsDisplayed(GroupManagementXpath.GROUP_CLASSSIFYINFO);
        if (!result1) {
            Assert.assertTrue(result, "分类没有提示必填");
        }
        boolean result2 = performOperation.IsDisplayed(GroupManagementXpath.GROUP_TYPEINFO);
        if (!result2) {
            Assert.assertTrue(result, "类型没有提示必填");
        }
        baseOpenBrowser.CloseChrome();
    }
}
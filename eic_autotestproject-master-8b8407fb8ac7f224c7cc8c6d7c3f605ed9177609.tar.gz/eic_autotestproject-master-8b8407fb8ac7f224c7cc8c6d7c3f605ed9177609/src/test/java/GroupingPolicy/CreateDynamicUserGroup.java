package GroupingPolicy;

import Base.Case;
import CommonOperation.BaseOpenBrowser;
import CommonOperation.Log;
import CommonOperation.LoginOperation;
import CommonOperation.PerformOperation;
import ElementXPath.CommonElementXpath;
import ElementXPath.GroupManagementXpath;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.*;

public class CreateDynamicUserGroup extends Case {
    WebDriver webDriver;

    @Parameters({"url", "userName", "passWord"})
    @Test
    public void createGroup03(String url, String userName, String passWord) {

        BaseOpenBrowser baseOpenBrowser = new BaseOpenBrowser();
        webDriver = baseOpenBrowser.OpenChrome();
        LoginOperation loginUrl = new LoginOperation(webDriver, url, userName, passWord);
        Log.info("在Chrome浏览器中输入URL");
        loginUrl.GetUrl();
        Log.info("输入用户名和密码");
        loginUrl.InputUserInfoAndSubmit();
        PerformOperation performOperation = new PerformOperation(webDriver);
        Log.info("进入后台管理");
        performOperation.clickObject(CommonElementXpath.BUTTON_BACKSTAGEMANAGEMENT);
        performOperation.clickObject(CommonElementXpath.BUTTON_TACTICALMANAGEMENT);
        Log.info("进入分组策略菜单");
        performOperation.clickObject(CommonElementXpath.BUTTON_GROUPMANAGEMENT);
        Log.info("点击新建按钮");
        performOperation.clickObject(GroupManagementXpath.BUTTON_CREATE);
        Log.info("输入名称，备注");
        performOperation.inputObject(GroupManagementXpath.GROUP_NAME, performOperation.getStringRandom(10)+"@LND");
        performOperation.inputObject(GroupManagementXpath.GROUP_REMARK, performOperation.getStringRandom(10)+"@LND");
        Log.info("选择动态分组，用户分组");
        performOperation.clickObject(GroupManagementXpath.GROUP_CLASSSIFY);
        performOperation.clickObject(GroupManagementXpath.GROUP_DYNAMIC);
        performOperation.clickObject(GroupManagementXpath.GROUP_TYPE);
        performOperation.clickObject(GroupManagementXpath.GROUP_USER);
        Log.info("点击保存");
        performOperation.clickObject(GroupManagementXpath.GROUP_SAVE);
        Log.info("新建动态用户分组成功");
        Log.info("新建动态组织分组成功"); boolean result = performOperation.IsDisplayed(CommonElementXpath.CREATE_SUCCESS);
        if (!result) {
            Assert.assertTrue(result, "创建动态组织分组失败");
        }
        baseOpenBrowser.CloseChrome();
    }
}
package SyncPolicy;

import Base.Case;
import CommonOperation.BaseOpenBrowser;
import CommonOperation.Log;
import CommonOperation.LoginOperation;
import CommonOperation.PerformOperation;

import ElementXPath.CommonElementXpath;
import ElementXPath.SyncPolicyXpath;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;

import java.awt.*;
import java.awt.event.KeyEvent;

public class SyncRecord01 extends Case {
    WebDriver webDriver;

    @Parameters({"url", "userName", "passWord"})
    @Test
    public void SyncRecord(String url, String userName, String passWord) {
        try {
            BaseOpenBrowser baseOpenBrowser = new BaseOpenBrowser();
            webDriver = baseOpenBrowser.OpenChrome();
            LoginOperation loginUrl = new LoginOperation(webDriver, url, userName, passWord);
            Log.info("在Chrome浏览器中输入URL");
            loginUrl.GetUrl();
            Log.info("输入用户名和密码");
            loginUrl.InputUserInfoAndSubmit();
            PerformOperation performOperation = new PerformOperation(webDriver);
            Log.info("进入后台管理");
            performOperation.clickObject(CommonElementXpath.BUTTON_BACKSTAGEMANAGEMENT);
            performOperation.clickObject(CommonElementXpath.BUTTON_TACTICALMANAGEMENT);
            performOperation.IsDisplayed(CommonElementXpath.BUTTON_SYNC);
            Log.info("进入同步策略菜单");
            performOperation.clickObject(CommonElementXpath.BUTTON_SYNC);
            Thread.sleep(1000);
            Log.info("点击同步详情");
            performOperation.clickObject(SyncPolicyXpath.RECORD);
            performOperation.clickObject(SyncPolicyXpath.RESULT);
            performOperation.clickObject(SyncPolicyXpath.SUCCESS);
            performOperation.clickObject(SyncPolicyXpath.SUCCESS);
            performOperation.clickObject(SyncPolicyXpath.FAIL);
            performOperation.clickObject(SyncPolicyXpath.FAIL);
            performOperation.clickObject(SyncPolicyXpath.EXECUTE);
            performOperation.clickObject(SyncPolicyXpath.EXECUTE);
            Robot robot = new Robot();
            robot.keyPress(KeyEvent.VK_ESCAPE);
            Log.info("点击返回");
            performOperation.clickObject(SyncPolicyXpath.RETURN);
            performOperation.IsDisplayed(SyncPolicyXpath.BUTTON_CREATE);
            Log.info("返回成功");
            baseOpenBrowser.CloseChrome();
        } catch (AWTException e) {
            Log.error(e.toString());
        } catch (InterruptedException ex) {
            Log.error(ex.toString());
        }
    }
}
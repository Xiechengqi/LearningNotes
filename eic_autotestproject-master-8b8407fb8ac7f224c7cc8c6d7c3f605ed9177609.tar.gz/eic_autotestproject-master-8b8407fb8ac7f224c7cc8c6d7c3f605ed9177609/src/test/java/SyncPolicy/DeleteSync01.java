package SyncPolicy;

import Base.Case;
import CommonOperation.BaseOpenBrowser;
import CommonOperation.Log;
import CommonOperation.LoginOperation;
import CommonOperation.PerformOperation;

import ElementXPath.CommonElementXpath;
import ElementXPath.SyncPolicyXpath;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;

public class DeleteSync01 extends Case {
    WebDriver webDriver;

    @Parameters({"url", "userName", "passWord"})
    @Test
    public void create(String url, String userName, String passWord) {

        BaseOpenBrowser baseOpenBrowser = new BaseOpenBrowser();
        webDriver = baseOpenBrowser.OpenChrome();
        LoginOperation loginUrl = new LoginOperation(webDriver, url, userName, passWord);
        Log.info("在Chrome浏览器中输入URL");
        loginUrl.GetUrl();
        Log.info("输入用户名和密码");
        loginUrl.InputUserInfoAndSubmit();
        PerformOperation performOperation = new PerformOperation(webDriver);
        Log.info("进入后台管理");
        performOperation.clickObject(CommonElementXpath.BUTTON_BACKSTAGEMANAGEMENT);
        performOperation.clickObject(CommonElementXpath.BUTTON_TACTICALMANAGEMENT);
        performOperation.IsDisplayed(CommonElementXpath.BUTTON_SYNC);
        Log.info("进入同步策略菜单");
        performOperation.clickObject(CommonElementXpath.BUTTON_SYNC);
        Log.info("点击新建按钮");
        performOperation.clickObject(SyncPolicyXpath.BUTTON_CREATE);
        Log.info("输入名称，备注");
        performOperation.inputObject(SyncPolicyXpath.SYNC_NAME, performOperation.getStringRandom(10)+"@LN");
        performOperation.inputObject(SyncPolicyXpath.SYNC_REMARK, performOperation.getStringRandom(10)+"@LN");
        Log.info("选择同步方式为LDAP");
        performOperation.clickObject(SyncPolicyXpath.LDAP);
        Log.info("选择处理类");
        performOperation.clickObject(SyncPolicyXpath.DISPOSE);
        performOperation.clickObject(SyncPolicyXpath.BPM);
        Log.info("输入IP");
        performOperation.inputObject(SyncPolicyXpath.IP,"1");
        performOperation.inputObject(SyncPolicyXpath.PORT,"1");
        performOperation.inputObject(SyncPolicyXpath.BaseDN,performOperation.getStringRandom(5));
        performOperation.inputObject(SyncPolicyXpath.USER_NAME,performOperation.getStringRandom(10));
        performOperation.inputObject(SyncPolicyXpath.PWD,performOperation.getStringRandom(10));
        performOperation.clickObject(SyncPolicyXpath.SYNC_SAVE);
        Log.info("新建同步方式为LDAP策略成功");
        performOperation.IsDisplayed(SyncPolicyXpath.SYNC_SELECTK);
        performOperation.inputObject(SyncPolicyXpath.SYNC_SELECTK,"@LNDB");
        performOperation.clickObject(SyncPolicyXpath.SYNC_SELECT);
        performOperation.clickObject(SyncPolicyXpath.GROUP_CHECK1);
        Log.info("点击删除");
        performOperation.clickObject(SyncPolicyXpath.SYNC_DEL);
        performOperation.clickObject(SyncPolicyXpath.SYNC_AFFIRM);
        performOperation.IsDisplayed(CommonElementXpath.DELETE_SUCCESS);
        Log.info("删除成功");
        baseOpenBrowser.CloseChrome();
    }
}
package Base;

import CommonOperation.DeleteData;
import CommonOperation.Log;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import java.sql.SQLException;

public class DeleteAllDatas extends Case{

    @Test
    public void DeleteData() throws SQLException {
        Log.info("删除应用管理下%UI2020%的数据");
        DeleteData.DeleteDataForSql("pi_app", "%UI2020%");
        DeleteData.DeleteDataForSql("policy_group", "%UI2020%");
        DeleteData.DeleteDataForSql("policy_group", "%@LNJ%");
        DeleteData.DeleteDataForSql("policy_group", "%@LND%");
        DeleteData.DeleteDataForSql("policy_group", "%@LN%");
    }
}

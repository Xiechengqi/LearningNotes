package Base;

import CommonOperation.BaseOpenBrowser;
import CommonOperation.Log;
import CommonOperation.LoginOperation;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

public class Case extends BaseOpenBrowser {
    String className = Thread.currentThread().getStackTrace()[2].getClassName();

    @BeforeClass
    public void LogStart() {
        Log.startTestCase(className);
    }

    @AfterClass
    public void LogEnd() {
        Log.endTestCase(className);
    }
}

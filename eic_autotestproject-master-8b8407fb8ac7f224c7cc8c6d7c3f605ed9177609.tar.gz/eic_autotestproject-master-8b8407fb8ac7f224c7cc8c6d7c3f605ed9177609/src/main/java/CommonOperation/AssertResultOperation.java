package CommonOperation;

import org.testng.Assert;

public class AssertResultOperation{
    String ActualResult;
    String ExpectedResult;
    String Message;

    /**
     * 构造函数
     * @param actualRe：实际结果
     * @param expectedRe：期望结果
     */
    public AssertResultOperation(String actualRe, String expectedRe){
        this.ActualResult = actualRe;
        this.ExpectedResult = expectedRe;
    }

    /**
     * 构造函数
     * @param actualRe
     * @param expectedRe
     * @param message
     */
    public AssertResultOperation(String actualRe, String expectedRe,String message){
        this.ActualResult = actualRe;
        this.ExpectedResult = expectedRe;
        this.Message = message;
    }

    /**
     * 判断实际结果和期望结果是否相等
     */
    public void AssertEqualsResult(){
        Assert.assertEquals(this.ActualResult,this.ExpectedResult);

    }

}
package CommonOperation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import java.util.Random;

public class PerformOperation {

    FindElement findElement;

    public PerformOperation(WebDriver webDriver) {
        findElement = new FindElement(webDriver);
    }

    /**
     * 对于指定控件进行点击操作
     *
     * @param buttonName：控件的XPath值
     */
    public void clickObject(By buttonName) {
        WebElement element = findElement.findElement(buttonName);
        if (element != null) {
            element.click();
        } else {
            Log.error("没有获取到元素：" + buttonName);
            Assert.assertNotNull(element, "没有获取到");
        }
    }

    /**
     * 对于指定控件进行输入指定值操作
     *
     * @param buttonName：控件的XPath值
     * @param value：输入的值
     */
    public void inputObject(By buttonName, String value) {

        WebElement element = findElement.findElement(buttonName);
        if (element != null) {
            element.sendKeys(value);
        } else {
            Log.error("没有获取到元素：" + buttonName);
            Assert.assertNotNull(element, "没有获取到");
        }
    }

    /**
     * 检查必填项的提示语是否出现
     *
     * @param value：提示语控件的XPath路径
     * @return
     */
    public boolean IsDisplayed(By value) {
        Boolean isDisplay = false;

        WebElement element = findElement.waitTipsAppear(value);
        if (element != null && element.isDisplayed()) {
            isDisplay = true;
        }
        else {
            Log.error(value + "没有出现");
        }

        return isDisplay;
    }

    /**
     * 获取显示的内容
     * 譬如页面调整到显示100条数据时，检查页面显示的条数
     * @param by
     * @return
     */
    public String getTexts(By by) {
        findElement.waitTipsAppear(by);
        return findElement.webDriver.findElement(by).getText();
    }

    /**
     * 查找页面上某个内容是否出现
     * 譬如：新建数据成功后，会出现"新建成功"字样
     *
     * @param name：页面上显示的控件名。例如：新建成功
     * @return
     */
    public boolean IsDisplayed(String name) {
        Boolean isDisplay = false;

        WebElement element = findElement.findElement(By.xpath("//span[text()='" + name + "']"));
        if (element != null && element.isDisplayed()) {
            isDisplay = true;
        }
        else {
            Log.error(name + "没有出现");
        }

        return isDisplay;
    }

    /**
     * 生成随机数字
     * @param length：长度
     * @return
     */
    public static long getNumRandom(int length) {
        int num = 0;
        num = (int) (Math.random() * Math.pow(10, length));
        return num;
    }

    /**
     * 生成最小值与最大值之间的随机数
     * @param min：最小值
     * @param max：最大值
     * @return
     */
    public static long getNumRandom(int min, int max) {
        int num = 0;
        Random random = new Random();
        num = random.nextInt(max - min + 1) + min;
        return num;
    }

    /**
     * 生成随机字母数字
     *
     * @param length：长度
     * @return
     */
    public static String getStringRandom(int length) {
        String val = "";
        Random random = new Random();
        for (int i = 0; i < length; i++) {
            String charOrNum = random.nextInt(2) % 2 == 0 ? "char" : "num";
            if ("char".equals(charOrNum)) {
                int temp = random.nextInt(2) % 2 == 0 ? 65 : 97;
                val += (char) (random.nextInt(26) + temp);
            } else if ("num".equals(charOrNum)) {
                val += String.valueOf(random.nextInt(10));
            }
        }
        return val;
    }
}


package CommonOperation;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class BaseOpenBrowser{

    public WebDriver mWebDriver ;

    /**
     * 打开Chrome浏览器,返回webDriver对象
     */
    public WebDriver OpenChrome() {

        System.setProperty("webdriver.chrome.driver", ".\\drivers\\ChromeDriver.exe");
        mWebDriver = new ChromeDriver();
        return  mWebDriver;
    }

    /**
     * 打开Firefox浏览器
     */
    public WebDriver  OpenFirefox() {

        System.setProperty("webdriver.firefox.bin", ".\\drivers\\firefox.exe");
        mWebDriver = new FirefoxDriver();

        return  mWebDriver;
    }

    /**
     * 关闭浏览器
     */
    public void CloseChrome(){
        mWebDriver.close();
    }
}

package CommonOperation;

import java.sql.*;
import java.sql.DriverManager;
import java.sql.ResultSet;

public class DeleteData {

    /**
     * 数据库执行删除指定数据操作
     * @param tableName
     * @param name：
     * @throws SQLException
     * @throws ClassNotFoundException
     */
    public static void DeleteDataForSql(String tableName, String name) throws SQLException {
        String driver = "com.mysql.cj.jdbc.Driver";
        String url = "jdbc:mysql://121.37.128.253:3306/escdb";
        String username = "esc";
        String password = "T1v0li123!";
        Connection connection = null;
        Statement statement = null;
        try {
            Log.info("加载驱动");
            Class.forName(driver); //classLoader,加载对应驱动
            Log.info("连接数据库");
            connection = (Connection) DriverManager.getConnection(url, username, password);//建立连接
            statement = connection.createStatement();
            deleteTest(connection, statement, tableName, name);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            statement.close();
            connection.close();
        }
    }

    public static void deleteTest(Connection connection,Statement statement,String tableName, String name){
        String sql="delete from " + tableName +" where name like " + "\"" + name + "\"";
        Log.info("删除数据：" + sql);
        try {
            int count=statement.executeUpdate(sql);
            if(count>0){
                Log.info("delete success");
            }
        } catch (SQLException e) {
            Log.error(e.toString());
            e.printStackTrace();
        }
    }
}

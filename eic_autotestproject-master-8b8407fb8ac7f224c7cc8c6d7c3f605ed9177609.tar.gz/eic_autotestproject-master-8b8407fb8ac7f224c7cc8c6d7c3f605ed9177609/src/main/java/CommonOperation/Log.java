package CommonOperation;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class Log {

        // 初始化log4j log
        private static Logger log = Logger.getLogger(Log.class.getName());

        // 运行测试用例之前的日志输出
        public static void startTestCase(String sTestCaseName){
            PropertyConfigurator.configure(".\\log4j.properties");
            log.info("*******************************************************");
            log.info("$$$$$$$$$"+"执行测试用例：" + sTestCaseName+ "$$$$$$$$$$");
            log.info("*******************************************************");
        }

        // 用例执行结束后日志输出
        public static void endTestCase(String sTestCaseName){
            log.info("*******************"+"-E---N---D-"+"*******************");
            log.info("$$$$$$$$$"+"测试用例：" + sTestCaseName+ "执行结束"+ "$$$$$$$$$$");
            log.info("*******************************************************");
        }

        // 以下是不同日志级别的方法，方便需要的时候调用，一般info和error用得最多
        public static void info(String message) {
            log.info(message);
        }

        public static void warn(String message) {
            log.warn(message);
        }

        public static void error(String message) {
            log.error(message);
        }

        public static void fatal(String message) {
            log.fatal(message);
        }

        public static void debug(String message) {
            log.debug(message);
        }
}

package CommonOperation.IdentifyManagement;

import CommonOperation.FindElement;
import CommonOperation.PerformOperation;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import java.util.ArrayList;
import java.util.List;

public class PagingProcess {

    public enum STAT_PAGING {
        STAT_FIRST_PAGE,
        STAT_LAST_PAGE,
        STAT_MIDDLE_PAGE,
        STAT_FIRST_AND_LAST_PAGE
    };

    // 翻页信息
    private PagingProcess.STAT_PAGING mPagingStat;
    private int mCurCol = 0;
    private int mCurPage = 1;
    private int mCurPageStartItem = 0;
    private int mCurPageEndItem = 0;

    private int mTotalItem = 0;

    // 页面定位元素
    private By mColSwitchLocator = null;
    private By mColNumBaseLocator = null;
    private By mColNumInputLocator = null;
    private By mPagingInfoLocator = null;
    private By mInputPageNumLocator = null;
    private By mButtonPageNumLocator = null;
    private By mPrevPageLocator = null;
    private By mNextPageLocator = null;

    private String mProps = null;

    private ArrayList<Integer> mColPerPageArray = null;
    private WebDriver driver;

    public PagingProcess(WebDriver driver) {
        mColPerPageArray = new ArrayList<Integer>();
        this.driver = driver;
    }

    public void setColSwitchLocator(By colSwitchLocator) {
        mColSwitchLocator = colSwitchLocator;
    }

    public void setColNumBaseLocator(By colNumBaseLocator) {
        mColNumBaseLocator = colNumBaseLocator;
    }

    public void setColNumInputLocator(By colNumInputLocator) {
        mColNumInputLocator = colNumInputLocator;
    }

    public void setProps(String props) {
        mProps = props;
    }

    public void setPagingInfoLocator(By pagingInfoLocator) {
        mPagingInfoLocator = pagingInfoLocator;
    }

    public void setInputPageNum(By inputPageNumLocator) {
        mInputPageNumLocator = inputPageNumLocator;
    }

    public void setButtonPageNumLocator(By buttonPageNumLocator) {
        mButtonPageNumLocator = buttonPageNumLocator;
    }

    public void setPrevPageLocator(By prevPageLocator) {
        mPrevPageLocator = prevPageLocator;
    }

    public void setNextPageLocator(By nextPageLocator) {
        mNextPageLocator = nextPageLocator;
    }

    public void initPagingColData() throws InterruptedException {
        WebElement element;
        FindElement findElement = new FindElement(this.driver);
        Actions builder = new Actions(this.driver);
        PerformOperation performOperation = new PerformOperation(this.driver);

        element = findElement.findElement(mColSwitchLocator);
        builder.moveToElement(element).click().perform();

        System.out.println(mColSwitchLocator);

        Thread.sleep(5000);

        List<WebElement> elems = this.driver.findElements(mColNumBaseLocator);
        for(WebElement elem : elems) {
            if(elem.getAttribute(mProps) != null) {
                mColPerPageArray.add(Integer.valueOf(elem.getAttribute(mProps)));
            }

            System.out.println(elem.getAttribute(mProps));
        }
    }


    public void readPagingInfo() {
        FindElement findElement = new FindElement(this.driver);
        WebElement elem;
        elem = findElement.findElement(mPagingInfoLocator);

        System.out.println(elem.getText());

        String[] info = elem.getText().split(":");
        mTotalItem = Integer.parseInt(info[1].trim());
        String itemInfo = info[0].trim();
        String[] data = itemInfo.split(" ");
        String[] startEnd = data[0].split("-");
        mCurPageStartItem = Integer.parseInt(startEnd[0].trim());
        mCurPageEndItem = Integer.parseInt(startEnd[1].trim());

        elem = findElement.findElement(mColNumInputLocator);
        mCurPage = mCurPageStartItem / Integer.parseInt(elem.getAttribute("value"))  + 1;
    }


    public void SwitchColPerPage(int index) {
        WebElement element;
        FindElement findElement = new FindElement(this.driver);
        Actions builder = new Actions(this.driver);
        String pageIdxLocator = mColNumBaseLocator + "[@" + mProps + "=" + mColPerPageArray.get(index).toString() + "]";

        System.out.println(pageIdxLocator);
        element = findElement.findElement(mColSwitchLocator);
        builder.moveToElement(element).click().perform();

        findElement.findElementByXpath(pageIdxLocator).click();

        mCurCol = mColPerPageArray.get(index).intValue();
    }

    public void SwitchPage(int pageNum) {
        WebElement element;
        Actions builder = new Actions(this.driver);
        FindElement findElement = new FindElement(this.driver);
        PerformOperation performOperation = new PerformOperation(this.driver);

        performOperation.inputObject(mInputPageNumLocator, String.valueOf(pageNum));

        performOperation.clickObject(mPagingInfoLocator);

        element = findElement.findElement(mButtonPageNumLocator);
        builder.moveToElement(element).click(element).perform();

        System.out.println(mButtonPageNumLocator);

        readPagingInfo();
    }

    public void CheckPagingStat() {
        WebElement elementPrev;
        WebElement elementNext;
        FindElement findElement = new FindElement(this.driver);

        elementPrev = findElement.findElement(mPrevPageLocator);
        elementNext = findElement.findElement(mNextPageLocator);

        // 失能：true 使能:null
//        System.out.println("elementPrev:" + elementPrev.getAttribute("disabled"));
//        System.out.println("elementNext:" + elementNext.getAttribute("disabled"));

        mPagingStat = PagingProcess.STAT_PAGING.STAT_LAST_PAGE;
        if(!elementPrev.isEnabled() && !elementNext.isEnabled()) {
            mPagingStat = PagingProcess.STAT_PAGING.STAT_FIRST_AND_LAST_PAGE;
            return;
        }

        if(!elementPrev.isEnabled()) {
            mPagingStat = PagingProcess.STAT_PAGING.STAT_FIRST_PAGE;
            return;
        }

        if(!elementNext.isEnabled()) {
            mPagingStat = PagingProcess.STAT_PAGING.STAT_LAST_PAGE;
            return;
        }

        mPagingStat = PagingProcess.STAT_PAGING.STAT_MIDDLE_PAGE;

        System.out.println(mPagingStat);
    }

    public boolean PageUp() {
        PerformOperation performOperation = new PerformOperation(this.driver);

        if(mPagingStat == PagingProcess.STAT_PAGING.STAT_MIDDLE_PAGE ||
                mPagingStat == PagingProcess.STAT_PAGING.STAT_LAST_PAGE) {
            performOperation.clickObject(mPrevPageLocator);
            CheckPagingStat();
            readPagingInfo();

            return true;
        }

        return false;
    }

    public boolean PageDown() {
        PerformOperation performOperation = new PerformOperation(this.driver);

        if(mPagingStat == PagingProcess.STAT_PAGING.STAT_FIRST_PAGE ||
                mPagingStat == PagingProcess.STAT_PAGING.STAT_MIDDLE_PAGE) {
            performOperation.clickObject(mNextPageLocator);
            CheckPagingStat();
            readPagingInfo();

            return true;
        }

        return false;
    }
}

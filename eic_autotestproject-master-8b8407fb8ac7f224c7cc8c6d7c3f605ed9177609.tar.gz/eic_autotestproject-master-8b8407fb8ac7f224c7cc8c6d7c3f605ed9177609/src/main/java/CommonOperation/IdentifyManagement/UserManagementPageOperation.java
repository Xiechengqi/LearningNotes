package CommonOperation.IdentifyManagement;

import CommonOperation.FindElement;
import CommonOperation.PerformOperation;
import ElementXPath.UserManagementPageXPath;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import java.util.List;

public class UserManagementPageOperation {
    public enum OPS_RECORD_STAT {
        OPS_RECORD_DEL,
        OPS_RECORD_ENABLE,
        OPS_RECORD_DISABLE,
        OPS_RECORD_LOCK,
        OPS_RECORD_UNLOCK
    };


    private UserManagementPageXPath mPageLocator;
    private WebDriver driver;

    // 用户信息
    private String mCurUserUid;
    private String mCurUserPassword;

    // 翻页信息
    private PagingProcess mPagingProcess = null;


    public UserManagementPageOperation(WebDriver driver) {
        this.driver = driver;

        mPagingProcess = new PagingProcess(this.driver);
    }

    public void InitPagingInfo() throws InterruptedException {
        FindElement findElement = new FindElement(this.driver);

        mPagingProcess.setColNumBaseLocator(UserManagementPageXPath.SELECT_PAGE_NUM_BASE);
        mPagingProcess.setColNumInputLocator(UserManagementPageXPath.INPUT_PAGE_NUM);
        mPagingProcess.setColSwitchLocator(UserManagementPageXPath.SELECT_PAGE_NUM);

        mPagingProcess.setPagingInfoLocator(UserManagementPageXPath.INFO_PAGE_STATISTIC);

        mPagingProcess.setButtonPageNumLocator(UserManagementPageXPath.BUTTON_PAGE_NUM_SWITCH);
        mPagingProcess.setInputPageNum(UserManagementPageXPath.INPUT_PAGE_NUM_SWITCH);

        mPagingProcess.setPrevPageLocator(UserManagementPageXPath.BUTTON_PAGE_PREVIOUS);
        mPagingProcess.setNextPageLocator(UserManagementPageXPath.BUTTON_PAGE_NEXT);

        mPagingProcess.setProps("data-value");
        Thread.sleep(3000);
//        mPagingProcess.InitPagingColData();
//        mPagingProcess.SwitchColPerPage(3);
        mPagingProcess.SwitchPage(3);
    }



    public void OpenCreatePage() {
        PerformOperation performOperation = new PerformOperation(this.driver);

        performOperation.clickObject(mPageLocator.BUTTON_CREATE);
    }

    public void CreateUserInfo(String uid, String name) throws InterruptedException {
        WebElement element;
        FindElement findElement = new FindElement(this.driver);
        PerformOperation performOperation = new PerformOperation(this.driver);

        Thread.sleep(2000);

        performOperation.inputObject(mPageLocator.INPUT_UID, uid);

        performOperation.inputObject(mPageLocator.INPUT_NAME, name);

        performOperation.clickObject(mPageLocator.BUTTON_SAVE);

        // 检查点-创建提示信息回显
        element = findElement.findElement(mPageLocator.NOTICE_TEXT);
        System.out.println(element.getText());
        Assert.assertEquals(element.getText(), "新建成功");
    }


    public void OperateRecord(OPS_RECORD_STAT stat ,String uid) throws InterruptedException {
        WebElement element;
        FindElement findElement = new FindElement(this.driver);
        PerformOperation performOperation = new PerformOperation(this.driver);

        SearchRecord(uid);

        switch (stat) {
            case OPS_RECORD_DEL: {
                performOperation.clickObject(mPageLocator.BUTTON_DELETE);

                Thread.sleep(2000);

                performOperation.clickObject(mPageLocator.BUTTON_CONFIRM_PAGE_ACCEPT);

                // 检查点-删除提示信息回显
                element = findElement.findElement(mPageLocator.NOTICE_TEXT);
                System.out.println(element.getText());
                Assert.assertEquals(element.getText(), "删除成功");
                Thread.sleep(3000);
            }break;
            case OPS_RECORD_ENABLE: {
                performOperation.clickObject(mPageLocator.BUTTON_ENABLE);

                Thread.sleep(2000);

                performOperation.clickObject(mPageLocator.BUTTON_CONFIRM_PAGE_ACCEPT);

                // 检查点-启用提示信息回显
                element = findElement.findElement(mPageLocator.NOTICE_TEXT);
                System.out.println(element.getText());
                Assert.assertEquals(element.getText(), "启用成功");
                Thread.sleep(3000);
            }break;
            case OPS_RECORD_DISABLE:{
                performOperation.clickObject(mPageLocator.BUTTON_DISABLE);

                Thread.sleep(2000);

                performOperation.clickObject(mPageLocator.BUTTON_CONFIRM_PAGE_ACCEPT);

                // 检查点-停用提示信息回显
                element = findElement.findElement(mPageLocator.NOTICE_TEXT);
                System.out.println(element.getText());
                Assert.assertEquals(element.getText(), "停用成功");
                Thread.sleep(3000);
            }break;
            case OPS_RECORD_LOCK:{
                performOperation.clickObject(mPageLocator.BUTTON_LOCK);

                Thread.sleep(2000);

                performOperation.clickObject(mPageLocator.BUTTON_CONFIRM_PAGE_ACCEPT);

                // 检查点-锁定提示信息回显
                element = findElement.findElement(mPageLocator.NOTICE_TEXT);
                System.out.println(element.getText());
                Assert.assertEquals(element.getText(), "锁定成功");
                Thread.sleep(3000);
            }break;
            case OPS_RECORD_UNLOCK:{
                performOperation.clickObject(mPageLocator.BUTTON_UNLOCK);

                Thread.sleep(2000);

                performOperation.clickObject(mPageLocator.BUTTON_CONFIRM_PAGE_ACCEPT);

                // 检查点-解锁提示信息回显
                element = findElement.findElement(mPageLocator.NOTICE_TEXT);
                System.out.println(element.getText());
                Assert.assertEquals(element.getText(), "解锁成功");
                Thread.sleep(3000);
            }break;
        }

    }

    public void SearchRecord(String uid) throws InterruptedException {
        WebElement element;
        Actions builder = new Actions(driver);
        FindElement findElement = new FindElement(this.driver);
        PerformOperation performOperation = new PerformOperation(this.driver);

        Thread.sleep(3000);
        performOperation.inputObject(mPageLocator.INPUT_SEARCH, uid);
//        element.clear();
        element = findElement.findElement(mPageLocator.BUTTON_SEARCH);
        builder.moveToElement(element).click().perform();

        Thread.sleep(2000);
        performOperation.clickObject(mPageLocator.CHECK_BOX_SELECT_ALL);
    }

    public void ResetPassword(String uid) throws InterruptedException {
        FindElement findElement = new FindElement(this.driver);
        PerformOperation performOperation = new PerformOperation(this.driver);

        SearchRecord(uid);

        performOperation.clickObject(mPageLocator.BUTTON_RESET_PASSWORD);
        performOperation.clickObject(mPageLocator.BUTTON_RESET_ORIGIN_PASSWORD);
        performOperation.clickObject(mPageLocator.BUTTON_ACCEPT_RESET_PASSWORD);


        List<WebElement> elems = this.driver.findElements(mPageLocator.TEXT_NOTICE_RESET_PASSWORD);
        for(WebElement elem : elems) {
            System.out.println(elem.getText());

            // 检查点

            if(elem.getText().contains(":")) {
                String[] info = elem.getText().split(":");
                this.mCurUserUid = info[0].trim();
                this.mCurUserPassword = info[1].trim();
            }
        }

        performOperation.clickObject(mPageLocator.BUTTON_CLOSE_RESET_PASSWORD);

    }


}

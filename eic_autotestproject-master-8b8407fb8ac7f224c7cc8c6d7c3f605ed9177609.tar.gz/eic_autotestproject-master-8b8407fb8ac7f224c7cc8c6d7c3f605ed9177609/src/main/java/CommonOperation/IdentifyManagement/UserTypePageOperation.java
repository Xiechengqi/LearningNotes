package CommonOperation.IdentifyManagement;

import CommonOperation.FindElement;
import CommonOperation.PerformOperation;
import ElementXPath.UserTypePageXPath;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

public class UserTypePageOperation {

    private UserTypePageXPath mPageLocator;
    private WebDriver driver;

    public UserTypePageOperation(WebDriver driver) {
        this.driver = driver;
    }

    public void OpenCreatePage() {
        PerformOperation performOperation = new PerformOperation(this.driver);

        performOperation.clickObject(mPageLocator.BUTTON_CREATE);
    }

    public void CreateTypeInfo(String name, String code, String remark) throws InterruptedException {
        WebElement element;

        FindElement findElement = new FindElement(this.driver);
        PerformOperation performOperation = new PerformOperation(this.driver);

        performOperation.inputObject(mPageLocator.INPUT_TYPE_NAME, name);

        performOperation.inputObject(mPageLocator.INPUT_TYPE_CODE, code);

        if(!remark.isEmpty()) {
            performOperation.inputObject(mPageLocator.INPUT_TYPE_REMARK, remark);
        }

        performOperation.clickObject(mPageLocator.BUTTON_SAVE);

        // 检查点-创建提示信息回显
        element = findElement.findElement(mPageLocator.NOTICE_TEXT);
        System.out.println(element.getText());
        Assert.assertEquals(element.getText(), "新建成功");
    }


    public void DelTypeRecord(String name) throws InterruptedException {
        WebElement element;
        Actions builder = new Actions(driver);
        FindElement findElement = new FindElement(this.driver);
        PerformOperation performOperation = new PerformOperation(this.driver);

        Thread.sleep(3000);
        performOperation.inputObject(mPageLocator.INPUT_SEARCH, name);
        element = findElement.findElement(mPageLocator.BUTTON_SEARCH);
        builder.moveToElement(element).click().perform();

        Thread.sleep(2000);
        performOperation.clickObject(mPageLocator.CHECK_BOX_SELECT_ALL);
        performOperation.clickObject(mPageLocator.BUTTON_DELETE);

        Thread.sleep(2000);

        performOperation.clickObject(mPageLocator.BUTTON_DELETE_PAGE_ACCEPT);

        // 检查点-删除提示信息回显
        element = findElement.findElement(mPageLocator.NOTICE_TEXT);
        System.out.println(element.getText());
        Assert.assertEquals(element.getText(), "删除成功");
        Thread.sleep(3000);
    }

}


package CommonOperation.IdentifyManagement;

import CommonOperation.PerformOperation;
import ElementXPath.CommonElementXpath;
import org.openqa.selenium.WebDriver;

import java.nio.charset.Charset;
import java.util.ArrayList;

import com.csvreader.CsvReader;

public class IdentifyManagementUtils {

    public enum PAGE_IDENTIFY_MGMT {
        PAGE_USER_MANAGEMENT,
        PAGE_USER_TYPE,
        PAGE_ORG_MANAGEMENT,
        PAGE_JOB_MANAGEMENT
    }

    private WebDriver driver;

    public IdentifyManagementUtils(WebDriver driver) {
        this.driver = driver;
    }

    public static ArrayList<String[]> ReadCSV(String filePath) {
        ArrayList<String[]> list = new ArrayList<String[]>();
        CsvReader reader = null;

        try {
            reader = new CsvReader(filePath, ',', Charset.forName("GBK"));
            reader.readHeaders();

            while (reader.readRecord())
                list.add(reader.getValues());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            reader.close();
        }

        Object data[][] = new Object[list.size()][];
        for (int i = 0; i < list.size(); i++) {
            data[i] = list.get(i);
        }

        return list;
    }

    public void OpenIdentifyMgmtPage(IdentifyManagementUtils.PAGE_IDENTIFY_MGMT pageType) {

        PerformOperation performOperation = new PerformOperation(this.driver);

        performOperation.clickObject(CommonElementXpath.BUTTON_IDENTITY_MANAGEMENT);

        switch (pageType) {
            case PAGE_USER_MANAGEMENT:
                performOperation.clickObject(CommonElementXpath.BUTTON_USER_MANAGEMENT);
                break;
            case PAGE_USER_TYPE:
                performOperation.clickObject(CommonElementXpath.BUTTON_USER_TYPE);
                break;
            case PAGE_ORG_MANAGEMENT:
                performOperation.clickObject(CommonElementXpath.BUTTON_ORG_MANAGEMENT);
                break;
            case PAGE_JOB_MANAGEMENT:
                performOperation.clickObject(CommonElementXpath.BUTTON_JOB_MANAGEMENT);
                break;
            default:
                break;
        }
    }
}

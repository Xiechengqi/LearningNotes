package CommonOperation.IdentifyManagement;

import CommonOperation.FindElement;
import CommonOperation.PerformOperation;
import ElementXPath.JobManagementPageXPath;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

public class JobManagementPageOperation {

    private JobManagementPageXPath mPageLocator;
    private WebDriver driver;

    public JobManagementPageOperation(WebDriver driver) {
        this.driver = driver;
    }

    public void OpenCreatePage() {
        PerformOperation performOperation = new PerformOperation(this.driver);

        performOperation.clickObject(mPageLocator.BUTTON_CREATE);
    }

    public void CreateJobInfo(String name, String code, String orderNum,String remark) throws InterruptedException {
        WebElement element;
        FindElement findElement = new FindElement(this.driver);

        PerformOperation performOperation = new PerformOperation(this.driver);

        performOperation.inputObject(mPageLocator.INPUT_NAME, name);

        performOperation.inputObject(mPageLocator.INPUT_CODE, code);

        performOperation.inputObject(mPageLocator.INPUT_ORDER_NUM, orderNum);

        if(!remark.isEmpty()) {
            performOperation.inputObject(mPageLocator.INPUT_REMARK, remark);
        }

        performOperation.clickObject(mPageLocator.BUTTON_SAVE);

        // 检查点-创建提示信息回显
        element = findElement.findElement(mPageLocator.NOTICE_TEXT);
        System.out.println(element.getText());
        Assert.assertEquals(element.getText(), "新建成功");
    }


    public void DelRecord(String name) throws InterruptedException {
        WebElement element;
        Actions builder = new Actions(driver);
        FindElement findElement = new FindElement(this.driver);

        Thread.sleep(3000);
        findElement.findElement(mPageLocator.INPUT_SEARCH).sendKeys(name);
        element = findElement.findElement(mPageLocator.BUTTON_SEARCH);
        builder.moveToElement(element).click().perform();

        Thread.sleep(2000);
        findElement.findElement(mPageLocator.CHECK_BOX_SELECT_ALL).click();
        findElement.findElement(mPageLocator.BUTTON_DELETE).click();

        Thread.sleep(2000);

        findElement.findElement(mPageLocator.BUTTON_DELETE_PAGE_ACCEPT).click();

        // 检查点-删除提示信息回显
        element = findElement.findElement(mPageLocator.NOTICE_TEXT);
        System.out.println(element.getText());
        Assert.assertEquals(element.getText(), "删除成功");
        Thread.sleep(3000);

        findElement.findElement(mPageLocator.CHECK_BOX_SELECT_ALL).click();
        findElement.findElement(mPageLocator.BUTTON_PHYSICAL_DELETE).click();
        Thread.sleep(2000);

        findElement.findElement(mPageLocator.BUTTON_DELETE_PAGE_ACCEPT).click();

        // 检查点-物理删除提示信息回显
        element = findElement.findElement(mPageLocator.NOTICE_TEXT);
        System.out.println(element.getText());
        Assert.assertEquals(element.getText(), "物理删除成功");
        Thread.sleep(3000);
    }

}


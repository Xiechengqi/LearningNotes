package CommonOperation.IdentifyManagement;

import CommonOperation.FindElement;
import CommonOperation.PerformOperation;
import ElementXPath.OrgManagementPageXPath;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

public class OrgManagementPageOperation {
    private OrgManagementPageXPath mPageLocator;
    private WebDriver driver;

    public OrgManagementPageOperation(WebDriver driver) {
        this.driver = driver;
    }

    public void OpenCreatePage() {
        PerformOperation performOperation = new PerformOperation(this.driver);

        performOperation.clickObject(mPageLocator.BUTTON_CREATE);
    }

    public void CreateOrgInfo(String parentName, String name, String code) throws InterruptedException {
        WebElement element;
        Actions builder = new Actions(driver);
        PerformOperation performOperation = new PerformOperation(this.driver);

        FindElement findElement = new FindElement(this.driver);

        this.driver.findElement(By.cssSelector(".para-tree-select-right")).click();
        this.driver.findElement(By.cssSelector(".Mui-error > .para-ui-MuiInputBase-input")).click();
        this.driver.findElement(By.cssSelector(".Mui-error > .para-ui-MuiInputBase-input")).sendKeys(parentName);
        element = this.driver.findElement(By.xpath("//div[@id='para-tree-select']/descendant::span[@class='para-ui-MuiIconButton-label']"));
        builder.moveToElement(element).click().perform();

        Thread.sleep(2000);

        driver.findElement(By.cssSelector(".para-tree-checkbox-inner")).click();

        performOperation.inputObject(mPageLocator.INPUT_NAME, name);

        performOperation.inputObject(mPageLocator.INPUT_CODE, code);

        performOperation.clickObject(mPageLocator.BUTTON_SAVE);

        // 检查点-创建提示信息回显
        element = findElement.findElement(mPageLocator.NOTICE_TEXT);
        System.out.println(element.getText());
        Assert.assertEquals(element.getText(), "新建成功");
    }


    public void DelRecord(String name) throws InterruptedException {
        WebElement element;
        Actions builder = new Actions(driver);
        FindElement findElement = new FindElement(this.driver);
        PerformOperation performOperation = new PerformOperation(this.driver);

        Thread.sleep(3000);
        performOperation.inputObject(mPageLocator.INPUT_SEARCH, name);
//        element.click();
        element = findElement.findElement(mPageLocator.BUTTON_SEARCH);
        builder.moveToElement(element).click().perform();

        Thread.sleep(2000);
        performOperation.clickObject(mPageLocator.CHECK_BOX_SELECT_ALL);
        performOperation.clickObject(mPageLocator.BUTTON_DELETE);

        Thread.sleep(2000);

        performOperation.clickObject(mPageLocator.BUTTON_DELETE_PAGE_ACCEPT);

        // 检查点-删除提示信息回显
        element = findElement.findElement(mPageLocator.NOTICE_TEXT);
        System.out.println(element.getText());
        Assert.assertEquals(element.getText(), "删除成功");
        Thread.sleep(3000);

        performOperation.clickObject(mPageLocator.CHECK_BOX_SELECT_ALL);
        performOperation.clickObject(mPageLocator.BUTTON_PHYSICAL_DELETE);
        Thread.sleep(2000);

        performOperation.clickObject(mPageLocator.BUTTON_DELETE_PAGE_ACCEPT);

        // 检查点-物理删除提示信息回显
        element = findElement.findElement(mPageLocator.NOTICE_TEXT);
        System.out.println(element.getText());
        Assert.assertEquals(element.getText(), "物理删除成功");
        Thread.sleep(3000);
    }

    public void EnableRecord(String name) throws InterruptedException {
        WebElement element;
        Actions builder = new Actions(driver);
        FindElement findElement = new FindElement(this.driver);
        PerformOperation performOperation = new PerformOperation(this.driver);

        Thread.sleep(3000);
        performOperation.inputObject(mPageLocator.INPUT_SEARCH, name);
        element = findElement.findElement(mPageLocator.BUTTON_SEARCH);
        builder.moveToElement(element).click().perform();

        Thread.sleep(2000);
        performOperation.clickObject(mPageLocator.CHECK_BOX_SELECT_ALL);
        performOperation.clickObject(mPageLocator.BUTTON_ENABLE);

        performOperation.clickObject(mPageLocator.BUTTON_DELETE_PAGE_ACCEPT);

        // 检查点-停用提示信息回显
        element = findElement.findElement(mPageLocator.NOTICE_TEXT);
        System.out.println(element.getText());
        Assert.assertEquals(element.getText(), "启用成功");
        Thread.sleep(3000);
    }

    public void DisableRecord(String name) throws InterruptedException {
        WebElement element;
        Actions builder = new Actions(driver);
        FindElement findElement = new FindElement(this.driver);
        PerformOperation performOperation = new PerformOperation(this.driver);

        Thread.sleep(3000);
        performOperation.inputObject(mPageLocator.INPUT_SEARCH, name);
        element = findElement.findElement(mPageLocator.BUTTON_SEARCH);
        builder.moveToElement(element).click().perform();

        Thread.sleep(2000);
        performOperation.clickObject(mPageLocator.CHECK_BOX_SELECT_ALL);
        performOperation.clickObject(mPageLocator.BUTTON_DISABLE);

        performOperation.clickObject(mPageLocator.BUTTON_DELETE_PAGE_ACCEPT);

        // 检查点-停用提示信息回显
        element = findElement.findElement(mPageLocator.NOTICE_TEXT);
        System.out.println(element.getText());
        Assert.assertEquals(element.getText(), "停用成功");
        Thread.sleep(3000);
    }

}

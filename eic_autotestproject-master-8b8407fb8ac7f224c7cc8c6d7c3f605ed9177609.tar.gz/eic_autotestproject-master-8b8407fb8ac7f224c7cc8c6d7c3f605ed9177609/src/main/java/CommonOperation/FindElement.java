package CommonOperation;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.Random;

public class FindElement {

    WebDriver webDriver;

    public FindElement(WebDriver driver) {
        this.webDriver = driver;
    }

    /**
     * 通过传的path来查找指定元素
     *
     * @param path
     * @return
     */
    public WebElement findElement(By path) {

        WebElement result;

        Log.info("等待查找的节点出现");
        result = waitElementAppear(path);
        ThreadSleep(1);

        return result;
    }

    /**
     * 等待时间的方法
     * 添加了时间和异常的处理
     *
     * @param count：秒
     */
    public static void ThreadSleep(int count) {
        try {
            Log.info("等待" + count + "秒");
            int i = count * 1000;
            Thread.sleep(i);
        } catch (InterruptedException ex) {
            Log.error(ex.toString());
            ex.printStackTrace();
        }
    }

    /// <summary>
    /// 根据设置的Finder查找控件并返回第一个匹配的
    /// </summary>
    /// <param name="finder"></param>
    /// <returns></returns>
    public WebElement findElementByXpath(String xpath) {
        WebElement result = null;

        if (xpath != null && xpath != "") {

            try {
                result = this.webDriver.findElement(By.xpath(xpath));
            } catch (NoSuchElementException ex) {
                Log.error("查找xpath为:" + xpath + "元素时出错，出错信息是：{1}" + ex.toString());
                return result;
            }
        }

        return result;
    }

    /**
     * 通过指定的id来查找控件
     *
     * @param id
     * @return
     */
    public WebElement findElementByID(String id) {

        WebElement result = null;

        if (id != null && id != "") {

            try {
                result = this.webDriver.findElement(By.id(id));
            } catch (NoSuchElementException ex) {
                Log.error("查找id为:" + id + "元素时出错，出错信息是：{1}" + ex.toString());
                return result;
            }
        }

        return result;
    }

    /**
     * 等待控件加载出现，最多等待30秒
     * 30秒内，控件出现就会返回该控件
     *
     * @param by
     * @return
     */
    public WebElement waitElementAppear(final By by) {
        WebElement webElement = null;

        try {
            webElement = new WebDriverWait(webDriver, 30).until(new ExpectedCondition<WebElement>() {
                public WebElement apply(WebDriver driver) {
                    return driver.findElement(by);
                }
            });
        } catch (Exception e) {
            Log.error("元素" + by + "查找超时" + e.toString());
            e.printStackTrace();
        }

        return webElement;
    }

    /**
     * 等待提示信息加载出现，最多等待30秒
     * 30秒内，提示信息出现就会返回该控件
     *
     * @param by
     * @return
     */
    public WebElement waitTipsAppear(By by) {
        WebDriverWait wait = new WebDriverWait(webDriver, 15);
        wait.until(ExpectedConditions.presenceOfElementLocated(by));
        return webDriver.findElement(by);
    }
}
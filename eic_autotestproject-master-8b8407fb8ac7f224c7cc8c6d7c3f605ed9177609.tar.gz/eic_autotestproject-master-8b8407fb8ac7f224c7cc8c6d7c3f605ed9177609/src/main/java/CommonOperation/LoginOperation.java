package CommonOperation;

import ElementXPath.CommonElementXpath;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

public class LoginOperation {

    String Url;
    String UserName;
    String PassWord;
    WebDriver webDriver;

    public LoginOperation(WebDriver driver, String url , String userName, String passWord){

        this.webDriver = driver;
        this.Url = url;
        this.UserName = userName;
        this.PassWord = passWord;
    }

    public void GetUrl(){

        this.webDriver.get(this.Url);
        this.webDriver.manage().window().maximize();

        Log.info("最大化后，等待2秒钟");
        FindElement.ThreadSleep(2);
    }

    public void InputUserInfoAndSubmit(){

        WebElement element;
        WebElement element1;
        WebElement element2;

        Log.info("定位用户名输入框");
        element = this.webDriver.findElement(CommonElementXpath.INPUT_USERNAME);
        if(element != null){
            Log.info("输入用户名：" + this.UserName);
            element.sendKeys(this.UserName);
        }
        else{
            Log.error("没有获取到用户名输入框");
            Assert.assertNotNull(element,"没有获取到用户名输入框");
        }

        Log.info("定位密码输入框");
        element1 = this.webDriver.findElement(CommonElementXpath.INPUT_PASSWORD);
        if(element1 != null) {
            Log.info("输入密码：" + this.PassWord);
            element1.sendKeys(this.PassWord);
        }
        else{
            Log.error("没有获取到密码输入框");
            Assert.assertNotNull(element1,"没有获取到密码输入框");
        }

        Log.info("定位登录按钮");
        element2 = this.webDriver.findElement(CommonElementXpath.BUTTON_SSOSUBMIT);
        if(element2 != null) {
            Log.info("点击登录按钮");
            element2.click();
        }
        else{
            Log.error("没有获取到登录按钮");
            Assert.assertNotNull(element2,"没有获取到登录按钮");
        }

        FindElement.ThreadSleep(2);
    }

}

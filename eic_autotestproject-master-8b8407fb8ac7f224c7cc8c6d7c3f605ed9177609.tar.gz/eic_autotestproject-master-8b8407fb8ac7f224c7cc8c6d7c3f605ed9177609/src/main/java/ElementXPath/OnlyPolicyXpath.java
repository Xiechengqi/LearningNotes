package ElementXPath;

import org.openqa.selenium.By;

public class OnlyPolicyXpath {
    //唯一新建按钮
    public static By BUTTON_CREATE = By.xpath("//span[text()='新建']");
    //唯一名称输入框
    public static By ONLY_NAME = By.xpath("//label[text()='策略名称']/following-sibling::div/input");
    //备注
    public static By ONLY_REMARK = By.xpath("//label[text()='备注']/following-sibling::div/input");
    //用户分组
    public static By GROUP_CLASSSIFY = By.xpath("//label[text()='用户分组']/following-sibling::div/div");
    //用户分组1
    public static By GROUP_CLASSSIFY1 = By.xpath("//*[@id=\"menu-groupId\"]/div[3]/ul/li[1]");
    //可选属性
    public static By PROPERTY = By.id("mui-component-select-selectedAttr");
    //可选属性名字
    public static By PROPERTY_NAME = By.xpath("//span[text()='user_name(姓名)']");
    //可选属性邮箱
    public static By PROPERTY_EMAIL = By.xpath("//span[text()='email(邮箱)']");
    //追加
    public static By PROPERTY_ADD = By.xpath("//span[text()='追加']");
    //保存
    public static By PROPERTY_SAVE= By.xpath("//div[@class=\"eic-MuiGrid-root button-list eic-MuiGrid-item eic-MuiGrid-grid-xs-12\"]/descendant::span[text()='保存']");
    //搜索输入框
    public static By ONLY_SELECTK= By.xpath("//input[@placeholder=\"策略名称/分组名称\"]");
    //搜索按钮
    public static By ONLY_SELECT= By.xpath("//div[@class=\"main\"]//div[@class=\"eic-MuiInputAdornment-root eic-MuiInputAdornment-positionStart\"]/descendant::*[name()='svg']");
    //点击编辑
    public static By ONLY_EDIT= By.xpath("//tbody[@class=\"eic-MuiTableBody-root\"]/tr[@class=\"eic-MuiTableRow-root eic-MuiTableRow-hover\"][1]/descendant::button");
    //策略名称为必填
    public static By ONLY_NAME_K = By.xpath("//p[text()='策略名称为必填']");
    //用户分组为必填
    public static By ONLY_GROUP = By.xpath("//p[text()='用户分组为必填']");
    //已选属性为必填
    public static By ONLY_PROPERTY = By.xpath("//p[text()='属性为必填']");
    //界面勾选用户按钮
    public static By GROUP_CHECK1= By.xpath("//descendant::tr[@class=\"eic-MuiTableRow-root eic-MuiTableRow-hover\"][1]/td[1]/span");
    //停用按钮
    public static By ONLY_DISABLE = By.xpath("//span[text()='停用']");
    //停用状态
    public static By ONLY_DISABLE_STATUS = By.xpath("//descendant::tr[@class=\"eic-MuiTableRow-root eic-MuiTableRow-hover\"][1]//span[@class=\"statusColor0\"]");
    //启用按钮
    public static By ONLY_ENABLE = By.xpath("//span[text()='启用']");
    //启用状态
    public static By ONLY_ENABLE_STATUS = By.xpath("//descendant::tr[@class=\"eic-MuiTableRow-root eic-MuiTableRow-hover\"][1]//span[@class=\"statusColor1\"]");
    //确认
    public static By ONLY_AFFIRM = By.xpath("//span[text()='确认']");
    //删除按钮
    public static By ONLY_DEL = By.xpath("//span[text()='删除']");
    //界面勾选全选按钮
    public static By ALL= By.xpath("//th[@class=\"eic-MuiTableCell-root eic-MuiTableCell-head eic-MuiTableCell-paddingCheckbox eic-MuiTableCell-sizeSmall\"]");
}

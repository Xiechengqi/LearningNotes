package ElementXPath;

import org.openqa.selenium.By;

// 通知策略
public class NotifyPolicyXPath {

    public enum LanguageType {
        zh,
        en
    }

    // 页面Tab：SSO相关/IDM相关 可以直接使用：NotifyProviderXPath.NOTIFY_TAB
    // 通知方式 勾选哪项可以直接使用：CommonElementXpath.BUTTON_SHOWCOLUMNS_SELECT("邮件")
    // 必填项校验: 必须选择一种通知方式 。可以直接使用：NotifyProviderXPath.NOTIFY_REQUIRE()

    // 选择通知方式模板
    public static By NOTIFYPOLICY_TEMPLATE(String templateName) {
        return By.xpath("//div[@class='eic-MuiButtonGroup-root notify-type-button-group']/following::span[contains(text(),'" + templateName + "')]");
    }

    // 保存
    public static By NOTIFYPOLICY_SAVE = By.xpath("//span[text()='保存']");
    // 取消
    public static By NOTIFYPOLICY_CANCEL = By.xpath("//span[text()='取消']");

    //<editor-fold desc="SSO相关">

    //<editor-fold desc="邮件模板页面">

    // 模板的中文和英文Tab. 可以直接使用：NotifyProviderXPath.NOTIFY_TAB
    // 中文标题
    public static By NOTIFYPOLICY_EMAIL_TEMPLATETITLE = By.xpath("//input[@name='zh_email_templateTitle']");
    // 英文标题
    public static By NOTIFYPOLICY_EMAIL_ENTEMPLATETITLE = By.xpath("//input[@name='en_email_templateTitle']");
    // 内容
    public static By NOTIFYPOLICY_EMAIL_CONTENT = By.xpath("//div[@class='ql-editor']");

    //</editor-fold>

    //<editor-fold desc="短信模板页面">

    // 短信供应商
    public static By NOTIFY_SMS_PROVIDER = By.xpath("//label[text()='短信供应商']/following-sibling::div/div");

    /**
     * 选择中文/英文短信供应商
     *
     * @param language: 两个值
     * @param smsName:  选择的供应商名字
     * @return
     */
    public static By NOTIFY_SMS_PROVIDER_SELECT(LanguageType language, String smsName) {
        if (language == LanguageType.en) {
            return By.xpath("//div[@id='menu-en_sms_providerTemplateId']/descendant::" +
                    "ul[@class='eic-MuiList-root eic-MuiMenu-list eic-MuiList-padding']/descendant::li[text()='" + smsName + "']");
        } else {
            return By.xpath("//div[@id='menu-zh_sms_providerTemplateId']/descendant::" +
                    "ul[@class='eic-MuiList-root eic-MuiMenu-list eic-MuiList-padding']/descendant::li[text()='" + smsName + "']");
        }
    }

    // 模板ID
    public static By NOTIFYPOLICY_SMS_TEMPLATEID(LanguageType language) {
        if (language == LanguageType.en) {
            return By.xpath("//input[@name='en_sms_templateId']");
        } else {
            return By.xpath("//input[@name='zh_sms_templateId']");
        }
    }

    // 模板参数
    public static By NOTIFYPOLICY_SMS_TEMPLATECONTENT(LanguageType language) {
        if (language == LanguageType.en) {
            return By.xpath("//textarea[@name='en_sms_templateContent']");
        } else {
            return By.xpath("//textarea[@name='zh_sms_templateContent']");
        }
    }

    //</editor-fold>

    //<editor-fold desc="微信模板页面">

    // 模板ID
    public static By NOTIFYPOLICY_WECHAT_TEMPLATEID(LanguageType language) {
        if (language == LanguageType.en) {
            return By.xpath("//input[@name='en_wechat_templateId']");
        } else {
            return By.xpath("//input[@name='zh_wechat_templateId']");
        }
    }

    // 模板参数
    public static By NOTIFYPOLICY_WECHAT_TEMPLATECONTENT(LanguageType language) {
        if (language == LanguageType.en) {
            return By.xpath("//textarea[@name='en_wechat_templateContent']");
        } else {
            return By.xpath("//textarea[@name='zh_wechat_templateContent']");
        }
    }

    //</editor-fold>

    //<editor-fold desc="企业微信页面">

    // 模板参数
    public static By NOTIFYPOLICY_WORKWECHAT_TEMPLATECONTENT(LanguageType language) {
        if (language == LanguageType.en) {
            return By.xpath("//textarea[@name='en_workwechat_templateContent']");
        } else {
            return By.xpath("//textarea[@name='zh_workwechat_templateContent']");
        }
    }
    //</editor-fold>

    //<editor-fold desc="钉钉页面">

    // 模板参数
    public static By NOTIFYPOLICY_DINGDING_TEMPLATECONTENT(LanguageType language) {
        if (language == LanguageType.en) {
            return By.xpath("//textarea[@name='en_dingding_templateContent']");
        } else {
            return By.xpath("//textarea[@name='zh_dingding_templateContent']");
        }
    }

    //</editor-fold>

    //</editor-fold>

    //<editor-fold desc="IDM相关">

    // 操作启用
    public static By NOTIFYPOLICY_ENABLE(String policyName) {
        return By.xpath("//span[text()='" + policyName + "']/following::button[@title='停用']/span");
    }

    // 操作停用
    public static By NOTIFYPOLICY_DISABLE(String policyName) {
        return By.xpath("//span[text()='" + policyName + "']/following::button[@title='启用']/span");
    }

    // 操作编辑
    public static By NOTIFYPOLICY_EDIT(String policyName) {
        return By.xpath("//span[text()='" + policyName + "']/following::button[@title='编辑']/span");
    }

    // 接收人，向导
    public static By NOTIFYPOLICY_RESERVE = By.xpath("//span[text()='向导']");

    // 向导页面--删除指定接收人
    public static By NOTIFYPOLICY_RESERVE_DELETE(String userName) {
        return By.xpath("//span[text()='" + userName + "']/following-sibling::*[name()='svg']");
    }

    // 向导页面--动态接收人
    public static By NOTIFYPOLICY_AUTORESERVE = By.xpath("//span[text()='动态接收人']");
    // 向导页面--人员
    public static By NOTIFYPOLICY_USER = By.xpath("//span[text()='人员']");

    // 向导页面--选择动态接收人
    public static By NOTIFYPOLICY_AUTORESERVE_SELECT(String userName) {
        return By.xpath("//span[text()='" + userName + "']/ancestor::td/preceding-sibling::td/span");
    }

    // 向导页面--选择人员时的搜索框
    public static By NOTIFYPOLICY_USER_SEARCH = By.xpath("//input[@class='eic-MuiInputBase-input eic-MuiInputBase-inputAdornedStart']");
    // 向导页面--选择人员时的搜索按钮
    public static By NOTIFYPOLICY_USER_SEARCHBUTTON = By.xpath("//input[@class='eic-MuiInputBase-input eic-MuiInputBase-inputAdornedStart']/" +
            "preceding-sibling::div/*[name()='svg']");

    // 向导页面--选择人员 可以直接使用：NOTIFYPOLICY_AUTORESERVE_SELECT

    // 向导页面--组织架构的搜索栏
    public static By NOTIFYPOLICY_ORG_SEARCH = By.xpath("//input[@class='para-ui-MuiInputBase-input']");
    // 向导页面--组织架构的搜索按钮
    public static By NOTIFYPOLICY_ORG_SEARCHBUTTON = By.xpath("//input[@class='para-ui-MuiInputBase-input']/ancestor::div/" +
            "preceding-sibling::button/span[@class='para-ui-MuiIconButton-label']");

    // 向导页面--组织架构的组织名称
    public static By OTIFYPOLICY_ORGNAME(String orgName) {
        return By.xpath("//span[text()='" + orgName + "']");
    }

    // 向导页面--保存
    public static By NOTIFYPOLICY_RESERVE_SAVE = By.xpath("//div[@class='ie-scroll-dialog']/descendant::span[text()='保存']");
    // 向导页面--取消
    public static By NOTIFYPOLICY_RESERVE_CANCEL = By.xpath("//div[@class='ie-scroll-dialog']/descendant::span[text()='取消']");

    // 发送方式 可以直接使用：CommonElementXpath.BUTTON_SHOWCOLUMNS_SELECT("") 即时发送/定时发送

    // 通知时间--开始时间
    public static By NOTIFYPOLICY_TIMESTART = By.xpath("//input[@name='timeStart']");
    // 通知时间--结束时间
    public static By NOTIFYPOLICY_TIMEEND = By.xpath("//input[@name='timeEnd']");

    // 选择时间
    public static By NOTIFYPOLICY_SELECTTIME(String timeValue) {
        return By.xpath("//div[@class='eic-MuiPickersClock-squareMask']/following-sibling::span[text()='" + timeValue + "']");
    }

    //</editor-fold>

}

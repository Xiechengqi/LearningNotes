package ElementXPath;

import org.openqa.selenium.By;

public class InitialPasswordXpath {
    //初始密码新建按钮
    public static By BUTTON_CREATE = By.xpath("//span[text()='新建']");
    //名称输入框
    public static By NAME = By.xpath("//label[text()='策略名称']/following-sibling::div/input");
    //备注
    public static By REMARK = By.xpath("//label[text()='备注']/following-sibling::div/input");
    //用户分组
    public static By GROUP_CLASSSIFY = By.xpath("//label[text()='用户分组']/following-sibling::div/div");
    //用户分组1
    public static By GROUP_CLASSSIFY1 = By.xpath("//*[@id=\"menu-groupIds\"]/div[3]/ul/li[1]");
    //固定密码按钮
    public static By FIXED_PWD = By.xpath("//span[text()='固定密码']");
    //身份证后6位
    public static By ID6 = By.xpath("//span[text()='身份证后六位']");
    //动态表达式
    public static By EXPRESSION = By.xpath("//span[text()='动态表达式']");
    //密码输入框
    public static By PWD_INPUT = By.xpath("//label[text()='密码']/following-sibling::div/input");
    //密码输入框
    public static By ID6_INPUT = By.xpath("//label[text()='身份证为空时的密码']/following-sibling::div/input");
    //表达入框
    public static By EXPRESSION_INPUT = By.xpath("//label[text()='表达式']/following-sibling::div/input");
    //保存
    public static By SAVE= By.xpath("//div[@class=\"eic-MuiGrid-root button-list eic-MuiGrid-item eic-MuiGrid-grid-xs-12\"]/descendant::span[text()='保存']");
    //搜索输入框
    public static By SELECTK= By.xpath("//input[@placeholder=\"策略名称\"]");
    //搜索按钮
    public static By SELECT= By.xpath("//div[@class=\"main\"]//div[@class=\"eic-MuiInputAdornment-root eic-MuiInputAdornment-positionStart\"]/descendant::*[name()='svg']");
    //点击编辑
    public static By EDIT= By.xpath("//tbody[@class=\"eic-MuiTableBody-root\"]/tr[@class=\"eic-MuiTableRow-root eic-MuiTableRow-hover\"][1]/descendant::button[3]");
    //策略名称为必填
    public static By NAME_K = By.xpath("//p[text()='策略名称为必填']");
    //用户分组为必填
    public static By GROUP = By.xpath("//p[text()='用户分组为必填']");
    //密码生成策略为必填
    public static By PROPERTY = By.xpath("//p[text()='密码生成策略为必填']");
    //界面勾选用户按钮
    public static By CHECK1= By.xpath("//descendant::tr[@class=\"eic-MuiTableRow-root eic-MuiTableRow-hover\"][1]/td[1]/span");
    //停用按钮
    public static By DISABLE = By.xpath("//span[text()='停用']");
    //停用状态
    public static By DISABLE_STATUS = By.xpath("//descendant::tr[@class=\"eic-MuiTableRow-root eic-MuiTableRow-hover\"][1]//span[@class=\"statusColor0\"]");
    //启用按钮
    public static By ENABLE = By.xpath("//span[text()='启用']");
    //启用状态
    public static By ENABLE_STATUS = By.xpath("//descendant::tr[@class=\"eic-MuiTableRow-root eic-MuiTableRow-hover\"][1]//span[@class=\"statusColor1\"]");
    //确认
    public static By AFFIRM = By.xpath("//span[text()='确认']");
    //删除按钮
    public static By DEL = By.xpath("//span[text()='删除']");
    //界面勾选全选按钮
    public static By ALL= By.xpath("//th[@class=\"eic-MuiTableCell-root eic-MuiTableCell-head eic-MuiTableCell-paddingCheckbox eic-MuiTableCell-sizeSmall\"]");
    //调高
    public static By UP = By.xpath("//tbody[@class=\"eic-MuiTableBody-root\"]/tr[@class=\"eic-MuiTableRow-root eic-MuiTableRow-hover\"][2]/descendant::button[2]");
    //调高上限
    public static By UP1 = By.xpath("//tbody[@class=\"eic-MuiTableBody-root\"]/tr[@class=\"eic-MuiTableRow-root eic-MuiTableRow-hover\"][1]/descendant::button[2]");
    //上调最高提示
    public static By UP_FAIL = By.xpath("//span[contains(text(),'无法再调高')]");
    //调低
    public static By DOWN = By.xpath("//tbody[@class=\"eic-MuiTableBody-root\"]/tr[@class=\"eic-MuiTableRow-root eic-MuiTableRow-hover\"][1]/descendant::button[1]");
    //调整每页行数
    public static By SIZE = By.xpath("//div[@class=\"eic-MuiInputBase-root eic-MuiTablePagination-input eic-MuiTablePagination-selectRoot\"]");
    //100
    public static By HUNDRED = By.xpath("//*[@id=\"menu-\"]/div[3]/ul/li[5]");
   //总计元素
    public static By TOTAL = By.xpath("//div[@class=\"eic-MuiTablePagination-root\"]/div/p[2]");
    //下调最低提示
    public static By DOWN_FAIL = By.xpath("//span[contains(text(),'无法再降低')]");
}
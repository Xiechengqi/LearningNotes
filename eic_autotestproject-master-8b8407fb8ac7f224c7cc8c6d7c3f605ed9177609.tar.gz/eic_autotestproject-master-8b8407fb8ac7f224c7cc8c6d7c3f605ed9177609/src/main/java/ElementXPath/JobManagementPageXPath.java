package ElementXPath;

import org.openqa.selenium.By;

/**
 * 身份管理-岗位管理页面定位xpath
 */
public class JobManagementPageXPath {
    public static By BUTTON_CREATE = By.xpath("//div[@class='main']/descendant::span[text()='新建']");
    public static By BUTTON_DELETE = By.xpath("//div[@class='main']/descendant::span[text()='删除']");
    public static By BUTTON_PHYSICAL_DELETE = By.xpath("//div[@class='main']/descendant::span[text()='物理删除']");
    public static By BUTTON_ENABLE = By.xpath("//div[@class='main']/descendant::span[text()='启用']");
    public static By BUTTON_DISABLE = By.xpath("//div[@class='main']/descendant::span[text()='停用']");
    public static By BUTTON_EXPORT = By.xpath("//div[@class='main']/descendant::span[text()='导出']");
    public static By BUTTON_IMPORT = By.xpath("//div[@class='main']/descendant::span[text()='导入']");

    // 删除提示框
    public static By BUTTON_DELETE_PAGE_ACCEPT = By.xpath("//div[@class='eic-MuiPaper-root eic-MuiPaper-elevation0 eic-MuiPaper-rounded']/descendant::span[text()='确认']/parent::button");


    // 状态过滤
    public static By FILTER_STATUS = By.xpath("");
    public static By FILTER_STATUS_DELETE = By.xpath(" ");
    public static By FILTER_STATUS_ENABLE = By.xpath(" ");
    public static By FILTER_STATUS_DISABLE = By.xpath(" ");

    // 搜索框
    public static By BUTTON_SEARCH = By.xpath("//div[@class='main']/descendant::div[@class='eic-MuiInputAdornment-root eic-MuiInputAdornment-positionStart']");
    public static By INPUT_SEARCH = By.xpath("//div[@class='main']/descendant::input[@class='eic-MuiInputBase-input eic-MuiInputBase-inputAdornedStart']");

    // 全选
    public static By CHECK_BOX_SELECT_ALL = By.xpath("//div[@id='root']/descendant::input[@type='checkbox']");

    // 翻页
    public static By BUTTON_PAGE_PREVIOUS = By.xpath(" ");
    public static By BUTTON_PAGE_NEXT = By.xpath(" ");
    public static By INPUT_PAGE_NUM_SWITCH = By.xpath(" ");
    public static By BUTTON_PAGE_NUM_SWITCH = By.xpath(" ");
    public static By SELECT_PAGE_NUM = By.xpath(" ");
    public static By SELECT_PAGE_NUM_FIRST = By.xpath(" ");
    public static By SELECT_PAGE_NUM_SECOND = By.xpath(" ");
    public static By SELECT_PAGE_NUM_THIRD = By.xpath(" ");
    public static By SELECT_PAGE_NUM_FOURTH = By.xpath(" ");
    public static By SELECT_PAGE_NUM_FIFTH = By.xpath(" ");

    // 显示列
    public static By BUTTON_DISPLAY_COL = By.xpath(" ");

    // 提示信息
    public static By NOTICE_TEXT = By.xpath("//div[@class='para-message-notice']/descendant::span");

    /**
     * 身份管理-岗位管理-新建页面定位xpath
     */
    public static By INPUT_NAME = By.xpath("(//input[@value=''])[5]");
    public static By INPUT_CODE = By.xpath("(//input[@value=''])[5]");
    public static By INPUT_ORDER_NUM = By.xpath("(//input[@value=''])[5]");
    public static By INPUT_REMARK = By.xpath("(//input[@value=''])[5]");

    public static By BUTTON_SAVE = By.xpath("//div[@class='eic-MuiDialogActions-root eic-MuiDialogActions-spacing']/child::button[@class='eic-MuiButtonBase-root eic-MuiButton-root eic-MuiButton-contained eic-MuiButton-containedPrimary']");


}

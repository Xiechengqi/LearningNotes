package ElementXPath;

import org.openqa.selenium.By;

public class PasswordPolicyXpath {
    //密码策略新建按钮
    public static By BUTTON_CREATE = By.xpath("//span[text()='新建']");
    //名称输入框
    public static By NAME = By.xpath("//label[text()='策略名称']/following-sibling::div/input");
    //备注
    public static By REMARK = By.xpath("//label[text()='备注']/following-sibling::div/input");
    //用户分组
    public static By GROUP_CLASSSIFY = By.xpath("//label[text()='用户分组']/following-sibling::div/div");
    //用户分组1
    public static By GROUP_CLASSSIFY1 = By.xpath("//*[@id=\"menu-groupIds\"]/div[3]/ul/li[1]");
    //保存
    public static By SAVE= By.xpath("//div[@class=\"eic-MuiGrid-root button-list eic-MuiGrid-item eic-MuiGrid-grid-xs-12\"]/descendant::span[text()='保存']");
    //最小长度
    public static By MIN_LENGTH = By.xpath("//label[text()='密码最小长度/位']/following-sibling::div/input");
    //最大长度
    public static By MAX_LENGTH = By.xpath("//label[text()='密码最大长度/位']/following-sibling::div/input");
    //密码有效期/天
    public static By EFF_DAY = By.xpath("//label[text()='密码有效期/天']/following-sibling::div/input");
    //密码到期预提醒天数/天
    public static By REMIND_DAY = By.xpath("//label[text()='密码到期预提醒天数/天']/following-sibling::div/input");
    //每日的预提醒次数/次
    public static By REMIND_TIME = By.xpath("//label[text()='每日的预提醒次数/次']/following-sibling::div/input");
    //最少大写字母位数/位
    public static By LETTER = By.xpath("//label[text()='最少大写字母位数/位']/following-sibling::div/input");
    //最少小写字母位数/位
    public static By LETTER1 = By.xpath("//label[text()='最少小写字母位数/位']/following-sibling::div/input");
    //最少数字位数/位
    public static By NUMBER = By.xpath("//label[text()='最少数字位数/位']/following-sibling::div/input");
    //特殊字符个数/位
    public static By SPECAIL = By.xpath("//label[text()='特殊字符个数/位']/following-sibling::div/input");
    //强制密码历史个数/个
    public static By HISTORY = By.xpath("//label[text()='强制密码历史个数/个']/following-sibling::div/input");
    //密码错误几次锁定帐号/次
    public static By LOCK = By.xpath("//label[text()='密码错误几次锁定帐号/次']/following-sibling::div/input");
    //锁定时间/分钟
    public static By LOCK_MINS = By.xpath("//label[text()='锁定时间/分钟']/following-sibling::div/input");
    //搜索输入框
    public static By SELECTK= By.xpath("//input[@placeholder=\"策略名称\"]");
    //搜索按钮
    public static By SELECT= By.xpath("//div[@class=\"main\"]//div[@class=\"eic-MuiInputAdornment-root eic-MuiInputAdornment-positionStart\"]/descendant::*[name()='svg']");
    //点击编辑
    public static By EDIT= By.xpath("//tbody[@class=\"eic-MuiTableBody-root\"]/tr[@class=\"eic-MuiTableRow-root eic-MuiTableRow-hover\"][1]/descendant::button[3]");
    //策略名称为必填项
    public static By NAME_K = By.xpath("//p[text()='策略名称为必填项']");
    //该项为必填项
    public static By MUST = By.xpath("//p[text()='该项为必填项']");
    //界面勾选用户按钮
    public static By CHECK1= By.xpath("//descendant::tr[@class=\"eic-MuiTableRow-root eic-MuiTableRow-hover\"][1]/td[1]/span");
    //停用按钮
    public static By DISABLE = By.xpath("//span[text()='停用']");
    //停用状态
    public static By DISABLE_STATUS = By.xpath("//descendant::tr[@class=\"eic-MuiTableRow-root eic-MuiTableRow-hover\"][1]//span[@class=\"statusColor0\"]");
    //启用按钮
    public static By ENABLE = By.xpath("//span[text()='启用']");
    //启用状态
    public static By ENABLE_STATUS = By.xpath("//descendant::tr[@class=\"eic-MuiTableRow-root eic-MuiTableRow-hover\"][1]//span[@class=\"statusColor1\"]");
    //确认
    public static By AFFIRM = By.xpath("//span[text()='确认']");
    //删除按钮
    public static By DEL = By.xpath("//span[text()='删除']");
    //界面勾选全选按钮
    public static By ALL= By.xpath("//th[@class=\"eic-MuiTableCell-root eic-MuiTableCell-head eic-MuiTableCell-paddingCheckbox eic-MuiTableCell-sizeSmall\"]");
    //调高
    public static By UP = By.xpath("//tbody[@class=\"eic-MuiTableBody-root\"]/tr[@class=\"eic-MuiTableRow-root eic-MuiTableRow-hover\"][2]/descendant::button[2]");
    //调高上限
    public static By UP1 = By.xpath("//tbody[@class=\"eic-MuiTableBody-root\"]/tr[@class=\"eic-MuiTableRow-root eic-MuiTableRow-hover\"][1]/descendant::button[2]");
    //上调最高提示
    public static By UP_FAIL = By.xpath("//span[contains(text(),'无法再调高')]");
    //调低
    public static By DOWN = By.xpath("//tbody[@class=\"eic-MuiTableBody-root\"]/tr[@class=\"eic-MuiTableRow-root eic-MuiTableRow-hover\"][1]/descendant::button[1]");
    //调整每页行数
    public static By SIZE = By.xpath("//div[@class=\"eic-MuiInputBase-root eic-MuiTablePagination-input eic-MuiTablePagination-selectRoot\"]");
    //100
    public static By HUNDRED = By.xpath("//*[@id=\"menu-\"]/div[3]/ul/li[5]");
    //总计元素
    public static By TOTAL = By.xpath("//div[@class=\"eic-MuiTablePagination-root\"]/div/p[2]");
    //下调最低提示
    public static By DOWN_FAIL = By.xpath("//span[contains(text(),'无法再降低')]");
    //重新执行按钮
    public static By ROLLBACK = By.xpath("//span[text()='重新执行']");
    //重新执行按钮
    public static By ALL_EXECUTE = By.xpath("//span[text()='全部执行']");
    //按组织执行
    public static By ORG_EXECUTE = By.xpath("//span[text()='按组织执行']");
    //执行记录
    public static By EXECUTE_RECORD = By.xpath("//span[text()='执行记录']");
    //提交成功
    public static By SUBMIT_SUCCESS = By.xpath("//span[text()='提交成功']");
    //选择组织
    public static By SELECT_ORG = By.xpath("//div[@class=\"para-tree-list-holder-inner\"]/div[1]/span[2]/span[2]");
    //提交按钮
    public static By SUBMIT = By.xpath("//span[text()='提交']");
    //执行状态过滤
    public static By CLASSIFY_ILTRATE = By.xpath("//div[@class=\"eic-MuiSelect-root eic-MuiSelect-select eic-MuiSelect-selectMenu eic-MuiInputBase-input eic-MuiInput-input\"]");
    //失败
    public static By FAIL = By.xpath("//span[@class=\"eic-MuiTypography-root eic-MuiListItemText-primary eic-MuiTypography-body1 eic-MuiTypography-displayBlock\" and text()='失败']");
    //成功
    public static By SUCCESS = By.xpath("//span[@class=\"eic-MuiTypography-root eic-MuiListItemText-primary eic-MuiTypography-body1 eic-MuiTypography-displayBlock\" and text()='成功']");
    //运行中
    public static By SERVICE = By.xpath("//span[@class=\"eic-MuiTypography-root eic-MuiListItemText-primary eic-MuiTypography-body1 eic-MuiTypography-displayBlock\" and text()='运行中']");
    //等待中
    public static By WAIT = By.xpath("//span[@class=\"eic-MuiTypography-root eic-MuiListItemText-primary eic-MuiTypography-body1 eic-MuiTypography-displayBlock\" and text()='等待中']");
    //返回
    public static By RETURN = By.xpath("//span[text()='返回']");






}

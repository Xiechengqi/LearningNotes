package ElementXPath;

import org.openqa.selenium.By;

/**
 * 身份管理-用户管理页面定位xpath
 */
public class UserManagementPageXPath {
    public static By BUTTON_CREATE = By.xpath("//div[@class='main']/descendant::span[text()='新建']");
    public static By BUTTON_DELETE = By.xpath("//div[@class='main']/descendant::span[text()='删除']");
    public static By BUTTON_ENABLE = By.xpath("//div[@class='main']/descendant::span[text()='启用']");
    public static By BUTTON_DISABLE = By.xpath("//div[@class='main']/descendant::span[text()='停用']");
    public static By BUTTON_LOCK = By.xpath("//div[@class='main']/descendant::span[text()='锁定']");
    public static By BUTTON_UNLOCK = By.xpath("//div[@class='main']/descendant::span[text()='解锁']");
    public static By BUTTON_RESET_PASSWORD = By.xpath("//div[@class='main']/descendant::span[text()='重置密码']");
    public static By BUTTON_EXPORT = By.xpath("//div[@class='main']/descendant::span[text()='导出']");
    public static By BUTTON_IMPORT = By.xpath("//div[@class='main']/descendant::span[text()='导入']");

    // 新建页面
    public static By INPUT_UID = By.xpath("(//input[@value=''])[9]");
    public static By INPUT_NAME = By.xpath("(//input[@value=''])[9]");

    public static By BUTTON_SAVE = By.xpath("//div[@class='eic-MuiDialogActions-root eic-MuiDialogActions-spacing']/child::button[@class='eic-MuiButtonBase-root eic-MuiButton-root eic-MuiButton-contained eic-MuiButton-containedPrimary']");


    // 密码重置
    public static By BUTTON_RESET_ORIGIN_PASSWORD = By.xpath("//div[@class='eic-MuiPopover-root']/descendant::span[text()='初始密码']");
    public static By BUTTON_RESET_RANDOM_PASSWORD = By.xpath("//div[@class='eic-MuiPopover-root']/descendant::span[text()='随机密码']");

    // 重置密码确认提示框
    public static By BUTTON_ACCEPT_RESET_PASSWORD = By.xpath("//div[@class='eic-MuiPopover-root']/descendant::span[text()='确定']");

    // 重置后提示框
    public static By TEXT_NOTICE_RESET_PASSWORD = By.xpath("//div[@class='para-notification para-notification-topRight']/descendant::p");
    public static By BUTTON_CLOSE_RESET_PASSWORD = By.xpath("//a[@class='para-notification-notice-close']/*[name()='svg']");


    // 确认提示框
    public static By BUTTON_CONFIRM_PAGE_ACCEPT = By.xpath("//div[@class='eic-MuiPaper-root eic-MuiPaper-elevation0 eic-MuiPaper-rounded']/descendant::span[text()='确认']/parent::button");


    // 状态过滤
    public static By FILTER_STATUS = By.xpath("//div[@class='eic-MuiCardHeader-avatar']/div[@aria-haspopup='listbox'][1]");
    public static By FILTER_STATUS_ENABLE = By.xpath("//ul[@class='eic-MuiList-root eic-MuiMenu-list eic-MuiList-padding']/li[@data-value='0']//input");
    public static By FILTER_STATUS_DISABLE = By.xpath("//ul[@class='eic-MuiList-root eic-MuiMenu-list eic-MuiList-padding']/li[@data-value='1']//input");
    public static By FILTER_STATUS_PASSWORD_ERROR_LOCK = By.xpath("//ul[@class='eic-MuiList-root eic-MuiMenu-list eic-MuiList-padding']/li[@data-value='2']//input");
    public static By FILTER_STATUS_ADMIN_LOCK = By.xpath("//ul[@class='eic-MuiList-root eic-MuiMenu-list eic-MuiList-padding']/li[@data-value='3']//input");


    // 类型过滤
    public static By FILTER_TYPE = By.xpath("//div[@class='eic-MuiCardHeader-avatar']/div[@aria-haspopup='listbox'][1]");
    public static By FILTER_TYPE_DATA_BASE = By.xpath("//div[@class='eic-MuiList-root eic-MuiMenu-list eic-MuiList-padding']/li");


    // 搜索框
    public static By BUTTON_SEARCH = By.xpath("//div[@class='main']/descendant::div[@class='eic-MuiInputAdornment-root eic-MuiInputAdornment-positionStart']");
    public static By INPUT_SEARCH = By.xpath("//div[@class='main']/descendant::input[@class='eic-MuiInputBase-input eic-MuiInputBase-inputAdornedStart']");

    // 全选
    public static By CHECK_BOX_SELECT_ALL = By.xpath("//div[@id='root']/descendant::input[@type='checkbox']");

    // 翻页
    public static By BUTTON_PAGE_PREVIOUS = By.xpath("//div[@class='eic-MuiTablePagination-actions']/descendant::button[@aria-label='Previous page']");
    public static By BUTTON_PAGE_NEXT = By.xpath("//div[@class='eic-MuiTablePagination-actions']/descendant::button[@aria-label='Next page']");

    public static By INPUT_PAGE_NUM_SWITCH = By.xpath("//div[@class='eic-MuiInputBase-root eic-MuiInput-root eic-MuiInput-underline eic-MuiInputBase-adornedEnd']/descendant::input[@class='eic-MuiInputBase-input eic-MuiInput-input eic-MuiInputBase-inputAdornedEnd']");
//    public static By BUTTON_PAGE_NUM_SWITCH = "//div[@class='eic-MuiInputBase-root eic-MuiInput-root eic-MuiInput-underline eic-MuiInputBase-adornedEnd']/descendant::input[@placeholder='跳转']/following-sibling::div/*[name()='svg']";
    public static By BUTTON_PAGE_NUM_SWITCH = By.xpath("//div[@class='eic-MuiInputBase-root eic-MuiInput-root eic-MuiInput-underline eic-MuiInputBase-adornedEnd']/div/*[name()='svg'][@class='eic-MuiSvgIcon-root']");

    public static By SELECT_PAGE_NUM = By.xpath("//div[contains(@class, 'pageNav eic-MuiCardActions-spacing')]/descendant::div[contains(@class, 'eic-MuiInputBase-root eic-MuiTablePagination-input eic-MuiTablePagination-selectRoot')]/*[name()='svg']");
    public static By SELECT_PAGE_NUM_BASE = By.xpath("//ul[@class='eic-MuiList-root eic-MuiMenu-list eic-MuiList-padding']/li");
    public static By INPUT_PAGE_NUM = By.xpath("//p[contains(text(), '每页行数')]/following-sibling::*/descendant::input");


    public static By INFO_PAGE_STATISTIC = By.xpath("//div[contains(@class, 'pageNav eic-MuiCardActions-spacing')]/descendant::p[contains(text(), '总计')]");


    // 显示列
    public static By BUTTON_DISPLAY_COL = By.xpath("//span[text()='显示列']/[name()='svg']");


    // 组织架构
    public static By BUTTON_ORG_REFRESH = By.xpath("//div[@class='para-request-tree']/form/button[1]");
    public static By INPUT_ORG_REFRESH = By.xpath("//div[@class='para-request-tree']/form/descendant::input[@aria-label='请输入搜索关键词']");
    public static By BUTTON_ORG_SEARCH = By.xpath("//div[@class='para-request-tree']/form/button[2]");

    // 不存在 class='para-tree-treenode'
    // 存在未展开 class='para-tree-treenode para-tree-treenode-switcher-close'
    // 存在展开 class='para-tree-treenode para-tree-treenode-switcher-open'
    public static By ITEM_ORG_DATA = By.xpath("//div[@class='para-search-content-scroll']/descendant::div[@class='para-tree-list-holder-inner']/div[@class='para-tree-treenode']");

    // 激活状态 class='org-tree-textbtn org-tree-active' 非激活 class='org-tree-textbtn'
    public static By BUTTON_ORG_CUR_ORG = By.xpath("//p[text()='组织架构']/span[text()='当前组织']");
    public static By BUTTON_ORG_INCLUDE = By.xpath("//p[text()='组织架构']/span[text()='包含子组织']");

    // 提示信息
    public static By NOTICE_TEXT = By.xpath("//div[@class='para-message-notice']/descendant::span");
}
package ElementXPath;

import org.openqa.selenium.By;

public class AppManagementXpath {

    //<editor-fold desc="必填项校验">

    // 应用名称不能为空!
    public static By APPNAME_CHECK = By.xpath("p[text()='应用名称不能为空!']");
    // 应用编码不能为空!
    public static By APPCODE_CHECK = By.xpath("p[text()='应用编码不能为空!']");
    // 应用架构不能为空!
    public static By APPTYPE_CHECK = By.xpath("p[text()='应用架构不能为空!']");
    // 应用地址不能为空!
    public static By APPADDRESS_CHECK = By.xpath("p[text()='应用地址不能为空!']");
    // 请选择集成方式
    public static By ACCINTEGRATE_CHECK = By.xpath("p[text()='请选择集成方式']");
    // 同步方式为必填
    public static By SYNCTYPE_CHECK = By.xpath("p[text()='同步方式为必填']");
    // API URL前缀为必填
    public static By PUSHAPI_APIURL_CHECK = By.xpath("p[text()='API URL前缀为必填']");
    // IP或主机名为必填
    public static By PUSHLDAP_IP_CHECK = By.xpath("p[text()='IP或主机名为必填']");
    // 端口号为必填
    public static By PUSHLDAP_PORT_CHECK = By.xpath("p[text()='端口号为必填']");
    // BaseDN为必填
    public static By PUSHLDAP_BASEDN_CHECK = By.xpath("p[text()='BaseDN为必填']");
    // 用户名为必填
    public static By PUSHLDAP_USERNAME_CHECK = By.xpath("p[text()='用户名为必填']");
    // 密码为必填
    public static By PUSHLDAP_PASSWORD_CHECK = By.xpath("p[text()='密码为必填']");
    // 数据库类型为必填
    public static By PUSHDB_SQLTYPE_CHECK = By.xpath("p[text()='数据库类型为必填']");
    // JDBC URL为必填
    public static By PUSHDB_JDBCURL_CHECK = By.xpath("p[text()='JDBC URL为必填']");
    // appid为必填
    public static By PULL_APPID_CHECK = By.xpath("p[text()='appid为必填']");
    // appsecret为必填
    public static By PULL_APPSECRET_CHECK = By.xpath("p[text()='appsecret为必填']");
    // 预定义协议为必填
    public static By DEFSSO_TYPE_CHECK = By.xpath("p[text()='预定义协议为必填']");
    // LTPA配置为必填
    public static By LTPA_CHECK = By.xpath("p[text()='LTPA配置为必填']");
    // clientID为必填
    public static By CLIENTID_CHECK = By.xpath("p[text()='clientID为必填']");
    // clientSecret为必填
    public static By CLIENTSECRET_CHECK = By.xpath("p[text()='clientSecret为必填']");
    // callback地址为必填
    public static By CALLBACK_CHECK = By.xpath("p[text()='callback地址为必填']");
    // metaData URL为必填
    public static By METADATA_CHECK = By.xpath("p[text()='metaData URL为必填']");

    //</editor-fold>

    //<editor-fold desc="应用配置页面控件">


    // 应用配置--编辑
    public static By SPAN_APPEDIT = By.xpath("//div[@class='orga-list']/descendant::tr[@class='eic-MuiTableRow-root eic-MuiTableRow-hover']/" +
            "descendant::button[@type='button' and @title='编辑']/span");
    // 应用配置--同步策略
    public static By SPAN_ACCOUNTSUPPLY = By.xpath("//div[@class='orga-list']/descendant::tr[@class='eic-MuiTableRow-root eic-MuiTableRow-hover']/" +
            "descendant::button[@type='button' and @title='供应策略']/span");
    // 应用配置--回收
    public static By SPAN_RECYCLE = By.xpath("//div[@class='orga-list']/descendant::tr[@class='eic-MuiTableRow-root eic-MuiTableRow-hover']/" +
            "descendant::button[@type='button' and @title='回收']/span");
    // 应用配置--字段同步配置
    public static By SPAN_FIELDSYNC = By.xpath("//div[@class='orga-list']/descendant::tr[@class='eic-MuiTableRow-root eic-MuiTableRow-hover']/" +
            "descendant::button[@type='button' and @title='字段同步配置']/span");
    // 应用配置--搜索输入框
    public static By INPUT_APP_SEARCH = By.xpath("//div[@class='orga-list']/descendant::input[@class='eic-MuiInputBase-input eic-MuiInputBase-inputAdornedStart']");

    // 应用配置--搜索按钮
    // 搜索框输入值后，class控件值会变动，所以只能用水印值
    public static By BUTTON_APP_SEARCH(String searchMarkName) {
        return By.xpath("//div[@class='orga-list']/descendant::input[@placeholder='" + searchMarkName + "']/" +
                "preceding-sibling::div/*[name()='svg']");
    }

    // 应用配置--搜索内容后的checkbox
    public static By SPAN_APP_SEARCH_SELECT = By.xpath("//div[@class='orga-list']/descendant::tr[@class='eic-MuiTableRow-root eic-MuiTableRow-hover']/td/span");

    //</editor-fold>

    //<editor-fold desc="应用配置新建的第一步">

    // 新建页面的节点:应用名称
    public static By BUTTON_APPNAME = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/descendant::input[@name='pi_app__name']");
    // 新建页面的节点:应用编码
    public static By BUTTON_APPCODE = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/descendant::input[@name='pi_app__app_code']");
    // 新建页面的节点:备注
    public static By BUTTON_APPREMARK = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/descendant::input[@name='pi_app__remark']");
    // 新建页面的节点: BS 应用架构
    public static By BUTTON_APPRESTYPE_BS = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/descendant::input[@value='BS']");
    // 新建页面的节点: BS 应用架构
    public static By BUTTON_APPRESURL = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/descendant::input[@name='pi_app__resUrl']");
    // 新建页面的节点: CS 应用架构
    public static By BUTTON_APPRESTYPE_CS = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/descendant::input[@value='CS']");
    // 新建页面的节点: 选择负责人按钮
    public static By BUTTON_SELECTUSERS = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/descendant::span[text() ='选择负责人']");
    // 新建页面的节点: 选择负责人页面 搜索框输入内容
    public static By BUTTON_SELECTUSERS_SEARCHCONTENT = By.xpath("//div[@class='ie-scroll-dialog']/descendant::div[@class='eic-MuiCardHeader-avatar']/" +
            "descendant::input[@class='eic-MuiInputBase-input eic-MuiInputBase-inputAdornedStart']");
    // 新建页面的节点: 选择负责人页面 search图标
    public static By BUTTON_SELECTUSERS_SEARCH = By.xpath("//div[@class='ie-scroll-dialog']/descendant::div[@class='eic-MuiCardHeader-avatar']/" +
            "descendant::*[name()='svg']");
    // 新建页面的节点: 选择负责人页面 找到符合的用户信息并勾选
    public static By BUTTON_SELECTUSERS_SELECT = By.xpath("//div[@class='ie-scroll-dialog']/descendant::table[@class='eic-MuiTable-root']/tbody/tr/td/span");
    // 新建页面的节点: 选择负责人页面 保存
    public static By BUTTON_SELECTUSER_SAVE = By.xpath("//div[@class='ie-scroll-dialog']/" +
            "descendant::button[@class='eic-MuiButtonBase-root eic-MuiButton-root eic-MuiButton-contained eic-MuiButton-containedPrimary']/span[text()='保存']");
    // 新建页面的节点: 选择负责人页面 取消
    public static By BUTTON_SELECTUSER_CANCEL = By.xpath("//div[@class='ie-scroll-dialog']/" +
            "descendant::button[@class='eic-MuiButtonBase-root eic-MuiButton-root eic-MuiButton-text']/span[text()='取消']");
    // 新建页面的节点: 下一步
    public static By BUTTON_NEXTSTEP = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/descendant::span[text()='下一步']");
    // 新建页面的节点: 上一步
    public static By BUTTON_BACK = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/descendant::span[text()='上一步']");
    // 新建页面的节点: 取消
    public static By BUTTON_CANCEL = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/" +
            "descendant::button[@class='eic-MuiButtonBase-root eic-MuiButton-root eic-MuiButton-contained eic-MuiButton-containedPrimary']/span[text()='取消']");

    //</editor-fold>

    //<editor-fold desc="应用配置新建的第二步">

    // 新建页面的节点: 二次开发接口类
    public static By BUTTON_APICLASS = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/" +
            "descendant::div[@id='mui-component-select-app_sync_config__customized_class_name']");

    /**
     * 新建页面的节点: 二次开发接口类
     *
     * @param apiName : 选择哪项二次开发接口类就写页面上的那个值
     * @return 返回指定接口类的定位
     */
    public static By BUTTON_APICLASS_SELECTAPICLASS(String apiName) {
        return By.xpath("//div[@class='eic-MuiPaper-root eic-MuiMenu-paper eic-MuiPopover-paper eic-MuiPaper-elevation8 eic-MuiPaper-rounded']/" +
                "ul/descendant::li[text()=" + "'" + apiName + "'" + "]");
    }

    // 新建页面的节点: 是否集成
    public static By BUTTON_ACCINTEGRATE = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/" +
            "descendant::label[@class='eic-MuiFormControlLabel-root eic-MuiFormControlLabel-labelPlacementStart']/descendant::input[@name='pi_app__accIntegrate']");

    //<editor-fold desc="主推">

    // 新建页面的节点: 主推 push
    public static By BUTTON_PUSH = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/" +
            "descendant::div[@class='eic-MuiFormControl-root']/descendant::span[text()='主推']");

    // 新建页面的节点: 主推 同步方式
    public static By BUTTON_PUSHSYNCTYPE(String syncTypeName) {
        return By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/descendant::div[@class='eic-MuiFormGroup-root eic-MuiFormGroup-row']/" +
                "descendant::span[text()=" + "'" + syncTypeName + "'" + "]");
    }

    //<editor-fold desc="api同步方式">

    // 新建页面的节点: api url前缀
    public static By BUTTON_PUSHAPI_APIURL = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/descendant::div[@class='eic-MuiFormControl-root eic-MuiTextField-root eic-MuiFormControl-fullWidth']/" +
            "descendant::input[@name ='app_sync_config__push_api_url']");
    // 新建页面的节点: 数据加密
    public static By BUTTON_PUSHAPI_ENCRYPTION = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/descendant::div[@class='eic-MuiFormControl-root eic-MuiTextField-root eic-MuiFormControl-fullWidth']/" +
            "descendant::input[@name ='app_sync_config__push_encryption']");

    /**
     * 数据加密方式
     *
     * @param encryptionName : 与页面上显示的值一致，选哪个值就写哪项即可
     * @return 返回指定项的定位
     */
    public static By BUTTON_PUSHAPI_ENCRYPTIONVALUE(String encryptionName) {
        return By.xpath("//div[@id='menu-app_sync_config__push_encryption']/descendant::ul[@class='eic-MuiList-root eic-MuiMenu-list eic-MuiList-padding']/" +
                "descendant::li[text()=" + "'" + encryptionName + "'" + "]");
    }
    //</editor-fold>

    //<editor-fold desc="ldap同步方式">

    // 新建页面的节点: IP或主机名
    public static By BUTTON_PUSHLDAP_IP = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/descendant::div[@class='eic-MuiFormControl-root eic-MuiTextField-root eic-MuiFormControl-fullWidth']/" +
            "descendant::input[@name ='app_sync_config__push_ldap_ip']");
    // 新建页面的节点: 端口号
    public static By BUTTON_PUSHLDAP_PORT = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/descendant::div[@class='eic-MuiFormControl-root eic-MuiTextField-root numberInput eic-MuiFormControl-fullWidth']/" +
            "descendant::input[@name ='app_sync_config__push_ldap_port']");
    // 新建页面的节点: BaseDN
    public static By BUTTON_PUSHLDAP_BASEDN = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/descendant::div[@class='eic-MuiFormControl-root eic-MuiTextField-root eic-MuiFormControl-fullWidth']/" +
            "descendant::input[@name ='app_sync_config__push_ldap_base_dn']");
    // 新建页面的节点: 是否启用SSL
    public static By BUTTON_PUSHLDAP_SSL = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/descendant::label[text()='是否启用SSL']/" +
            "following-sibling::div[@class ='eic-MuiFormGroup-root']/descendant::span[@class='eic-MuiIconButton-label']");
    // 新建页面的节点: keystore路径
    public static By BUTTON_PUSHLDAP_SSL_KEYSTOREPATH = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/descendant::label[text()='keystore路径']/" +
            "following-sibling::div/input[@name='ldapKeystorePath']");
    // 新建页面的节点: keystore的密钥
    public static By BUTTON_PUSHLDAP_SSL_KEYSTOREPWD = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/descendant::label[text()='keystore的密钥']/" +
            "following-sibling::div/input[@name='ldapKeystorePwd']");
    // 新建页面的节点: 用户名
    public static By BUTTON_PUSHLDAP_USERNAME = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/descendant::label[text()='用户名']/" +
            "following-sibling::div/input[@name='app_sync_config__push_ldap_user_name']");
    // 新建页面的节点: 密码
    public static By BUTTON_PUSHLDAP_PASSWORD = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/descendant::label[text()='密码']/" +
            "following-sibling::div/input[@name='app_sync_config__push_ldap_password']");
    // 新建页面的节点: 测试连接
    public static By BUTTON_PUSHLDAP_CONNECTIONTEST = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/" +
            "descendant::button[@class='eic-MuiButtonBase-root eic-MuiButton-root eic-MuiButton-text eic-MuiButton-textPrimary']");

    //</editor-fold>

    //<editor-fold desc="ad同步方式">

    // 其他节点与ldap同步方式相同

    // 新建页面的节点: 域名
    public static By BUTTON_PUSHAD_DOMAINNAME = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/descendant::label[text()='域名']/" +
            "following-sibling::div/input[@name='app_sync_config__push_ldap_ad_domain_name']");

    //</editor-fold>

    //<editor-fold desc="db同步方式">

    // 新建页面的节点: 数据库类型
    public static By BUTTON_PUSHDB_DBTYPE = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/descendant::label[text()='数据库类型']/" +
            "following-sibling::div/descendant::input[@name='app_sync_config__push_db_type']");

    /**
     * 选择数据库类型
     *
     * @param dbTypeName : 与页面上显示的值一致，选哪个值就写哪项即可
     * @return 返回指定项的定位
     */
    public static By BUTTON_PUSHDB_DBTYPE_SELECT(String dbTypeName) {
        return By.xpath("//div[@id='menu-app_sync_config__push_db_type']/descendant::ul[@class='eic-MuiList-root eic-MuiMenu-list eic-MuiList-padding']/" +
                "descendant::li[text()=" + "'" + dbTypeName + "'" + "]");
    }

    // 新建页面的节点: JDBC URL
    public static By BUTTON_PUSHDB_JDBCURL = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/descendant::label[text()='JDBC URL']/" +
            "following-sibling::div/descendant::input[@name='app_sync_config__push_db_jdbc_url']");
    // 新建页面的节点: 用户名
    public static By BUTTON_PUSHDB_USERNAME = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/descendant::label[text()='用户名']/" +
            "following-sibling::div/input[@name='app_sync_config__push_db_user_name']");
    // 新建页面的节点: 密码
    public static By BUTTON_PUSHDB_PASSWORD = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/descendant::label[text()='密码']/" +
            "following-sibling::div/input[@name='app_sync_config__push_db_password']");

    //</editor-fold>

    // 额外参数
    public static By BUTTON_PUSHEXTRAINFO = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/descendant::textarea[@name ='app_sync_config__push_extra_info']");

    //</editor-fold>

    //<editor-fold desc="被推">

    // 新建页面的节点: 被推 pull
    public static By BUTTON_PULL = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/descendant::div[@class='eic-MuiFormControl-root']/descendant::span[text()='被推']");
    // 新建页面的节点: 下游系统同步回调结果
    public static By BUTTON_PULL_CALLBACK = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/" +
            "descendant::label[@class='eic-MuiFormControlLabel-root']/descendant::input[@name='app_sync_config__pull_callback']");
    // 新建页面的节点: AppID
    public static By BUTTON_PULL_APPID = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/descendant::label[text()='AppID']/" +
            "following-sibling::div/input[@name='app_sync_config__pull_secret_id']");
    // 新建页面的节点: AppSecret
    public static By BUTTON_PULL_APPSECRET = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/descendant::label[text()='AppSecret']/" +
            "following-sibling::div/input[@name='app_sync_config__pull_secret_key']");
    // 新建页面的节点: 点击生成
    public static By BUTTON_PULL_CREATE = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/descendant::span[text()='点击生成']");

    //</editor-fold>

    //</editor-fold>

    //<editor-fold desc="应用配置新建的第三步">

    /**
     * 单点协议
     *
     * @param singleName:与页面上显示的值一致，选哪个值就写哪项即可
     * @return 返回指定项的定位
     */
    public static By BUTTON_SINGLEPROTOCOL(String singleName) {
        return By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/descendant::div[@class='eic-MuiFormControl-root']/descendant::span[text()=" + "'" + singleName + "'" + "]");
    }

    //<editor-fold desc="预定义">

    // 新建页面的节点: 预定义协议
    public static By BUTTON_DEFSSOTYPE = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/descendant::div[@id='mui-component-select-pi_app__defType']");

    /**
     * 新建页面的节点: 预定义协议
     *
     * @param defTypeName : 写关联的认证值即可，不用写几级
     * @return 返回指定接口类的定位
     */
    public static By BUTTON_DEFSSOTYPE_SELECT(String defTypeName) {

        return By.xpath("//div[@id='menu-pi_app__defType']/descendant::ul[@class='eic-MuiList-root eic-MuiMenu-list eic-MuiList-padding']/" +
                "descendant::span[contains(text(),'" + defTypeName + "')]");
    }

    // 新建页面的节点: 协议参数,选择预定义协议后，协议参数自动填值
    public static By BUTTON_DEFSSOJSON = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/" +
            "descendant::textarea[@name='pi_app__defSSOJson']");
    //新建页面的节点: 认证等级
    public static By BUTTON_DEFSSO_AUTHLEVEL = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/descendant::label[text()='认证等级']/following-sibling::div");
    // descendant::input[@name='pi_app__auth_level']

    /**
     * 新建页面的节点: 认证等级
     *
     * @param levelName : 写关联的认证值即可，不用写几级
     * @return 返回指定的定位
     */
    public static By BUTTON_DEFSSO_AUTHLEVEL_SELECT(String levelName) {

        return By.xpath("//div[@id='menu-pi_app__auth_level']/descendant::ul[@class='eic-MuiList-root eic-MuiMenu-list eic-MuiList-padding']/" +
                "descendant::li[contains(text(),'" + levelName + "')]");
    }
    //</editor-fold>

    //<editor-fold desc="表单代填">

    // 新建页面的节点: 网关代填
    public static By BUTTON_ESSO_NSSO = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/descendant::label[text()='网关代填']/" +
            "following-sibling::div[@class ='eic-MuiFormGroup-root']/descendant::input[@name='pi_app__nsso']");

    //</editor-fold>

    //<editor-fold desc="LTPA">

    // 新建页面的节点: LTPA配置
    public static By BUTTON_LTPA = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/" +
            "descendant::div[@id='mui-component-select-pi_app__sso_ltpa_app_id']");

    /**
     * 新建页面的节点: LTPA配置
     *
     * @param ltpaName : 写关联的认证值即可，不用写几级
     * @return 返回指定定位
     */
    public static By BUTTON_LTPA_SELECT(String ltpaName) {

        return By.xpath("//div[@id='menu-pi_app__sso_ltpa_app_id']/descendant::ul[@class='eic-MuiList-root eic-MuiMenu-list eic-MuiList-padding']/" +
                "descendant::li[contains(text(),'" + ltpaName + "')]");
    }

    //</editor-fold>

    //<editor-fold desc="OAuth">

    // 新建页面的节点: ClientID
    public static By BUTTON_OAUTH_CLIENTID = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/descendant::label[text()='clientID']/" +
            "following-sibling::div/input[@name='pi_app__clientId']");
    // 新建页面的节点: ClientSecret
    public static By BUTTON_OAUTH_CLIENTSECRET = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/descendant::label[text()='clientSecret']/" +
            "following-sibling::div/input[@name='pi_app__clientSecret']");
    // 新建页面的节点: callback地址
    public static By BUTTON_OAUTH_CALLBACK = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/descendant::label[text()='callback地址']/" +
            "following-sibling::div/input[@name='pi_app__serviceId']");
    // 新建页面的节点: Token刷新
    public static By BUTTON_OAUTH_TOKEN = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/descendant::label[text()='Token刷新']/" +
            "following-sibling::div/descendant::span[@class='eic-MuiSwitch-thumb']");
    // 新建页面的节点: JSON Token
    public static By BUTTON_OAUTH_JSONToken = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/descendant::label[text()='JSON Token']/" +
            "following-sibling::div/descendant::span[@class='eic-MuiSwitch-thumb']");
    // 新建页面的节点: 用户信息字段
    public static By BUTTON_OAUTH_USERID = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/" +
            "descendant::input[@name='pi_app__returnUserId']");

    /**
     * 新建页面的节点: 用户信息字段
     *
     * @param userIdName : 想要选择的用户信息字段名，与界面保持一致
     * @return 返回指定定位
     */
    public static By BUTTON_OAUTH_USERID_SELECT(String userIdName) {
        // 获取符合userIdName的节点
        String userIdXpath = "//div[@id='menu-pi_app__returnUserId']/descendant::ul[@class='eic-MuiList-root eic-MuiMenu-list eic-MuiList-padding']/" +
                "descendant::span[contains(text(),'" + userIdName + "')]";
        // 获取userIdName节点的复选框
        String path = "/parent::div[@class='eic-MuiListItemText-root']/preceding::span/span[@class = 'eic-MuiIconButton-label']";

        By userIdPath = By.xpath(userIdXpath + path);

        return userIdPath;
    }

    //</editor-fold>

    //<editor-fold desc="OIDC">

    // 新建页面的节点: 加密Token
    public static By BUTTON_OIDC_ENCRYPTIDTOKEN = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/descendant::label[text()='加密Token']/" +
            "following-sibling::div/descendant::span[@class='eic-MuiSwitch-thumb']");
    // 新建页面的节点: 签名Token
    public static By BUTTON_OIDC_SINGIDTOKEN = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/descendant::label[text()='签名Token']/" +
            "following-sibling::div/descendant::span[@class='eic-MuiSwitch-thumb']");

    //</editor-fold>

    //<editor-fold desc="SAML">

    // 新建页面的节点: metaData URL
    public static By BUTTON_SAML_METADATAURL = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/descendant::label[text()='metaData URL']/" +
            "following-sibling::div/input[@name='pi_app__metadataLocation']");

    //</editor-fold>

    // 新建页面的节点: 默认浏览器
    public static By BUTTON_BROWSER = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/" +
            "descendant::div[@class='eic-MuiSelect-root eic-MuiSelect-select eic-MuiSelect-selectMenu eic-MuiInputBase-input eic-MuiInput-input']");

    /**
     * 新建页面的节点: 默认浏览器
     *
     * @param browserName : 选择哪个浏览器就写页面上的那个值
     * @return 返回指定接口类的定位
     */
    public static By BUTTON_BROWSER_SELECT(String browserName) {
        return By.xpath("//div[@id='menu-pi_app__browser']/descendant::ul[@class='eic-MuiList-root eic-MuiMenu-list eic-MuiList-padding']/" +
                "descendant::li[text()=" + "'" + browserName + "'" + "]");
    }

    // 新建页面的节点: 保存
    public static By BUTTON_APPSAVE = By.xpath("//div[@class='eic-MuiGrid-root BgBoxShadow']/descendant::span[text()='保存']");

    //</editor-fold>

    //<editor-fold desc="应用配置的供应策略">

    // 策略名称
    public static By BUTTON_ACCOUNTSUPPLY_POLICYNAME = By.xpath("//legend[text()='策略名称*']/following-sibling::div/descendant::input[@class='eic-MuiInputBase-input eic-MuiInput-input']");

    /**
     * 供应策略开关
     *
     * @param operationName：帐号同步/组织同步/岗位同步，帐号创建/帐号启用/帐号停用等名称，开关的名称
     * @param onOff：只有两个值：是和否（与页面显示的一致）
     * @return
     */
    public static By BUTTON_ACCOUNTSUPPLY_SYNCONOFF(String operationName, String onOff) {
        By value = By.xpath("//legend[contains(text(), '" + operationName + "')]/following-sibling::div/descendant::span[text()='" + onOff + "']/preceding-sibling::span");

        return value;
    }

    // 备注
    public static By BUTTON_ACCOUNTSUPPLY_REMARK = By.xpath("//legend[text()='备注']/following-sibling::div/descendant::input[@class='eic-MuiInputBase-input eic-MuiInput-input']");

    // 供应策略Tab
    public static By BUTTON_ACCOUNTSUPPLY_TAB(String supplyName) {
        return By.xpath("//div[@id='accountStrategy-box']/descendant::span[text()='" + supplyName + "']");
    }

    // 供应策略: 保存
    public static By BUTTON_ACCOUNTSUPPLY_SAVE = By.xpath("//div[@class='eic-MuiDialogActions-root eic-MuiDialogActions-spacing']/descendant::span[text()='保存']");

    // 编辑默认同步策略--用户/组织/岗位分组
    public static By BUTTON_DEFAULTORACCOUNTSUPPLY_GROUP(String groupName) {
        return By.xpath("//legend[contains(text(),'" + groupName + "')]/following-sibling::div/label");
    }

    // 编辑默认同步策略--选择用户/组织/岗位分组
    // 以及延迟开通选择天/小时/分钟
    // 以及自定义选项选择时使用该项
    public static By BUTTON_DEFAULTORACCOUNTSUPPLY_GROUP_SELECT(String groupName) {
        By value = By.xpath("//div[@id='menu-']/descendant::ul[@class='eic-MuiList-root eic-MuiMenu-list eic-MuiList-padding']/" +
                "descendant::li[text()='" + groupName + "']");

        return value;
    }

    // 新建的延迟开通和删除的延迟生效的输入框
    public static By BUTTON_DEFAULTORACCOUNTSUPPLY_DELAY(String actionName, String value) {
        return By.xpath("//span[text()='" + actionName + "']/ancestor::label[@class='eic-MuiFormControlLabel-root']/" +
                "following-sibling::div/descendant::input[@class='eic-MuiInputBase-input eic-MuiInput-input']");
    }

    // 帐号删除的自定义选项
    public static By BUTTON_DEFAULTORACCOUNTSUPPLY_DELETESELF = By.xpath("//span[text()='自定义']/ancestor::label[@class='eic-MuiFormControlLabel-root']/following-sibling::div");

    //</editor-fold>

    //<editor-fold desc="帐号管理页面控件">

    // 批量开通账号
    public static By BUTTON_BATCHOPENACCOUNT = By.xpath("//span[text()='批量开通帐号']");

    // 帐号详情
    public static By BUTTON_ACCOUNTDETAIL(String name) {
        return By.xpath("//span[text()='" + name + "']/ancestor::td/following-sibling::td/descendant::button[@type='button' and @title='帐号详情']/span");
    }

    // 帐号管理--搜索输入框
    public static By BUTTON_ACCOUNTDETAIL_SEARCHINPUT = By.xpath("//div[@class='apps-list']/descendant::input[@class='eic-MuiInputBase-input eic-MuiInputBase-inputAdornedStart']");

    // 帐号管理--搜索按钮
    public static By BUTTON_ACCOUNTDETAIL_SEARCHSVG(String searchMarkName) {
        return By.xpath("//div[@class='apps-list']/descendant::input[@placeholder='" + searchMarkName + "']/" +
                "preceding-sibling::div/*[name()='svg']");
    }

    // 帐号详情--物理删除
    public static By BUTTON_ACCOUNTDETAIL_DELETE = By.xpath("//button[@class='eic-MuiButtonBase-root eic-MuiButton-root eic-MuiButton-text eic-MuiButton-textPrimary']/" +
            "descendant::span[text()='物理删除']");
    // 帐号详情--导出
    public static By BUTTON_ACCOUNTDETAIL_EXPORT = By.xpath("//button[@class='eic-MuiButtonBase-root eic-MuiButton-root eic-MuiButton-text eic-MuiButton-textPrimary']/" +
            "descendant::span[text()='导出']");
    // 帐号详情--编辑按钮用应用管理页面的即可： SPAN_APPEDIT
    // 帐号详情--主账号绑定
    public static By BUTTON_ACCOUNTDETAIL_BINDING = By.xpath("//div[@class='orga-list']/descendant::tr[@class='eic-MuiTableRow-root eic-MuiTableRow-hover']/" +
            "descendant::button[@type='button' and @title='主帐号绑定']/span");
    // 主账号绑定--可绑定用户
    public static By BUTTON_BINDINGACCOUNT_COULD = By.xpath("//span[text()='可绑定用户']");
    // 主账号绑定--搜索输入框
    public static By BUTTON_BINDINGACCOUNT_SEARCH = By.xpath("//input[text()='UID/姓名']");

    // 点击搜索图标可以使用变量：BUTTON_APP_SEARCH("UID/姓名")，参数赋值UID/姓名即可
    // 主账号绑定--找到符合的用户信息并勾选
    public static By BUTTON_BINDINGACCOUNT_SEARCH_SELECT(String userName) {
        return By.xpath("//span[text()='" + userName + "']/ancestor::td/preceding-sibling::td/span");
    }

    // 绑定用户
    public static By BUTTON_BINDINGACCOUNT_BINDINGUSER = By.xpath("//span[text()='绑定用户']");
    // 解绑用户
    public static By BUTTON_BINDINGACCOUNT_UNBINDINGUSER = By.xpath("//span[text()='解绑用户']");
    // 关闭按钮
    public static By BUTTON_BINDINGACCOUNT_CLOSE = By.xpath("//h6[text()='主帐号绑定']/following-sibling::button");

    //<editor-fold desc="新建应用账号页面">

    // 选择UID
    public static By BUTTON_CREATEACCOUNT_UID = By.xpath("//div[text()='UID *']/following-sibling::div/descendant::span[@class='eic-MuiButton-label']");
    // 点击UID后弹出的选择框
    public static By BUTTON_CREATEACCOUNT_UID_INPUT = By.xpath("//input[@placeholder='请输入搜索关键词']");
    // 点击UID后弹出的选择框搜索按钮
    public static By BUTTON_CREATEACCOUNT_UID_SEARCH = By.xpath("//input[@placeholder='请输入搜索关键词']/ancestor::div/" +
            "following-sibling::button[@class='para-ui-MuiButtonBase-root para-ui-MuiIconButton-root para-searchbar-icon-button para-ui-MuiIconButton-colorPrimary']/span");

    // 选择指定的uid
    public static By BUTTON_CREATEACCOUNT_UID_SELECT(String name) {
        return By.xpath("//input[@name='" + name + "']");
    }

    // 帐号/帐号名称
    public static By BUTTON_CREATEACCOUNT_FIELD(String name) {

        return By.xpath("//label[text()='" + name + "']/following-sibling::div/input");
    }

    // 帐号类型
    public static By BUTTON_CREATEACCOUNT_KIND = By.xpath("//label[text()='帐号类型']/following-sibling::div/div");

    // 选择帐号类型
    public static By BUTTON_CREATEACCOUNT_KIND_SELECT(String kindName) {
        By value = By.xpath("//div[@id='menu-']/descendant::ul[@role='listbox']/" +
                "descendant::li[contains(text(),'" + kindName + "')]");

        return value;
    }
    // 保存按钮使用供应策略的保存变量即可 BUTTON_ACCOUNTSUPPLY_SAVE

    //</editor-fold>

    //</editor-fold>

}

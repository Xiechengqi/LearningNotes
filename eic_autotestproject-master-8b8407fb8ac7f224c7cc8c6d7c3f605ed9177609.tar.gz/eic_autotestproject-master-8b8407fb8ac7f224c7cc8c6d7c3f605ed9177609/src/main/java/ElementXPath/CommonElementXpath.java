package ElementXPath;

import org.openqa.selenium.By;

public class CommonElementXpath {

    /** XPath轴运算：
     ancestor::* 表示当前节点的祖父节点

     self::* 表示当前节点的自身元素

     following::* 表示当前节点后的所有节点

     preceding::* 表示当前节点前的所有节点

     following-sibling::* 表示当前节点后的所有同级节点

     preceding-sibling::* 表示当前节点前的所有同级节点

     child::* 表示当前节点的所有子节点

     parent::* 表示当前节点的所有父节点

     descendant::* 表示当前节点下的后代元素

     descendant-or-self::* 表示当前节点及他们的后代元素

     ancestor-or-self::* 表示当前节点及它的祖先节点
     */

    // 后台管理
    public static By BUTTON_BACKSTAGEMANAGEMENT = By.xpath("//div[@class ='center-menu el-col el-col-12']/ul[@role='menubar']/descendant::span[text()='后台管理']");

    // 身份管理菜单
    public static By BUTTON_IDENTITY_MANAGEMENT = By.xpath("//div[@id='root']/descendant::ul[@class='eic-MuiList-root eic-MuiList-padding']/descendant::span[text()='身份管理']");
    // 用户管理
    public static By BUTTON_USER_MANAGEMENT = By.xpath("//div[@id='root']/descendant::ul[@class='eic-MuiList-root eic-MuiList-padding']/descendant::span[text()='用户管理']");
    // 用户分类
    public static By BUTTON_USER_TYPE = By.xpath("//div[@id='root']/descendant::ul[@class='eic-MuiList-root eic-MuiList-padding']/descendant::span[text()='用户分类']");
    // 组织管理
    public static By BUTTON_ORG_MANAGEMENT = By.xpath("//div[@id='root']/descendant::ul[@class='eic-MuiList-root eic-MuiList-padding']/descendant::span[text()='组织管理']");
    // 岗位管理
    public static By BUTTON_JOB_MANAGEMENT = By.xpath("//div[@id='root']/descendant::ul[@class='eic-MuiList-root eic-MuiList-padding']/descendant::span[text()='岗位管理']");

    //策略管理
    public static By BUTTON_TACTICALMANAGEMENT = By.xpath("//span[text()='策略管理']");
    //分组策略
    public static By BUTTON_GROUPMANAGEMENT = By.xpath("//span[@class=\"eic-MuiButton-label\" and text()='分组策略']");
    //初始密码
    public static By BUTTON_IN_PWD = By.xpath("//span[@class=\"eic-MuiButton-label\" and text()='初始密码']");
    //密码策略
    public static By BUTTON_PWD = By.xpath("//span[@class=\"eic-MuiButton-label\" and text()='密码策略']");
    //唯一策略
    public static By BUTTON_ONLY = By.xpath("//span[@class=\"eic-MuiButton-label\" and text()='唯一策略']");
    //同步策略
    public static By BUTTON_SYNC = By.xpath("//span[@class=\"eic-MuiButton-label\" and text()='同步策略']");

    // 应用管理
    public static By SPAN_APPMANAGEMENT = By.xpath("//div[@class='content-box']/descendant::ul[@class='eic-MuiList-root eic-MuiList-padding']/" +
            "descendant::span[text()='应用管理']");
    // 应用配置
    public static By SPAN_APPCONFIG = By.xpath("//div[@class='content-box']/descendant::ul[@class='eic-MuiList-root eic-MuiList-padding']/" +
            "descendant::span[text()='应用配置']");
    // 帐号管理
    public static By SPAN_APPACCOUNT = By.xpath("//div[@class='content-box']/descendant::ul[@class='eic-MuiList-root eic-MuiList-padding']/descendant::span[text()='帐号管理']");

    // EIC SSO登录界面信息
    // 登录按钮
    public static By BUTTON_SSOSUBMIT = By.xpath("//div[@class='usernameWay']/descendant::div[@id='usernamaSubmit']");
    // 用户名输入框
    public static By INPUT_USERNAME = By.xpath("//div[@class='usernameWay']/descendant::input[@id='_username_username']");
    // 密码输入框
    public static By INPUT_PASSWORD = By.xpath("//div[@class='usernameWay']/descendant::input[@id='_username_password']");
    // 用户名或密码输入错误后，弹出的错误提示框
    public static By TEXT_ERRORID = By.id("error-text");

    // 每个功能页面的--操作按键：新建、删除、启用、停用、物理删除等等
    public static By BUTTON_IDM_ACTION(String actionName){
        return By.xpath("//button[@class='eic-MuiButtonBase-root eic-MuiButton-root eic-MuiButton-text eic-MuiButton-textPrimary']/" +
                "descendant::span[text()='" + actionName + "']");
    }
    // 提示框的确认按钮
    public static By BUTTON_POP_CONFIRM = By.xpath("//div[@class='ie-scroll-dialog']/descendant::span[text()='确认']");
    // 提示框的取消按钮
    public static By BUTTON_POP_CANCEL = By.xpath("//div[@class='ie-scroll-dialog']/descendant::span[text()='取消']");
    // 每个页面的显示列
    public static By BUTTON_SHOWCOLUMNS = By.xpath("span[text()='显示列']");
    // 勾选显示列下的选项
    public static By BUTTON_SHOWCOLUMNS_SELECT(String showColumnName){
        return By.xpath("//span[text()='" + showColumnName + "']/preceding-sibling::span/span[@class='eic-MuiIconButton-label']");
    }

    // 自助服务页面的按钮信息
    // 我的应用
    public static By BUTTON_PIAPP = By.xpath("//div[@class ='center-menu el-col el-col-12']/ul[@role='menubar']/descendant::span[text()='我的应用']");
    // 登录详情
    // 应用插件
    //新建成功提示
    public static By CREATE_SUCCESS = By.xpath("//span[text()='新建成功']");
    //编辑成功提示
    public static By EDIT_SUCCESS = By.xpath("//span[text()='编辑成功']");
    //操作成功提示
    public static By OPERATE_SUCCESS = By.xpath("//span[text()='操作成功']");
    //停用成功提示
    public static By DISABLE_SUCCESS = By.xpath("//span[text()='停用成功']");
    //启用成功提示
    public static By ENABLE_SUCCESS = By.xpath("//span[text()='启用成功']");
    //删除成功提示
    public static By DELETE_SUCCESS = By.xpath("//span[text()='删除成功']");
    //上调成功提示
    public static By UP_SUCCESS = By.xpath("//span[text()='上调成功']");
    //下调成功提示
    public static By DOWN_SUCCESS = By.xpath("//span[text()='下调成功']");

}

package ElementXPath;

import org.openqa.selenium.By;

// 通知接口
public class NotifyProviderXPath {

    // 页面Tab：邮件、短信、微信、钉钉、企业微信
    public static By NOTIFY_TAB(String tabName){
        return By.xpath("//span[text()= '" + tabName + "']");
    }
    // 保存
    public static By NOTIFY_SAVE = By.xpath("//div[@class='eic-MuiDialog-root ie-scroll-dialog']/descendant::span[text()='保存']");
    // 取消
    public static By NOTIFY_CANCEL = By.xpath("//div[@class='eic-MuiDialog-root ie-scroll-dialog']/descendant::span[text()='取消']");
    // 上调/下调/编辑
    public static By NOTIFY_ACTION(String actionName){
        return By.xpath("//table[@class='eic-MuiTable-root']/tbody/tr/descendant::button[@title='"+ actionName +"']/span");
    }
    // 必填项校验: 名称不能为空/短信厂商不能为空!/EncodingAESKey必填/
    public static By NOTIFY_REQUIRE(String checkName) {
        return By.xpath("//p[text()='" + checkName + "']");
    }

    //<editor-fold desc="新建邮件通知接口页面">

    // 名称
    public static By NOTIFY_EMAIL_NAME = By.xpath("//input[@name='name']");
    // 邮件地址
    public static By NOTIFY_EMAIL_EMAILADDRESS = By.xpath("//input[@name='host']");
    // 端口
    public static By NOTIFY_EMAIL_PORT = By.xpath("//input[@name='port']");
    // 邮件服务配置
    public static By NOTIFY_EMAIL_MAILSERVICECONFIG = By.xpath("//input[@name='desc']");
    // 需要认证
    public static By NOTIFY_EMAIL_AUTH = By.xpath("//label[text()='需要认证']/following-sibling::div/div");
    // 选择是否需要认证
    public static By NOTIFY_EMAIL_AUTH_SELECT(String authValue){
        return By.xpath("//div[@id = 'menu-auth']/descendant::ul[@class = 'eic-MuiList-root eic-MuiMenu-list eic-MuiList-padding']/" +
                "descendant::li[contains(text(), '" + authValue + "')]");
    }
    // 发件人密码
    public static By NOTIFY_EMAIL_PASSWORD = By.xpath("//input[@name='password']");
    // 发件人显示名
    public static By NOTIFY_EMAIL_DISPLAYNAME = By.xpath("//input[@name='displayName']");
    // SSL
    public static By NOTIFY_EMAIL_SSL = By.xpath("//input[@name='ssl']");
    // 发件人账号
    public static By NOTIFY_EMAIL_USERNAME = By.xpath("//input[@name='userName']");
    // 备注
    public static By NOTIFY_EMAIL_REMARK = By.xpath("//textarea[@name='remark']");

    //</editor-fold>

    //<editor-fold desc="新建短信通知接口页面">

    // 名称与邮件通知接口页面一致，可以直接使用：NOTIFY_EMAIL_NAME
    // 备注与邮件通知接口页面一致，可以直接使用：NOTIFY_EMAIL_REMARK
    // 短信厂商
    public static By NOTIFY_SMS_PROVIDER = By.xpath("//label[text()='短信厂商']/following-sibling::div/div");
    // 选择是否需要认证
    public static By NOTIFY_SMS_PROVIDER_SELECT(String providerValue){
        return By.xpath("//div[@id = 'menu-provider']/descendant::ul[@class = 'eic-MuiList-root eic-MuiMenu-list eic-MuiList-padding']/" +
                "descendant::li[contains(text(), '" + providerValue + "')]");
    }
    // 是否使用模板
    public static By NOTIFY_SMS_TEMPLATE = By.xpath("//div[@id='mui-component-select-template']");
    // 选择是否使用模板
    public static By NOTIFY_SMS_TEMPLATE_SELECT(String authValue){
        return By.xpath("//div[@id = 'menu-auth']/descendant::ul[@class = 'eic-MuiList-root eic-MuiMenu-list eic-MuiList-padding']/" +
                "descendant::li[contains(text(), '" + authValue + "')]");
    }
    // 协议头(http/https)
    public static By NOTIFY_SMS_PROTOCOL = By.xpath("input[@name = 'protocol']");
    // 短信服务地址
    public static By NOTIFY_SMS_HOST = By.xpath("input[@name = 'host']");
    // 短信服务端口
    public static By NOTIFY_SMS_PORT = By.xpath("input[@name = 'port']");
    // 短信接口实现类
    public static By NOTIFY_SMS_CLASSPATH = By.xpath("input[@name = 'classPath']");
    // accessKeyId
    public static By NOTIFY_SMS_ACCESSKEYID = By.xpath("input[@name = 'accessKeyId']");
    // accessKeySecret
    public static By NOTIFY_SMS_ACCESSKEYSECRET = By.xpath("input[@name = 'accessKeySecret']");
    // signName/大陆签名
    public static By NOTIFY_SMS_SIGNNAME = By.xpath("input[@name= 'signName']");
    // signName/港澳台&国际签名
    public static By NOTIFY_SMS_FOREIGNSIGNNAME = By.xpath("input[@name = 'foreignSignName']");

    //</editor-fold>

    //<editor-fold desc="新建微信通知接口页面">

    // 名称与邮件通知接口页面一致，可以直接使用：NOTIFY_EMAIL_NAME
    // 备注与邮件通知接口页面一致，可以直接使用：NOTIFY_EMAIL_REMARK
    // AppID
    public static By NOTIFY_WECHAT_APPID = By.xpath("input[@name= 'AppID']");
    // AppSecret
    public static By NOTIFY_WECHAT_APPSECRET = By.xpath("input[@name= 'AppSecret']");
    // Token
    public static By NOTIFY_WECHAT_TOKEN = By.xpath("input[@name= 'Token']");
    // EncodingAESKey
    public static By NOTIFY_WECHAT_ENCODINGAESKEY = By.xpath("input[@name='EncodingAESKey']");

    //</editor-fold>

    //<editor-fold desc="新建钉钉通知接口页面">

    // 名称与邮件通知接口页面一致，可以直接使用：NOTIFY_EMAIL_NAME
    // 备注与邮件通知接口页面一致，可以直接使用：NOTIFY_EMAIL_REMARK
    // AgentId
    public static By NOTIFY_DINGDING_AGENTID = By.xpath("input[@name='AgentId']");
    // AppKey
    public static By NOTIFY_DINGDING_APPKEY = By.xpath("input[@name='AppKey']");
    // AppSecret
    public static By NOTIFY_DINGDING_APPSECRET = By.xpath("input[@name='AppSecret']");

    //</editor-fold>

    //<editor-fold desc="新建企业微信通知接口页面">

    // 名称与邮件通知接口页面一致，可以直接使用：NOTIFY_EMAIL_NAME
    // 备注与邮件通知接口页面一致，可以直接使用：NOTIFY_EMAIL_REMARK
    // 企业ID与钉钉页面的AppKey字段一致，可以直接使用：NOTIFY_DINGDING_APPKEY
    // AppSecret与钉钉页面的AppSecret字段一致，可以直接使用：NOTIFY_DINGDING_APPSECRET
    // AgentId与钉钉页面的AgentId字段一致，可以直接使用：NOTIFY_DINGDING_AGENTID

    //</editor-fold>

}

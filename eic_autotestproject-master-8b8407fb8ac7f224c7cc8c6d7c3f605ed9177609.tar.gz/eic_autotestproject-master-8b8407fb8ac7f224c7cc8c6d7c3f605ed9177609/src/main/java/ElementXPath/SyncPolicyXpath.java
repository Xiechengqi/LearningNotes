package ElementXPath;

import org.openqa.selenium.By;

public class SyncPolicyXpath {
    //分组新建按钮
    public static By BUTTON_CREATE = By.xpath("//span[text()='新建']");
    //同步名称输入框
    public static By SYNC_NAME = By.xpath("//label[text()='策略名称']/following-sibling::div/input");
    //备注
    public static By SYNC_REMARK = By.xpath("//label[text()='备注']/following-sibling::div/input");
    //处理类
    public static By DISPOSE = By.id("mui-component-select-config_interfaceClassName");
    //BPMDataSyncServiceImpl类
    public static By BPM = By.xpath("//li[text()='BPMDataSyncServiceImpl']");
    //API URL
    public static By API_URL= By.xpath("//label[text()='API URL']/following-sibling::div/input");
    //保存
    public static By SYNC_SAVE= By.xpath("//div[@class=\"eic-MuiGrid-root button-list eic-MuiGrid-item eic-MuiGrid-grid-xs-12\"]/descendant::span[text()='保存']");
    //LDAP
    public static By LDAP= By.xpath("//span[@class=\"eic-MuiTypography-root eic-MuiFormControlLabel-label eic-MuiTypography-body1\" and text()='LDAP']");
    //IP
    public static By IP= By.xpath("//label[text()='IP/域名']/following-sibling::div/input");
    //端口
    public static By PORT= By.xpath("//label[text()='端口']/following-sibling::div/input");
    //BaseDN
    public static By BaseDN= By.xpath("//label[text()='BaseDN']/following-sibling::div/input");
    //用户名
    public static By USER_NAME= By.xpath("//label[text()='用户名']/following-sibling::div/input");
    //密码
    public static By PWD= By.xpath("//label[text()='密码']/following-sibling::div/input");
    //AD
    public static By AD= By.xpath("//span[@class=\"eic-MuiTypography-root eic-MuiFormControlLabel-label eic-MuiTypography-body1\" and text()='AD']");
    //DB
    public static By DB= By.xpath("//span[@class=\"eic-MuiTypography-root eic-MuiFormControlLabel-label eic-MuiTypography-body1\" and text()='DB']");
    //JDBC URL
    public static By JDBC_URL= By.xpath("//label[text()='JDBC URL']/following-sibling::div/input");
    //搜索输入框
    public static By SYNC_SELECTK= By.xpath("//input[@placeholder=\"策略名称\"]");
    //搜索按钮
    public static By SYNC_SELECT= By.xpath("//div[@class=\"main\"]//div[@class=\"eic-MuiInputAdornment-root eic-MuiInputAdornment-positionStart\"]/descendant::*[name()='svg']");
    //点击编辑
    public static By SYNC_EDIT= By.xpath("//tbody[@class=\"eic-MuiTableBody-root\"]/tr[@class=\"eic-MuiTableRow-root eic-MuiTableRow-hover\"][1]/descendant::button");
    //BPMDataSyncServiceImpl类
    public static By DEMO = By.xpath("//li[text()='DemoDataSyncServiceImpl']");
    //界面勾选用户按钮
    public static By GROUP_CHECK1= By.xpath("//descendant::tr[@class=\"eic-MuiTableRow-root eic-MuiTableRow-hover\"][1]/td[1]/span");
    //停用按钮
    public static By SYNC_DISABLE = By.xpath("//span[text()='停用']");
    //停用状态
    public static By SYNC_DISABLE_STATUS = By.xpath("//descendant::tr[@class=\"eic-MuiTableRow-root eic-MuiTableRow-hover\"][1]//span[@class=\"statusColor0\"]");
    //启用按钮
    public static By SYNC_ENABLE = By.xpath("//span[text()='启用']");
    //启用状态
    public static By SYNC_ENABLE_STATUS = By.xpath("//descendant::tr[@class=\"eic-MuiTableRow-root eic-MuiTableRow-hover\"][1]//span[@class=\"statusColor1\"]");
    //确认
    public static By SYNC_AFFIRM = By.xpath("//span[text()='确认']");
    //删除按钮
    public static By SYNC_DEL = By.xpath("//span[text()='删除']");
    //界面勾选全选按钮
    public static By ALL= By.xpath("//th[@class=\"eic-MuiTableCell-root eic-MuiTableCell-head eic-MuiTableCell-paddingCheckbox eic-MuiTableCell-sizeSmall\"]");
    //同步记录
    public static By RECORD= By.xpath("//tbody[@class=\"eic-MuiTableBody-root\"]/tr[@class=\"eic-MuiTableRow-root eic-MuiTableRow-hover\"][1]/descendant::button[2]");
    //运行结果
    public static By RESULT = By.xpath("//div[@class=\"eic-MuiPaper-root eic-MuiCard-root eic-MuiPaper-elevation1 eic-MuiPaper-rounded\"]/div/div/div[1]//div[@class=\"eic-MuiSelect-root eic-MuiSelect-select eic-MuiSelect-selectMenu eic-MuiInputBase-input eic-MuiInput-input\"]");
    //成功
    public static By SUCCESS = By.xpath("//span[@class=\"eic-MuiTypography-root eic-MuiListItemText-primary eic-MuiTypography-body2 eic-MuiTypography-displayBlock\" and text()='成功']");
    //失败
    public static By FAIL = By.xpath("//span[@class=\"eic-MuiTypography-root eic-MuiListItemText-primary eic-MuiTypography-body2 eic-MuiTypography-displayBlock\" and text()='失败']");
    //执行中
    public static By EXECUTE = By.xpath("//span[@class=\"eic-MuiTypography-root eic-MuiListItemText-primary eic-MuiTypography-body2 eic-MuiTypography-displayBlock\" and text()='执行中']");
    //返回按钮
    public static By RETURN = By.xpath("//button[@class=\"eic-MuiButtonBase-root eic-MuiButton-root eic-MuiButton-text back-button eic-MuiButton-textPrimary\"]");
    //新建成功提示
    public static By CREATE_SUCC = By.xpath("//span[text()='新建成功']");

}

package ElementXPath;

import org.openqa.selenium.By;

public class GroupManagementXpath {
    //分组新建按钮
    public static By BUTTON_CREATE = By.xpath("//span[text()='新建']");
    //分组名称输入框
    public static By GROUP_NAME = By.xpath("//label[text()='分组名称']/following-sibling::div/input");
    //备注
    public static By GROUP_REMARK = By.xpath("//label[text()='备注']/following-sibling::div/input");
    //分组分类
    public static By GROUP_CLASSSIFY = By.xpath("//label[text()='分组分类']/following-sibling::div/div");
    //动态分组
    public static By GROUP_DYNAMIC = By.xpath("//li[text()='动态分组']");
    //静态分组
    public static By GROUP_STATIC = By.xpath("//li[text()='静态分组']");
    //分组类型
    public static By GROUP_TYPE = By.xpath("//label[text()='分组类型']/following-sibling::div/div");
    //岗位分组
    public static By GROUP_JOB = By.xpath("//li[text()='岗位分组']");
    //组织分组
    public static By GROUP_ORG= By.xpath("//li[text()='组织分组']");
    //用户分组
    public static By GROUP_USER= By.xpath("//li[text()='用户分组']");
    //保存按钮
    public static By GROUP_SAVE= By.xpath("//div[@class=\"ie-scroll-dialog global-modal-scss\"]/descendant::span[text()='保存']");
    //分组名称必填提示
    public static By GROUP_CREATEINFO= By.xpath("//P[text()='请输入必填项']");
    //分组分类必填提示
    public static By GROUP_CLASSSIFYINFO= By.xpath("//label[text()='分组分类']/following-sibling::p");
    //分组类型必填提示
    public static By GROUP_TYPEINFO= By.xpath("//label[text()='分组类型']/following-sibling::p");
    //搜索输入框
    public static By GROUP_SELECTK= By.xpath("//input[@placeholder=\"分组名称\"]");
    //搜索按钮
    public static By GROUP_SELECT= By.xpath("//div[@class=\"main\"]//div[@class=\"eic-MuiInputAdornment-root eic-MuiInputAdornment-positionStart\"]/descendant::*[name()='svg']");
    //点击编辑
    public static By GROUP_EDIT= By.xpath("//tbody[@class=\"eic-MuiTableBody-root\"]/tr[@class=\"eic-MuiTableRow-root eic-MuiTableRow-hover\"][1]/descendant::button");
    //可添加用户按钮
    public static By GROUP_CAN_ADD= By.xpath("//span[text()='可添加']");
    //已添加用户按钮
    public static By GROUP_ADDED= By.xpath("//span[text()='已添加']");
    //勾选用户按钮
    public static By GROUP_CHECK= By.xpath("//div[@class=\"eic-MuiPaper-root eic-MuiDialog-paper eic-MuiDialog-paperScrollPaper eic-MuiDialog-paperWidthMd eic-MuiPaper-elevation24 eic-MuiPaper-rounded\"]/descendant::tr[@class=\"eic-MuiTableRow-root eic-MuiTableRow-hover\"][1]/td[1]/span");
    //界面勾选用户按钮
    public static By GROUP_CHECK1= By.xpath("//descendant::tr[@class=\"eic-MuiTableRow-root eic-MuiTableRow-hover\"][1]/td[1]/span");
    //绑定用户按钮
    public static By GROUP_BINGING= By.xpath("//span[text()='绑定']");
    //绑定用户按钮
    public static By GROUP_UNBING= By.xpath("//span[text()='解绑']");
    //绑定保存按钮
    public static By GROUP_BINGSAVE= By.xpath("//div[@class=\"eic-MuiPaper-root eic-MuiPaper-elevation0 eic-MuiPaper-rounded\"]/descendant::span[text()='保存']");
    //动态属性分类
    public static By GROUP_PROPERTY_C = By.xpath("//label[text()='属性分类']/following-sibling::div/div");
    //idt_user
    public static By GROUP_IDT_USER = By.xpath("//li[text()='idt_user']");
    //动态属性
    public static By GROUP_PROPERTY = By.xpath("//label[text()='属性']/following-sibling::div/div");
    //属性UID
    public static By GROUP_UID = By.xpath("//li[text()='uid(UID)']");
    //操作符
    public static By GROUP_OPERA = By.xpath("//label[text()='操作符']/following-sibling::div/div");
    //操作==
    public static By GROUP_EQUALS = By.xpath("//li[text()='==']");
    //值
    public static By GROUP_VALUE = By.xpath("//label[text()='值']/following-sibling::div/input");
    //加入表达式
    public static By GROUP_ADD = By.xpath("//span[text()='加入表达式']");
    //动态保存
    public static By GROUP_SAVE_D = By.xpath("//span[text()='保存']");
    //删除按钮
    public static By GROUP_DEL = By.xpath("//span[text()='删除']");
    //删除确认
    public static By GROUP_AFFIRM = By.xpath("//span[text()='确认']");
    //类型过滤
    public static By TYPE_FILTRATE = By.xpath("//div[@class=\"eic-MuiPaper-root eic-MuiCard-root eic-MuiPaper-elevation1 eic-MuiPaper-rounded\"]/div/div/div[1]//div[@class=\"eic-MuiSelect-root eic-MuiSelect-select eic-MuiSelect-selectMenu eic-MuiInputBase-input eic-MuiInput-input\"]");
    //用户分组过滤
    public static By GROUP_USER_F = By.xpath("//span[@class=\"eic-MuiTypography-root eic-MuiListItemText-primary eic-MuiTypography-body2 eic-MuiTypography-displayBlock\" and text()='用户分组']");
    //校验刷选为用户分组
    public static By GROUP_USER_F1 = By.xpath("//descendant::tr[@class=\"eic-MuiTableRow-root eic-MuiTableRow-hover\"][1]//span[text()='用户分组']");
    //岗位分组过滤
    public static By GROUP_JOB_F = By.xpath("//span[@class=\"eic-MuiTypography-root eic-MuiListItemText-primary eic-MuiTypography-body2 eic-MuiTypography-displayBlock\" and text()='岗位分组']");
    //校验刷选为岗位分组
    public static By GROUP_JOB_F1 = By.xpath("//descendant::tr[@class=\"eic-MuiTableRow-root eic-MuiTableRow-hover\"][1]//span[text()='岗位分组']");
    //组织分组过滤
    public static By GROUP_ORG_F = By.xpath("//span[@class=\"eic-MuiTypography-root eic-MuiListItemText-primary eic-MuiTypography-body2 eic-MuiTypography-displayBlock\" and text()='组织分组']");
    //校验刷选为组织分组
    public static By GROUP_ORG_F1 = By.xpath("//descendant::tr[@class=\"eic-MuiTableRow-root eic-MuiTableRow-hover\"][1]//span[text()='组织分组']");
    //逻辑或
    public static By GROUP_OR = By.xpath("//span[text()='逻辑或 ']");
    //分类过滤
    public static By CLASSIFY_ILTRATE = By.xpath("//div[@class=\"eic-MuiPaper-root eic-MuiCard-root eic-MuiPaper-elevation1 eic-MuiPaper-rounded\"]/div/div/div[2]//div[@class=\"eic-MuiSelect-root eic-MuiSelect-select eic-MuiSelect-selectMenu eic-MuiInputBase-input eic-MuiInput-input\"]");
    //静态分组过滤
    public static By GROUP_STATIC_F = By.xpath("//span[@class=\"eic-MuiTypography-root eic-MuiListItemText-primary eic-MuiTypography-body2 eic-MuiTypography-displayBlock\" and text()='静态分组']");
    //校验刷选为静态分组
    public static By GROUP_STATIC_F1 = By.xpath("//descendant::tr[@class=\"eic-MuiTableRow-root eic-MuiTableRow-hover\"][1]//span[text()='静态分组']");
    //动态分组过滤
    public static By GROUP_DYNAMIC_F = By.xpath("//span[@class=\"eic-MuiTypography-root eic-MuiListItemText-primary eic-MuiTypography-body2 eic-MuiTypography-displayBlock\" and text()='动态分组']");
    //校验刷选为动态分组
    public static By GROUP_DYNAMIC_F1 = By.xpath("//descendant::tr[@class=\"eic-MuiTableRow-root eic-MuiTableRow-hover\"][1]//span[text()='动态分组']");








}

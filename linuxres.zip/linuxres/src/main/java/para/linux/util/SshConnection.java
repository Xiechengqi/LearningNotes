/**
 * 
 */
package para.linux.util;

import java.io.File;

import ch.ethz.ssh2.Connection;
import ch.ethz.ssh2.Session;

public class SshConnection {
	
	private String host = "172.16.7.177";

	private int port = 22; 
	private String keyUrl = null; 

	private String user = "gs312s_main_dev";

	private String pwd = "gs312s_main_dev";
	
	private Connection conn;
	
	private Session sess;
	
	private boolean isAuthenticated = false;
	
	public SshConnection() {
		
	}
	
	public SshConnection(String host, int port, String user, String pwd) {
		this.host = host;
		this.port = port;
		this.user = user;
		this.pwd = pwd;
	}
	
	public SshConnection(String host, int port, String user, String pwd,
			String keyUrl) {
		this.host = host;
		this.port = port;
		this.user = user;
		this.pwd = pwd;
		this.keyUrl = keyUrl;
	}
	
	public Connection getSSHConnection() throws Exception {
		if(conn == null) {
			conn = new Connection(host,port);
//			conn = new Connection(host);
			conn.connect();
			isAuthenticated = conn.authenticateWithPassword(user, pwd);
			if(!isAuthenticated){
				conn = null;
			}
		}
		return conn;
	}
	
	
	public Connection getSSHConnectionInteractive() throws Exception{
		if(conn == null) {
			//conn = new Connection(host);
			conn = new Connection(host,port);
			conn.connect();
			if (conn.isAuthMethodAvailable(user, "keyboard-interactive"))
			{
				InteractiveLogic il = new InteractiveLogic(pwd);
				isAuthenticated = conn.authenticateWithKeyboardInteractive(user, il);
				if(!isAuthenticated){
					isAuthenticated = conn.authenticateWithPassword(user, pwd);
				}
			}else{
				isAuthenticated = conn.authenticateWithPassword(user, pwd);
			}
		}
		return conn;
	}
	
	public Connection getSSHConnectionInteractive4Key() throws Exception{
		if(conn == null) {
			conn = new Connection(host, port);
			conn.connect();
			boolean isAuthenticated = false;
			isAuthenticated = conn.authenticateWithPublicKey(user, new File(
					keyUrl), pwd);
			if(!isAuthenticated){
				throw new Exception("connect to server:"+host+" with private key failed");
			}
		}
		return conn;
	}
	
	public void closeConnection() {
		if(conn!=null){
			conn.close();
			conn=null;
		}
		if(sess!=null){
			sess.close();
			sess=null;
		}
	}
	
	public CommandStatement createCommand(String command) throws Exception {
		CommandStatement statement = new CommandStatement(getSSHConnection());
		statement.setCommand(command);
		return statement;
	}
	
	public CommandStatement createCommand() throws Exception {
		CommandStatement statement = new CommandStatement(getSSHConnection());
		return statement;
		
	}
	
	public CommandStatement createCommandInteractive(String command) throws Exception {
		CommandStatement statement = new CommandStatement(getSSHConnectionInteractive());
		statement.setCommand(command);
		return statement;
	}
	
	public CommandStatement createCommandInteractive() throws Exception {
		CommandStatement statement = new CommandStatement(getSSHConnectionInteractive());
		return statement;
		
	}
	
	public CommandStatement createCommandInteractive4Key() throws Exception {
		CommandStatement statement = new CommandStatement(getSSHConnectionInteractive4Key());
		return statement;
		
	}
	
	public boolean isAuthSuccess(){
		return isAuthenticated;
	}

	/**
	 * @param host the host to set
	 */
	public void setHost(String host) {
		this.host = host;
	}

	/**
	 * @param port the port to set
	 */
	public void setPort(int port) {
		this.port = port;
	}

	/**
	 * @param user the user to set
	 */
	public void setUser(String user) {
		this.user = user;
	}

	/**
	 * @param pwd the pwd to set
	 */
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
}

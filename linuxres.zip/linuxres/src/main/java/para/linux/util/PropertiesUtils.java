package para.linux.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import com.paraview.base.jar.core.common.log.AppLog;
import com.paraview.base.jar.core.common.log.AppLogFactory;


public class PropertiesUtils {
	
	private static AppLog log = AppLogFactory.getLog(PropertiesUtils.class);
	public static Properties p =  null;
	
	static{
		InputStream inputStream = PropertiesUtils.class.getResourceAsStream("/linux_command.properties");
		p = new Properties();    
		try {
			if(inputStream==null){
				log.error("Loading command.properties,ImputStream Object is null");
			}else{
				p.load(inputStream);
			}
	    } catch (IOException e1) {    
	    	log.error("Loading command.properties Error:"+e1); 
		}    
	}
	
	  private static String replaceFirst(String src, String pattern, String replaceTo)
	  {
	    int pos;
	    String result = src;
	    if ((src == null) || (pattern == null) || (replaceTo == null)) {
	      throw new IllegalArgumentException("replace string error: src, pattern, replaceTo cannot be null.");
	    }

	    if ((pos = src.indexOf(pattern)) != -1) {
	      StringBuffer str = new StringBuffer();
	      str.append(src.substring(0, pos));
	      str.append(replaceTo);
	      str.append(src.substring(pos + pattern.length()));
	      result = str.toString();
	    }
	    return result;
	  }
	  
	  private static String replaceAll(String src, String pattern, String replaceTo)
	  {
	    String result = src;
	    while (result.indexOf(pattern) != -1)
	      result = replaceFirst(result, pattern, replaceTo);

	    return result;
	  }
	  
	public static String getResourceValue(String name,String... params){
		if(p==null){
			return "loading command properties file failuer...";
		}
		String retStr = p.getProperty(name);
		if(retStr!=null && params!=null && params.length>0){
			for (int i = 0; i < params.length; i++) {
				retStr=replaceAll(retStr, "{"+i+"}", params[i]);
			}
		}
		return retStr;
	}
	
	public static void main(String[] args) {
		System.out.println(PropertiesUtils.getResourceValue("cmd.add", "pengy"));
	}
	
	
}

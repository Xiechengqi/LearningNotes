/**
 * 
 */
package para.linux.util;

import para.util.LogUtil;



public class TelnetStatement {

	private static TelnetConnection telnetConn;
	private String sudoDir = PropertiesUtils.getResourceValue("sudo.homdDir");
	
	public TelnetStatement(String ip,int port, String accountNo, String password) {
		this.telnetConn = new TelnetConnection(ip, port, accountNo, password);
	}
	
	public TelnetStatement(String ip, String accountNo, String password) {
		this.telnetConn = new TelnetConnection(ip, 23,accountNo, password);
	}



	/*以下这段代码在判断返回值，是否操作成功方面是有巨大的问题的，如修改帐号的组的，返回错误，但实际在操作系统上已经修改完成*/
	private String execCommand(String cmd, String operType)
			throws Exception {
		LogUtil.printCommandMsg("", "", cmd);
		if (telnetConn == null) {
			return "Connection Exception";
		}
		String retStr = "";
		String rs = telnetConn.execCommand(cmd);
		if (rs != null && !"".equals(rs.trim()) && rs.length() > 1) {
			rs = rs.substring(1);
			String[] strArr = rs.split("\n");
			if (strArr != null && strArr.length > 0) {
				if (operType.equals("2")) {
					if (strArr[strArr.length - 2].toLowerCase().indexOf(
								"successfully") != -1) {
						return "SUCCESS";
					} else {
						for (int i = 1; i < strArr.length - 1; i++) {
							retStr += strArr[i] + " ";
						}
					}
				} else {
					if (strArr.length < 4) {
						if (strArr.length == 3) {
							return strArr[1];
						} else if (strArr.length == 2) {
							return "SUCCESS";
						} else {
							return "正在处理,但无返回..";
						}
					} else {
						for (int i = 1; i < strArr.length - 1; i++) {
							if (i < strArr.length - 2) {
								retStr += strArr[i] + ",";
							} else {
								retStr += strArr[i];
							}
						}
					}
				}
			}
		}
		if(retStr!=null && "0".equals(retStr.trim())){
			return "SUCCESS";
		}
		return retStr;
	}

	public String addUser(String name, String pwd, String groups,
						  boolean isSudo, boolean isPrimaryGroupExist) throws Exception {
		String flag = null;
		if (telnetConn == null) {
			return "Connection Object is Null";
		} else {
			CommandStatement cs = new CommandStatement(null);
			String newPasswd = cs.convertPwd(pwd);
			String cmd = PropertiesUtils.getResourceValue("cmd.addUser", newPasswd, name);
			if (isSudo) {
				cmd = sudoDir + " " + cmd;
			}
			if (groups != null && !"".equals(groups)) {
				cmd += " -G " + groups;
			}
			if (isPrimaryGroupExist) {
				cmd += " -g " + name;
			}
			return execCommand(cmd, "1");
		}
	}

	// update user pwd
	public String modifyUserPwd(String name, String pwd,boolean isSudo) throws Exception {
		String flag = "SUCCESS";
		if (telnetConn == null) {
			return "Connection Object is Null"; 
		} else {
			String cmd = "";
			String cmd1 = "";
			if(pwd.indexOf("\\")>-1 || pwd.indexOf("'")>-1){
				pwd = pwd.replaceAll("\\\\","\\\\\\\\");
				pwd = pwd.replaceAll("'", "\\\\0047");
				pwd = "'"+pwd+"'";
				cmd = PropertiesUtils.getResourceValue("cmd.changePwd.open", pwd,name);
				cmd1 = PropertiesUtils.getResourceValue("cmd.sudo.changePwd.open", pwd,name);
			}else{
			
				pwd = "'"+pwd+"'";
				cmd = PropertiesUtils.getResourceValue("cmd.changePwd", pwd,name);
				cmd1 = PropertiesUtils.getResourceValue("cmd.sudo.changePwd", pwd,name);
			}
			if (!isSudo) {
				flag = execCommand(cmd, "2");
			} else {
				flag = execCommand(cmd1, "2");
			}
			if(flag!=null && flag.toLowerCase().indexOf("changing password for")!=-1 || flag.toLowerCase().indexOf("successfully")!=-1){
				return "SUCCESS";
			}
			return flag;
		}
	}
	
	//update user group
	public String modifyUserGroup(String name,String groups,boolean isSudo) throws Exception{
		String cmd = PropertiesUtils.getResourceValue("cmd.changeUserGroup");
		if(isSudo){
			if(groups==null || groups.equals("")){
				cmd = sudoDir+" "+cmd+" '' "+name;
			}else{
				cmd = sudoDir+" "+cmd+" "+groups+" "+name;
			}
		}else{
			if(groups==null || groups.equals("")){
				cmd = cmd+" '' "+name;
			}else{
				cmd = cmd+" "+groups+" "+name;
			}
		}
		return execCommand(cmd,"1");
	}
	
	// delete User
	public String deleteUser(String name, boolean isSudo)
			throws Exception {
		String cmd = PropertiesUtils.getResourceValue("cmd.deleteUser",name);
		if(isSudo){
			cmd = sudoDir+" "+cmd;
		}
		String rs = execCommand(cmd, "1");
		if(rs==null || "".equals(rs.trim())){
			rs = execCommand(cmd, "1");
		}else{
			if (rs.toLowerCase().indexOf("userdel: unknown user") != -1 || rs.toLowerCase().indexOf("no crontab for") != -1 ||
					rs.toLowerCase().indexOf("does not exist") != -1 ||
					rs.toLowerCase().indexOf("successfully") != -1) {
				return "SUCCESS";
			}
		}
		return rs;
	}
	
	
	public String addGroup(String groupName,boolean isSudo)throws Exception {
			String cmd = PropertiesUtils.getResourceValue("cmd.addGroup",groupName);
			if(isSudo){
				cmd = sudoDir+" "+cmd;
			}
			return execCommand(cmd, "1");
	}
	

	public String deleteGroup(String groupName, boolean isSudo)
			throws Exception {
		String cmd = PropertiesUtils.getResourceValue("cmd.deleteGroup",groupName);
		if(isSudo){
			cmd = sudoDir+" "+cmd;
		}
		String rs= execCommand(cmd, "1");
		if(rs==null || "".equals(rs.trim())){
			rs = execCommand(cmd,  "1");
		}else{
			if(rs.toLowerCase().indexOf("groupdel: unknown group")!=-1){
				return "SUCCESS";
			}
		}
		return rs;
	}

	
	public String suppendUser(String accountNo, boolean isSudo) throws Exception {
		String cmd = PropertiesUtils.getResourceValue("cmd.suppendUser",accountNo);
		if(isSudo){
			cmd = sudoDir+" "+cmd;
		}
		String rs= execCommand(cmd,"1");
		if(rs==null || "".equals(rs.trim())){
			rs = execCommand(cmd,"1");
		}else{
			if(rs.indexOf("already locked")!=-1){
				return "SUCCESS";
			}
		}
		return rs;
	}

	public String restoreUser(String accountNo, boolean isSudo) throws Exception {
		String cmd = PropertiesUtils.getResourceValue("cmd.restoreUser",accountNo);
		if(isSudo){
			cmd = sudoDir+" "+cmd;
		}
		String rs= execCommand(cmd,"1");
		if(rs==null || "".equals(rs.trim())){
			rs = execCommand(cmd,"1");
		}else{
			if(rs.indexOf("Cannot unlock")!=-1){
				return "SUCCESS";
			}
		}
		return rs;
	}

	

}

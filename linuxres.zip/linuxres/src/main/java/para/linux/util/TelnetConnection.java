package para.linux.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;

import org.apache.commons.net.telnet.TelnetClient;

import para.util.LogUtil;

import com.paraview.base.jar.core.common.log.AppLog;
import com.paraview.base.jar.core.common.log.AppLogFactory;

public class TelnetConnection {
	
	private static AppLog log = AppLogFactory.getLog(TelnetConnection.class);
	
	private TelnetClient telnet;
	private InputStream in;
	private PrintStream out;
	private char prompt ;
	
	private String host = "";
	private int port = 23;
	private String user;
	private String password;
		
	public TelnetConnection(){}
	
	public TelnetConnection(String host,int port,String user,String password){
		this.host = host;
		this.port = port;
		this.user = user;
		this.password = password;
		//this.prompt = user.equals( "root" )?'#':'$';  
	}
	
	/**
	 * login
	 * @param host
	 * @param port
	 * @param user
	 * @param password
	 */
	public String connection(String host,int port, String user, String password) {
		try {
			telnet = new TelnetClient("VT100");
			telnet.setDefaultTimeout(Integer.parseInt(PropertiesUtils.getResourceValue("telnet.connectTime")));
			telnet.connect(host, port);
			in = telnet.getInputStream();
			out = new PrintStream(telnet.getOutputStream());
			readUntil("ogin: ",0);
			System.out.println(user);
			write(user);
			readUntil("assword: ",0);
			write(password);
			System.out.println(password);
		} catch (Exception e) {
			log.error("para.linux.util.TelnetConnect->connection("+host+","+port+","+user+","+password+") error:"+e);
			return e.getLocalizedMessage();
		}
		return "0";
	}
	
	
	
	public String modifyPwd(String cmd,String pwd){
		this.connection(host, port, user, password);
		try {
			write(cmd);
			readUntil(prompt + " ",0);
			write(pwd);
			readUntil(prompt + " ",0);
			write(pwd);
			prompt = '#';
			return readUntil(prompt + " ",1);
		} catch (Exception e) {
			log.error("para.linux.util.TelnetConnect->modifyPwd("+cmd+","+pwd+") error:"+e);
			return e.getLocalizedMessage();
		}finally{
			this.disconnect();
		}
	}
	
	
	public String readUntil(String pattern,int type) {
		StringBuffer strSB = new StringBuffer();
		StringBuffer sb = new StringBuffer();
		try {
			char lastChar = pattern.charAt(pattern.length() - 1);
			boolean found = false;
			char ch = (char) in.read();
			while (true) {
//				System.out.print(new String(String.valueOf(ch).getBytes("UTF-8"),"GB2312"));
				if(type==1){
					sb.append(ch);
					if(sb.toString().startsWith("$") || sb.toString().startsWith("#") || sb.toString().startsWith(">")){
						strSB.append(ch);
					}else{
						sb.deleteCharAt(0);
					}
				}
				if (ch == lastChar) {
					if (sb.toString().endsWith(pattern)) {
						return new String(sb.toString().getBytes("iso-8859-1"),"gb2312");
					}
				}
				ch = (char) in.read();
			}
		} catch (IOException e) {
			log.error("error: " + e.getMessage());
			if(e.getLocalizedMessage().indexOf("Read timed out")==-1){
				log.error("para.linux.util.TelnetConnect->readUntil("+pattern+","+type+") error:"+e);
				return e.getLocalizedMessage();
			}
			e.printStackTrace();
		}
		try {
//			System.out.println(""+strSB.toString());
			return new String(strSB.toString().getBytes("iso-8859-1"),"UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			return e.getLocalizedMessage();
		}
	}
	public void write(String value) {
		out.println(value);
		out.flush();
//		System.out.println(new String(value.getBytes("iso-8859-1"),"UTF-8"));
	}
	
	public String execCommand(String command) {
		LogUtil.printCommandMsg("", "", command);
		this.connection(host, port, user, password);
		try {
			write(command);
			return readUntil(prompt + "",1);
		} catch (Exception e) {
			log.error("para.linux.util.TelnetConnect->execCommand("+command+") error:"+e);
			return e.getLocalizedMessage();
		}finally{
			this.disconnect();
		}
	}
	
	public String su(String username,String pwd) {
		this.connection(host, port, user, password);
		try {
			write("su "+username);
			readUntil("Password: ",0);
			write(pwd);
			readUntil(prompt + " ",0);
			prompt = '#';
			return readUntil(prompt + " ",1);
		} catch (Exception e) {
			return e.getLocalizedMessage();
		}finally{
			this.disconnect();
		}
	}
	
	public void disconnect() {
		try {
			if(in!=null)
				in.close();
			if(out!=null)
				out.close();
			if(!telnet.isConnected()){
				telnet.disconnect();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public TelnetStatement createCommand(){
		TelnetStatement statement = new TelnetStatement(host,port,user, password);
		return statement;
	}
	
	public static void main(String[] args) {
		TelnetConnection obj = null;
		try {
			obj = new TelnetConnection("192.168.1.33",23, "test","tivoli");
			String rs = obj.execCommand("whoami");
			
			
//			obj.execCommand("sudo passwd pengy1");
//			System.out.println(obj.modifyPwd("sudo passwd pengy5","tivoli"));
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			obj.disconnect();
		}
	}


}

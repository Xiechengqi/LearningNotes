package para.linux.util;

import para.account.bean.RemoteService;

public class ObjectCheck {

    public static boolean checkParam(RemoteService rserver) {

        if (trimIsEmpty(rserver.getConnType())) {
            return false;
        }
        if (trimIsEmpty(rserver.getServerIp())) {
            return false;
        }
        if (trimIsEmpty(rserver.getLoginName())) {
            return false;
        }
        return true;
    }

    private static boolean trimIsEmpty(String para) {
        if (para == null || "".equals(para.trim())) {
            return true;
        }
        return false;
    }
}

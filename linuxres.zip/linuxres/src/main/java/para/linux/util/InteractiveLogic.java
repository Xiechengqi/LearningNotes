package para.linux.util;

import java.io.IOException;

import ch.ethz.ssh2.InteractiveCallback;

public class InteractiveLogic implements InteractiveCallback {
	
	private String result;
	
	public InteractiveLogic(String result) {
		this.result = result;
		
	}

	public String[] replyToChallenge(String name, String instruction, int numPrompts, String[] prompt, boolean[] echo) throws IOException
	{
		String[] prompts = new String[numPrompts];

		for (int i = 0; i < numPrompts; i++)
		{

			prompts[i] = result;
		}

		return prompts;
	}

}

package para.linux.util;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import para.account.bean.Account;
import para.account.bean.Group;
import para.account.bean.RemoteService;
import para.util.PageUtil;
import para.util.StringUtil;

import com.paraview.base.jar.core.common.log.AppLog;
import com.paraview.base.jar.core.common.log.AppLogFactory;

public class TelnetQuery {

	private static AppLog log = AppLogFactory.getLog(TelnetQuery.class);
	
	private static TelnetConnection telnetConn ;
	
	private static boolean isFolderExist(String folder, String[] a) {
		boolean isMatch = false;
		for (int i = 0; i < a.length; i++) {
			if (folder.equals(a[i])) {
				return true;
			}
		}
		return isMatch;
	}
	/**
	 * 查询帐号（分页）
	 * @param server
	 * @return
	 */
	public synchronized final List<Account> queryAllAccount(RemoteService server){
		String cmd =  PropertiesUtils.getResourceValue("cmd.gcUser.page",String.valueOf(PageUtil.calculateCurrentPageIndex(server)),String.valueOf(PageUtil.calculateCurrentPageSize(server)));
		String rs = telnetConn.execCommand(cmd);
		return this.executeResultAccount(rs, cmd);
	}
	/**
	 * 查询帐号(不分页)
	 * @return
	 */
	public synchronized final List<Account> queryAllAccount(){
		String cmd =  PropertiesUtils.getResourceValue("cmd.gcUser");
		String rs = telnetConn.execCommand(cmd);
		return this.executeResultAccount(rs, cmd);
	}
	/**
	 * 处理查询结果
	 * @param rs
	 * @param cmd
	 * @return
	 */
	private List<Account> executeResultAccount(String rs ,String cmd) {
		List<Account> list = new ArrayList<Account>();
		if(rs!=null && !"".equals(rs.trim()) && rs.length()>1){
			rs = rs.substring(1);
			String[] strArr = rs.split("\n");
			if(strArr!=null && strArr.length>0){
				for(String str : strArr){
					if(str.trim().indexOf(cmd)!=-1 || str.trim().startsWith("[") || str.trim().startsWith("$")|| str.trim().startsWith(">")|| str.trim().startsWith("#")){
						continue;
					}
					if(str.indexOf("@")!=-1 || str.indexOf("#")!=-1 || str.indexOf("$")!=-1  || str.indexOf(">")!=-1){
						continue;
					}
					Account obj = new Account();
					obj.setAccountNo(str.trim());
					if(!list.contains(obj)){
						list.add(obj);	
					}
				}
			}
		}
		return list;

	}
	
	public synchronized final boolean isExitAccount(String accountNo){
		String cmd =  PropertiesUtils.getResourceValue("cmd.findUser",accountNo);
		List<Account> list = new ArrayList<Account>();
		String rs = telnetConn.execCommand(cmd);
		if(rs!=null && !"".equals(rs.trim()) && rs.length()>1){
			rs = rs.substring(1);
			String[] strArr = rs.split("\n");
			if(strArr!=null && strArr.length>0){
				for(String str : strArr){
					if(str.trim().indexOf(cmd)!=-1 || str.trim().startsWith("[") || str.trim().startsWith("$")|| str.trim().startsWith(">")|| str.trim().startsWith("#")){
						continue;
					}
					if(str.indexOf("@")!=-1 || str.indexOf("#")!=-1 || str.indexOf("$")!=-1  || str.indexOf(">")!=-1){
						continue;
					}
					if(str.trim().equals(accountNo)){
						return true;
					}
				}
			}
		}
		return false;
	}
	
	public synchronized final boolean isExitGroup(String groupName){
		String cmd =  PropertiesUtils.getResourceValue("cmd.findGroup",groupName);
		List<Group> list = new ArrayList<Group>();
		String rs = telnetConn.execCommand(cmd);
		if(rs!=null && !"".equals(rs.trim()) && rs.length()>1){
			rs = rs.substring(1);
			String[] strArr = rs.split("\n");
			if(strArr!=null && strArr.length>0){
				for(String str : strArr){
					if(str.trim().indexOf(cmd)!=-1 || str.trim().startsWith("[") || str.trim().startsWith("$")|| str.trim().startsWith(">")|| str.trim().startsWith("#")){
						continue;
					}
					if(str.indexOf("@")!=-1 || str.indexOf("#")!=-1 || str.indexOf("$")!=-1  || str.indexOf(">")!=-1){
						continue;
					}
					if(str.trim().equals(groupName)){
						return true;
					}
				}
			}
		}
		return false;
	}

	/**
	 * 查询资源组信息 不分页查询
	 * @return
	 */
	public synchronized final List<Group> queryAllGroup(){
		String cmd =  PropertiesUtils.getResourceValue("cmd.gcGroup");
		log.debug("command : "+ cmd);
		String rs = telnetConn.execCommand(cmd);
		return this.executeResultGroup(rs, cmd);
	}
	/**
	 * 分页查询资源组信息
	 * @param server
	 * @return
	 */
	public synchronized final List<Group> queryAllGroup(RemoteService server){
		String cmd =  PropertiesUtils.getResourceValue("cmd.gcGroup.page",String.valueOf(PageUtil.calculateCurrentPageIndex(server)),String.valueOf(PageUtil.calculateCurrentPageSize(server)));
		log.debug("command : "+ cmd);
		String rs = telnetConn.execCommand(cmd);
		return this.executeResultGroup(rs, cmd);
	}

	/**
	 * 处理查询结果信息
	 * @param rs
	 * @param cmd
	 * @return
	 */
	private List<Group> executeResultGroup(String rs, String cmd){
		List<Group> list = new ArrayList<Group>();
		if(rs!=null && !"".equals(rs.trim()) && rs.length()>1){
			rs = rs.substring(1);
			String[] strArr = rs.split("\n");
			if(strArr!=null && strArr.length>0){
				for(String str : strArr){
					if(str.trim().indexOf(cmd)!=-1 || str.trim().startsWith("[") || str.trim().startsWith("$")|| str.trim().startsWith(">")|| str.trim().startsWith("#")){
						continue;
					}
					if(str.indexOf("@")!=-1 || str.indexOf("#")!=-1 || str.indexOf("$")!=-1  || str.indexOf(">")!=-1){
						continue;
					}
					Group obj = new Group();
					obj.setGroupName(str.trim());
					if(!list.contains(obj)){
						list.add(obj);	
					}
				}
			}
		}
		return list;
	}
	
	public synchronized final  List<Group>  queryGroupByNo(String accountNo) {
		List<Group> list = new ArrayList<Group>();
		String cmd = PropertiesUtils.getResourceValue("cmd.queryGroupByNo",accountNo);
		String rs = telnetConn.execCommand(cmd);
		if(rs!=null && !"".equals(rs.trim())){
			rs = rs.substring(1);
			String[] strArr = rs.split("\n");
			if(strArr!=null && strArr.length>0){
				for(String str : strArr){
					if(str.trim().indexOf(accountNo+"@")!=-1 || str.trim().indexOf(cmd)!=-1 || str.trim().startsWith("[") || str.trim().startsWith("$")|| str.trim().startsWith(">")|| str.trim().startsWith("#")){
						continue;
					}
					rs = str;
				}
			}
			byte[] byteAttr;
			try {
				byteAttr = rs.getBytes("UTF-8");
				log.error("资源组内容[" + rs + "] 这个不是错误");
				//某些平台下带\r,有些平台下不带\r,类unix服务器和windows服务器对文件的结尾是不同的，原来的开发人员一直都不明白
				String lastSting = new String(byteAttr, byteAttr.length - 1, 1);
				if (!"\r".equals(lastSting)) {
					rs = new String(byteAttr, 0, byteAttr.length).trim();
					log.error("最后一个符号不是 r,所以不截取");
				} else {
					rs = new String(byteAttr, 0, byteAttr.length - 1).trim();
					log.error("最后一个符号是 r,所有截取");
				}
				if(rs.indexOf(":")!=-1){
					rs = rs.substring(rs.indexOf(":")+2);	
				}
				 String[] rsArr = rs.split(" ");
					if(rsArr!=null && rsArr.length>0){
						for(String str : rsArr){
							Group group = new Group();
							group.setGroupName(str);
							if(!list.contains(group)){
								list.add(group);	
							}
						}
					}
			} catch (UnsupportedEncodingException e) {
				log.error("para.linux.util.TelnetQuery->queryGroupByNo("+accountNo+") Error:"+e);
				return list;
			}
		}
		return list;
	}

	public synchronized final  String  queryAccountByNo(String accountNo) {
		String cmd = PropertiesUtils.getResourceValue("cmd.queryGroupByNo",accountNo);
		String rs = telnetConn.execCommand(cmd);
		if(rs!=null && !"".equals(rs.trim())){
			rs = rs.substring(1);
			String[] strArr = rs.split("\n");
			if(strArr!=null && strArr.length>0){
				for(String str : strArr){
					if(str.trim().indexOf(accountNo+"@")!=-1 || str.trim().indexOf(cmd)!=-1 || str.trim().startsWith("[") || str.trim().indexOf("$")!=-1 || str.trim().startsWith(">")|| str.trim().indexOf("#")!=-1){
						continue;
					}
					rs = str;
				}
			}
			byte[] byteAttr;
			try {
				byteAttr = rs.getBytes("UTF-8");
				rs = new String(byteAttr,0,byteAttr.length-1).trim();
				if(rs.indexOf(":")!=-1){
					rs = rs.substring(rs.indexOf(":")+2);	
				}
			} catch (UnsupportedEncodingException e) {
				log.error("para.linux.util.TelnetQuery->queryAccountByNo("+accountNo+") Error:"+e);
				return e.getLocalizedMessage();
			}
		}
		return rs;
	}
	
	public synchronized final  List<String> queryAccountGroup() {
		String cmd = "cat /etc/group";
		List<String> list = new ArrayList<String>();
		String rs = telnetConn.execCommand(cmd);
		if(rs!=null && !"".equals(rs.trim()) && rs.length()>1){
			rs = rs.substring(1);
			String[] strArr = rs.split("\n");
			if(strArr!=null && strArr.length>1){
				for(String str : strArr){
					if(str.trim().indexOf(cmd)!=-1 || str.trim().startsWith("[") || str.trim().indexOf("$")!=-1 || str.trim().startsWith(">")|| str.trim().indexOf("#")!=-1){
						continue;
					}
					String groupName = str.substring(0,str.indexOf(":")).trim();
					String accountNos = str.substring(str.lastIndexOf(":")+1).trim();
					String value = groupName+":"+accountNos;
					if(!list.contains(value)){
						list.add(value);	
					}
				}
			}
		}
		return list;
	}
	
	public synchronized final boolean queryGroupByName(String groupName){
		String cmd = "cat /etc/group|grep "+groupName;
		List<String> list = new ArrayList<String>();
		String rs = telnetConn.execCommand(cmd);
		if(rs!=null && !"".equals(rs.trim()) && rs.length()>=1){
			rs = rs.substring(1);
			String[] strArr = rs.split("\n");
			if(strArr!=null && strArr.length>0){
				for(String str : strArr){
					if(str.trim().indexOf(cmd)!=-1 || str.trim().startsWith("[") || str.trim().indexOf("$")!=-1 || str.trim().startsWith(">")|| str.trim().indexOf("#")!=-1){
						continue;
					}
					String[] strArray = str.split(":");
					if(strArray[0].trim().toLowerCase().equals(groupName.trim().toLowerCase())){
						return true;
					}
				}
			}else{
				return false;
			}
		}
		return false;
	}
	
	public synchronized final String queryAccountByGoupName(String groupName){
		String cmd = "cat /etc/group|grep "+groupName;
		String uCmd = "cat /etc/passwd ";
		List<String> list = new ArrayList<String>();
		String rs = telnetConn.execCommand(cmd);
		boolean isGroupExist = false;
		if(rs!=null && !"".equals(rs.trim()) && rs.length()>1){
			rs = rs.substring(1);
			String[] strArr = rs.split("\n");
			if(strArr!=null && strArr.length>0){
				for(String str : strArr){
					if(str.trim().indexOf(cmd)!=-1 || str.trim().startsWith("[") || str.trim().indexOf("$")!=-1 || str.trim().startsWith(">")|| str.trim().indexOf("#")!=-1){
						continue;
					}
					String[] strArray = str.split(":");
					if(!strArray[0].trim().toLowerCase().equals(groupName.trim().toLowerCase())) continue;
					isGroupExist=true;
					String accountNos = "";
					if(strArray.length > 3 && strArray[3]!=null && !strArray[3].trim().equals("")){
						accountNos = strArray[3].trim()+",";
					}
//					else{
//						continue;
//					}
					if(strArray.length > 2){
						String GID = strArray[2];
//						uCmd += GID;
						String uStr = telnetConn.execCommand(uCmd);
						uStr = uStr.substring(1);
						String[] uStrs = uStr.split("\n");
						for(int i=0;i<uStrs.length;i++){
							if(uStrs[i].trim().indexOf(cmd)!=-1 || uStrs[i].trim().startsWith("[") || str.trim().indexOf("$")!=-1 || str.trim().startsWith(">")|| str.trim().indexOf("#")!=-1){
								continue;
							}
							String[] uArray = uStrs[i].split(":");
							if(uArray.length > 3 && uArray[3].equals(GID)){
								accountNos += uArray[0]+",";
							}
						}
						if(accountNos != ""){
							list.add(accountNos.trim());
						}
						break;
					}
				}
			}
		}
		String retValue = StringUtil.listToStr(list, ",");
		if (retValue == null || "".equals(retValue)) {
			if (isGroupExist) {
				return CommandQuery.EXITBUTNOACCOUNT__;
			} else {
				return retValue;
			}
		} else {
			return retValue;
		}
	}
	
	public String queryAccountByUID(String uid) {
		String cmd = "groups "+uid;
		String rs = telnetConn.execCommand(cmd);
		if(rs!=null && !"".equals(rs.trim())){
			rs = rs.substring(1);
			String[] strArr = rs.split("\n");
			if(strArr!=null && strArr.length>0){
				for(String str : strArr){
					if(str.trim().indexOf(cmd)!=-1 || str.trim().startsWith("[") || str.trim().indexOf("$")!=-1 || str.trim().startsWith(">")|| str.trim().indexOf("#")!=-1){
						continue;
					}
					rs = str;
				}
			}
			byte[] byteAttr;
			try {
				byteAttr = rs.getBytes("UTF-8");
				rs = new String(byteAttr,0,byteAttr.length-1).trim();
			} catch (UnsupportedEncodingException e) {
				return rs;
			}
			
		}
		return rs;
	}
	
	public static TelnetQuery getInstance(String ip,int port, String accountNo, String password){
		telnetConn = new TelnetConnection(ip,port,accountNo,password);
		return (new TelnetQuery());
	}
	
	public static void main(String[] arg) {
//		TelnetQuery aixObj = TelnetQuery.getInstance("192.168.1.90", "oscuser", "tivoli");
		
		TelnetQuery solairsObj = TelnetQuery.getInstance("192.168.1.57", 22,"oscuser", "tivoli");
//		List<String> list = solairsObj.queryAccountGroup();
//		for(String str : list){
//			System.out.println(str);
//		}
//		System.out.println(solairsObj.queryGroupByName("pengy5"));
//		List<String> list = solairsObj.queryAccountByGroup("other");
//		for(String str : list){
//			System.out.println(str);
//		}
		String strSolaris = solairsObj.queryAccountByUID("oscuser");
		try {
			System.out.println(new String(strSolaris.getBytes(),"UTF-8"));
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
//		List<String> listAix = aixObj.queryAccountGroup();
//		for(String str : listAix){
//			System.out.println(str);
//		}
//		System.out.println(aixObj.queryGroupByName("root"));
//		List<String> listAix = aixObj.queryAccountByGroup("system");
//		System.out.println(listAix.size());
//		for(String str : listAix){
//			System.out.println(str);
//		}
			
//		String strAix = aixObj.queryAccountByUID("oscuser");
//		try {
//			System.out.println(new String(strAix.getBytes(),"UTF-8"));
//		} catch (UnsupportedEncodingException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
			
		
		
	}
}

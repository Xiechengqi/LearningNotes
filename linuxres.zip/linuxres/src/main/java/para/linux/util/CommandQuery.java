package para.linux.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import para.account.bean.Account;
import para.account.bean.Group;
import para.account.bean.RemoteService;
import para.util.LogUtil;
import para.util.PageUtil;
import para.util.StringUtil;
import ch.ethz.ssh2.Connection;
import ch.ethz.ssh2.Session;
import ch.ethz.ssh2.StreamGobbler;

import com.paraview.base.jar.core.common.log.AppLog;
import com.paraview.base.jar.core.common.log.AppLogFactory;

public class CommandQuery {
	
	private static AppLog log = AppLogFactory.getLog(CommandQuery.class);
	
	private static  String hostIp = null;
	private static  String name = null;
	private static  String pwd = null;
	private static String keyUrl = null;
	private static int port = 22;
	public static final String EXITBUTNOACCOUNT__="EXITBUTNOACCOUNT__";
	public CommandQuery() {
	}
	
	public CommandQuery(String hostIp, int port, String name, String pwd,
			String keyUrl) {
		CommandQuery.hostIp = hostIp;
		CommandQuery.port = port;
		CommandQuery.name = name;
		CommandQuery.pwd = pwd;
		CommandQuery.keyUrl = keyUrl;
	}
	public CommandQuery(String hostIp,int port,String name,String pwd ) {
		CommandQuery.hostIp = hostIp;
		CommandQuery.port = port;
		CommandQuery.name = name;
		CommandQuery.pwd = pwd;
	}
	public CommandQuery(String hostIp,String name,String pwd ) {
		CommandQuery.hostIp = hostIp;
		CommandQuery.name = name;
		CommandQuery.pwd = pwd;
	}
	
	private static boolean isFolderExist(String folder, String[] a) {
		boolean isMatch = false;
		for (int i = 0; i < a.length; i++) {
			if (folder.equals(a[i])) {
				return true;
			}
		}
		return isMatch;
	}

	private String execCommand(String cmd) {
		LogUtil.printCommandMsg("", "", cmd);
		Connection conn = null;
		Session sess =null;
		InputStream sOut =null;
		try {
			conn =  new Connection(hostIp,port);
			conn.connect();
			boolean isAuthenticated = false;
			if (conn.isAuthMethodAvailable(name, "keyboard-interactive")){
				InteractiveLogic il = new InteractiveLogic(pwd);
				isAuthenticated = conn.authenticateWithKeyboardInteractive(name, il);
				if(!isAuthenticated){
					isAuthenticated = conn.authenticateWithPassword(name, pwd);
				}
			}else{
				isAuthenticated = conn.authenticateWithPassword(name, pwd);
			}
			if(isAuthenticated){
				sess = conn.openSession();

				sess.execCommand(cmd);
				sOut = new StreamGobbler(sess.getStdout());

				StringBuffer retSb = new StringBuffer();
				byte[] buffer = new byte[1024];
				int length = 0;
				while((length = sOut.read(buffer))!=-1){
					log.debug("执行命令:" + cmd + "  ");
					log.info("执行后的buffer长度:" + length + "  ");
					if (length > 0) {
						String rs = new String(buffer, 0, length);
						log.info("每次字符长度："+rs);
						retSb.append(rs);
					}else {
						break;
					}
				}
				log.info("总共字符长度:"+retSb.toString());
				return retSb.toString();
			}
		} catch (IOException e) {
			log.error("para.linux.util.CommandQuery->execCommand("+cmd+") Error:"+e);
			return null;//e.getLocalizedMessage();
		}finally{
			if (sOut != null) {
				try {
					sOut.close();
				} catch (IOException e) {
					e.printStackTrace();
					log.error("close StreamGobbler stream error!:" + e);
				}
				sOut = null;
			}
			if (sess != null) {
				sess.close();
				sess = null;
			}
			if (conn != null) {
				conn.close();
				conn = null;
			}
		}
		return null;

	}
	/**
	 * 不分页查询帐号
	 * @return
	 */
	public synchronized final List<Account> queryAllAccount(){
		String cmd = PropertiesUtils.getResourceValue("cmd.gcUser");
		log.debug("command: " + cmd);
		String rs = execCommand(cmd);
		return this.executeResultAccount(rs);
	}
	
	/**
	 * 不分页查询帐号
	 * @return
	 * @throws Exception 
	 */
	public synchronized final List<Account> queryAllAccount4Key() throws Exception{
		String cmd = PropertiesUtils.getResourceValue("cmd.gcUser");
		log.debug("command: " + cmd);
		String rs = execCommand4Key(cmd);
		return this.executeResultAccount(rs);
	}
	/**
	 * 需要分页查询帐号
	 * @param server
	 * @return
	 */
	public synchronized final List<Account> queryAllAccount(RemoteService server){
		String cmd = PropertiesUtils.getResourceValue("cmd.gcUser.page",String.valueOf(PageUtil.calculateCurrentPageIndex(server)),String.valueOf(PageUtil.calculateCurrentPageSize(server)));
		log.debug("command: " + cmd);
		String rs = execCommand(cmd);
		return this.executeResultAccount(rs);
	}
	
	/**
	 * 需要分页查询帐号
	 * @param server
	 * @return
	 * @throws Exception 
	 */
	public synchronized final List<Account> queryAllAccount4Key(RemoteService server) throws Exception{
		String cmd = PropertiesUtils.getResourceValue("cmd.gcUser.page",String.valueOf(PageUtil.calculateCurrentPageIndex(server)),String.valueOf(PageUtil.calculateCurrentPageSize(server)));
		log.debug("command: " + cmd);
		String rs = execCommand4Key(cmd);
		return this.executeResultAccount(rs);
	}

	/**
	 * 处理结果信息
	 * @param rs
	 * @return
	 */
	private List<Account> executeResultAccount(String rs){
		List<Account> list = new ArrayList<Account>();
		if(rs!=null && !"".equals(rs.trim()) && rs.length()>1){
			String[] strArr = rs.split("\n");
			if(strArr!=null && strArr.length>0){
				for(String str : strArr){
					Account obj = new Account();
					obj.setAccountNo(str);
					if(!list.contains(obj)){
						list.add(obj);	
					}
				}
			}
		}
		return list;
	}
	
	public synchronized final  boolean isExitAccount(String accountNo) {
		String cmd = PropertiesUtils.getResourceValue("cmd.findUser",accountNo);
		List<Group> list = new ArrayList<Group>();
		String rs = execCommand(cmd);
		if(rs!=null && !"".equals(rs.trim()) && rs.length()>1){
			String[] strArr = rs.split("\n");
			if(strArr!=null && strArr.length>0){
				for(String str : strArr){
					if(str.equals(accountNo)){
						return true;
					}
				}
			}
		}
		return false;
	}
	
	public synchronized final  boolean isExitAccount4Key(String accountNo) throws Exception {
		String cmd = PropertiesUtils.getResourceValue("cmd.findUser",accountNo);
		List<Group> list = new ArrayList<Group>();
		String rs = execCommand4Key(cmd);
		if(rs!=null && !"".equals(rs.trim()) && rs.length()>1){
			String[] strArr = rs.split("\n");
			if(strArr!=null && strArr.length>0){
				for(String str : strArr){
					if(str.equals(accountNo)){
						return true;
					}
				}
			}
		}
		return false;
	}
	
	public synchronized final  boolean isExitGroup(String groupName) {
		String cmd = PropertiesUtils.getResourceValue("cmd.findGroup",groupName);
		List<Group> list = new ArrayList<Group>();
		String rs = execCommand(cmd);
		if(rs!=null && !"".equals(rs.trim()) && rs.length()>1){
			String[] strArr = rs.split("\n");
			if(strArr!=null && strArr.length>0){
				for(String str : strArr){
					if(str.equals(groupName)){
						return true;
					}
				}
			}
		}
		return false;
	}
	public synchronized final  boolean isExitGroup4Key(String groupName) throws Exception {
		String cmd = PropertiesUtils.getResourceValue("cmd.findGroup",groupName);
		List<Group> list = new ArrayList<Group>();
		String rs = execCommand4Key(cmd);
		if(rs!=null && !"".equals(rs.trim()) && rs.length()>1){
			String[] strArr = rs.split("\n");
			if(strArr!=null && strArr.length>0){
				for(String str : strArr){
					if(str.equals(groupName)){
						return true;
					}
				}
			}
		}
		return false;
	}
	/**
	 * 查询资源组信息 不分页
	 * @return
	 */
	public synchronized final  List<Group> queryAllGroup() {
		String cmd = PropertiesUtils.getResourceValue("cmd.gcGroup");
		log.debug("command :" + cmd);
		String rs = execCommand(cmd);
		return this.executeResultGroup(rs);
	}
	
	/**
	 * 查询资源组信息 不分页
	 * @return
	 * @throws Exception 
	 */
	public synchronized final  List<Group> queryAllGroup4Key() throws Exception {
		String cmd = PropertiesUtils.getResourceValue("cmd.gcGroup");
		log.debug("command :" + cmd);
		String rs = execCommand4Key(cmd);
		return this.executeResultGroup(rs);
	}
	/**
	 * 分页查询资源组信息
	 * @param server
	 * @return
	 */
	public synchronized final  List<Group> queryAllGroup(RemoteService server) {
		String cmd = PropertiesUtils.getResourceValue("cmd.gcGroup.page",String.valueOf(PageUtil.calculateCurrentPageIndex(server)),String.valueOf(PageUtil.calculateCurrentPageSize(server)));
		log.debug("command :" + cmd);
		String rs = execCommand(cmd);
		log.debug("在帐号中数据:" + rs);
		return this.executeResultGroup(rs);
	}
	
	/**
	 * 分页查询资源组信息
	 * @param server
	 * @return
	 * @throws Exception 
	 */
	public synchronized final  List<Group> queryAllGroup4Key(RemoteService server) throws Exception {
		String cmd = PropertiesUtils.getResourceValue("cmd.gcGroup.page",String.valueOf(PageUtil.calculateCurrentPageIndex(server)),String.valueOf(PageUtil.calculateCurrentPageSize(server)));
		log.debug("command :" + cmd);
		String rs = execCommand4Key(cmd);
		log.debug("在帐号中数据:" + rs);
		return this.executeResultGroup(rs);
	}
	
	/**
	 * 处理查询结果信息
	 * @param rs
	 * @return
	 */
	private List<Group> executeResultGroup(String rs){
		List<Group> list = new ArrayList<Group>();
		if(rs!=null && !"".equals(rs.trim()) && rs.length()>1){
			String[] strArr = rs.split("\n");
			if(strArr!=null && strArr.length>0){
				for(String str : strArr){
					Group group = new Group();
					group.setGroupName(str);
					if(!list.contains(group)){
						list.add(group);	
					}
				}
			}
		}
		if (list != null){
			log.debug("在接口中。。。总共条数：" + list.size());
			StringBuffer stringBuffer = new StringBuffer();
			for (int i = 0; i < list.size(); i++) {
				stringBuffer.append(list.get(i).getGroupName()+",");
			}
			log.debug("在接口中帐号：" + stringBuffer.toString());
		}

		return list;
	}
	
	public synchronized final  List<Group>  queryGroupByNo(String accountNo) {
		List<Group> list = new ArrayList<Group>();
		String cmd = PropertiesUtils.getResourceValue("cmd.queryGroupByNo",accountNo);
		String rs = execCommand(cmd);
		if(rs!=null && !"".equals(rs.trim())){
			byte[] byteAttr;
			try {
				byteAttr = rs.getBytes("UTF-8");
				rs = new String(byteAttr,0,byteAttr.length-1).trim();
				if(rs.indexOf(":")!=-1){
					rs = rs.substring(rs.indexOf(":")+2);	
				}
			    String[] strArr = rs.split(" ");
				if(strArr!=null && strArr.length>0){
					for(String str : strArr){
						Group group = new Group();
						group.setGroupName(str);
						if(!list.contains(group)){
							list.add(group);	
						}
					}
				}
			} catch (UnsupportedEncodingException e) {
				log.error("para.linux.util.CommandQuery->queryGroupByNo("+accountNo+") Error:"+e);
				return list;
			}
			
		}
		return list;
	}
	
	public synchronized final  List<Group>  queryGroupByNo4Key(String accountNo) throws Exception {
		List<Group> list = new ArrayList<Group>();
		String cmd = PropertiesUtils.getResourceValue("cmd.queryGroupByNo",accountNo);
		String rs = execCommand4Key(cmd);
		if(rs!=null && !"".equals(rs.trim())){
			byte[] byteAttr;
			try {
				byteAttr = rs.getBytes("UTF-8");
				rs = new String(byteAttr,0,byteAttr.length-1).trim();
				if(rs.indexOf(":")!=-1){
					rs = rs.substring(rs.indexOf(":")+2);	
				}
			    String[] strArr = rs.split(" ");
				if(strArr!=null && strArr.length>0){
					for(String str : strArr){
						Group group = new Group();
						group.setGroupName(str);
						if(!list.contains(group)){
							list.add(group);	
						}
					}
				}
			} catch (UnsupportedEncodingException e) {
				log.error("para.linux.util.CommandQuery->queryGroupByNo("+accountNo+") Error:"+e);
				return list;
			}
			
		}
		return list;
	}
	
	
	public synchronized final  String  queryAccountByNo(String accountNo) {
		String cmd = PropertiesUtils.getResourceValue("cmd.queryGroupByNo",accountNo);
		String rs = execCommand(cmd);
		if(rs!=null && !"".equals(rs.trim())){
			byte[] byteAttr;
			try {
				byteAttr = rs.getBytes("UTF-8");
				rs = new String(byteAttr,0,byteAttr.length-1).trim();
				if(rs.indexOf(":")!=-1){
					rs = rs.substring(rs.indexOf(":")+2);
				}
			} catch (UnsupportedEncodingException e) {
				log.error("para.linux.util.CommandQuery->queryAccountByNo("+accountNo+") Error:"+e);
				return null;//e.getLocalizedMessage();
			}
			
		}
		return rs;
	}
	
	public synchronized final  String  queryAccountByNo4Key(String accountNo) throws Exception {
		String cmd = PropertiesUtils.getResourceValue("cmd.queryGroupByNo",accountNo);
		String rs = execCommand4Key(cmd);
		if(rs!=null && !"".equals(rs.trim())){
			byte[] byteAttr;
			try {
				byteAttr = rs.getBytes("UTF-8");
				rs = new String(byteAttr,0,byteAttr.length-1).trim();
				if(rs.indexOf(":")!=-1){
					rs = rs.substring(rs.indexOf(":")+2);
				}
			} catch (UnsupportedEncodingException e) {
				log.error("para.linux.util.CommandQuery->queryAccountByNo("+accountNo+") Error:"+e);
				return null;//e.getLocalizedMessage();
			}
			
		}
		return rs;
	}
	
	public synchronized final String queryAccountByGoupName(String groupName){
		String cmd = "cat /etc/group|grep "+groupName;
		String uCmd = "cat /etc/passwd ";
		List<String> list = new ArrayList<String>();
		String rs = execCommand(cmd);
		boolean isGroupExist = false;
		if(rs!=null && !"".equals(rs.trim()) && rs.length()>1){
			String[] strArr = rs.split("\n");
			if(strArr!=null && strArr.length>0){
				for(String str : strArr){
					String[] strArray = str.split(":");
					if(!strArray[0].toLowerCase().equals(groupName.toLowerCase())) continue;
					isGroupExist = true;
					String accountNos = "";
					if(strArray.length > 3 && strArray[3]!=null && !strArray[3].trim().equals("")){
						accountNos = strArray[3].trim()+",";
					}
//					else{
//						continue;
//					}
					if(strArray.length > 2){
						String GID = strArray[2];
//						uCmd += GID;
						String uStr = execCommand(uCmd);
						String[] uStrs = uStr.split("\n");
						for(int i=0;i<uStrs.length;i++){
							String[] uArray = uStrs[i].split(":");
							if(uArray.length > 3 && uArray[3].equals(GID)){
								accountNos += uArray[0]+",";
							}
						}
						if(accountNos != ""){
							list.add(accountNos);
						}
						break;
					}
				}
			}
		}
		String retValue = StringUtil.listToStr(list, ",");
		if (retValue == null || "".equals(retValue)) {
			if (isGroupExist) {
				return EXITBUTNOACCOUNT__;
			} else {
				return retValue;
			}
		} else {
			return retValue;
		}
	}
	
	public synchronized final String queryAccountByGoupName4Key(String groupName) throws Exception{
		String cmd = "cat /etc/group|grep "+groupName;
		String uCmd = "cat /etc/passwd ";
		List<String> list = new ArrayList<String>();
		String rs = execCommand4Key(cmd);
		boolean isGroupExist = false;
		if(rs!=null && !"".equals(rs.trim()) && rs.length()>1){
			String[] strArr = rs.split("\n");
			if(strArr!=null && strArr.length>0){
				for(String str : strArr){
					String[] strArray = str.split(":");
					if(!strArray[0].toLowerCase().equals(groupName.toLowerCase())) continue;
					isGroupExist = true;
					String accountNos = "";
					if(strArray.length > 3 && strArray[3]!=null && !strArray[3].trim().equals("")){
						accountNos = strArray[3].trim()+",";
					}
//					else{
//						continue;
//					}
					if(strArray.length > 2){
						String GID = strArray[2];
//						uCmd += GID;
						String uStr = execCommand4Key(uCmd);
						String[] uStrs = uStr.split("\n");
						for(int i=0;i<uStrs.length;i++){
							String[] uArray = uStrs[i].split(":");
							if(uArray.length > 3 && uArray[3].equals(GID)){
								accountNos += uArray[0]+",";
							}
						}
						if(accountNos != ""){
							list.add(accountNos);
						}
						break;
					}
				}
			}
		}
		String retValue = StringUtil.listToStr(list, ",");
		if (retValue == null || "".equals(retValue)) {
			if (isGroupExist) {
				return EXITBUTNOACCOUNT__;
			} else {
				return retValue;
			}
		} else {
			return retValue;
		}
	}
	
//	public synchronized final boolean queryGroupByName(String groupName){
//		String cmd = "cat /etc/group|grep "+groupName;
//		List<String> list = new ArrayList<String>();
//		String rs = execCommand(cmd);
//		if(rs!=null && !"".equals(rs.trim()) && rs.length()>=1){
//			String[] strArr = rs.split("\n");
//			if(strArr!=null && strArr.length>0){
//				for(String str : strArr){
//					if(str.trim().indexOf(cmd)!=-1 || str.trim().startsWith("[") || str.trim().startsWith("$")){
//						continue;
//					}
//					String[] strArray = str.split(":");
//					if(strArray[0].trim().toLowerCase().equals(groupName.trim().toLowerCase())){
//						return true;
//					}
//				}
//			}else{
//				return false;
//			}
//		}
//		return false;
//	}
	
	public synchronized final String queryAccountByGroup(String groupName){
		String cmd = "cat /etc/group|grep "+groupName;
		String uCmd = "cat /etc/passwd ";
		List<String> list = new ArrayList<String>();
		String rs = execCommand(cmd);
		if(rs!=null && !"".equals(rs.trim()) && rs.length()>1){
			String[] strArr = rs.split("\n");
			if(strArr!=null && strArr.length>0){
				for(String str : strArr){
					String[] strArray = str.split(":");
					if(!strArray[0].toLowerCase().equals(groupName.toLowerCase())) continue;
					String accountNos = "";
					if(strArray.length > 3 && strArray[3]!=null && !strArray[3].trim().equals("")){
						accountNos = strArray[3].trim()+",";
					}
//					else{
//						continue;
//					}
					if(strArray.length > 2){
						String GID = strArray[2];
//						uCmd += GID;
						String uStr = execCommand(uCmd);
						String[] uStrs = uStr.split("\n");
						for(int i=0;i<uStrs.length;i++){
							String[] uArray = uStrs[i].split(":");
							if(uArray.length > 3 && uArray[3].equals(GID)){
								accountNos += uArray[0]+",";
							}
						}
						if(accountNos != ""){
							list.add(accountNos);
						}
						break;
					}
				}
			}
		}
		return StringUtil.listToStr(list, ",");
	}
	
	
	public synchronized final String queryAccountByGroup4Key(String groupName) throws Exception{
		String cmd = "cat /etc/group|grep "+groupName;
		String uCmd = "cat /etc/passwd ";
		List<String> list = new ArrayList<String>();
		String rs = execCommand4Key(cmd);
		if(rs!=null && !"".equals(rs.trim()) && rs.length()>1){
			String[] strArr = rs.split("\n");
			if(strArr!=null && strArr.length>0){
				for(String str : strArr){
					String[] strArray = str.split(":");
					if(!strArray[0].toLowerCase().equals(groupName.toLowerCase())) continue;
					String accountNos = "";
					if(strArray.length > 3 && strArray[3]!=null && !strArray[3].trim().equals("")){
						accountNos = strArray[3].trim()+",";
					}
//					else{
//						continue;
//					}
					if(strArray.length > 2){
						String GID = strArray[2];
//						uCmd += GID;
						String uStr = execCommand4Key(uCmd);
						String[] uStrs = uStr.split("\n");
						for(int i=0;i<uStrs.length;i++){
							String[] uArray = uStrs[i].split(":");
							if(uArray.length > 3 && uArray[3].equals(GID)){
								accountNos += uArray[0]+",";
							}
						}
						if(accountNos != ""){
							list.add(accountNos);
						}
						break;
					}
				}
			}
		}
		return StringUtil.listToStr(list, ",");
	}
	public String queryAccountByUID(String uid) {
		String cmd = "groups "+uid;
		String rs = execCommand(cmd);
		if(rs!=null && !"".equals(rs.trim())){
			byte[] byteAttr;
			try {
				byteAttr = rs.getBytes("UTF-8");
				rs = new String(byteAttr,0,byteAttr.length-1);
			} catch (UnsupportedEncodingException e) {
				return rs;
			}
			
		}
		return rs;
	}
	
	public String queryAccountByUID4Key(String uid) throws Exception {
		String cmd = "groups "+uid;
		String rs = execCommand4Key(cmd);
		if(rs!=null && !"".equals(rs.trim())){
			byte[] byteAttr;
			try {
				byteAttr = rs.getBytes("UTF-8");
				rs = new String(byteAttr,0,byteAttr.length-1);
			} catch (UnsupportedEncodingException e) {
				return rs;
			}
			
		}
		return rs;
	}
	private String execCommand4Key(String cmd) throws Exception {
		LogUtil.printCommandMsg("", "", cmd);
		Connection conn = null;
		Session sess = null;
		InputStream sOut = null;
		InputStream sErr = null;
		BufferedReader br = null;
		BufferedReader brErr = null;
		StringBuffer retSb = null;
		try {
			conn = new Connection(hostIp, port);
			conn.connect();
			boolean isAuthenticated = false;
			isAuthenticated = conn.authenticateWithPublicKey(name, new File(
					keyUrl), pwd);
			if(!isAuthenticated){
				throw new Exception("connect to server:"+hostIp+" with private key failed");
			}
			sess = conn.openSession();
			sess.execCommand(cmd);
			sOut = new StreamGobbler(sess.getStdout());
			sErr = new StreamGobbler(sess.getStderr());

			retSb = new StringBuffer();
			br = new BufferedReader(new InputStreamReader(sOut,"utf-8"));
			brErr = new BufferedReader(new InputStreamReader(sErr,"utf-8"));
			while(true){
				String line = br.readLine();
				if(line != null && !"".equals(line) &&!"\n".equals(line)){
					retSb.append(line).append("\n");
				}else{
					break;
				}
			}
			
			while(true){
				String line = brErr.readLine();
				if(line != null && !"".equals(line) &&!"\n".equals(line)){
					retSb.append(line).append("\n");
				}else{
					break;
				}
			}
			log.info("get return result:" + retSb.toString());		
		} catch (Exception e) {
			log.error("bcm.aix.util.CommandQuery->execCommand(" + cmd
					+ ") Error:" + e);
			throw e;
		} finally {
			if (br != null) {
				br.close();
				br = null;
			}
			
			if (brErr != null) {
				brErr.close();
				brErr = null;
			}
			
			if (sOut != null) {
				sOut.close();
				sOut = null;
			}
			if (sErr != null) {
				sErr.close();
				sErr = null;
			}
			if (sess != null) {
				sess.close();
				sess = null;
			}
			if (conn != null) {
				conn.close();
				conn = null;
			}
		}

		return retSb.toString();
	}
	public static CommandQuery getInstance(String ip, int port, String accountNo, String password){
		return (new CommandQuery(ip,port,accountNo,password));
	}
	
	public static CommandQuery getInstance(String ip, int port,
			String accountNo, String password, String keyUrl) {
		return new CommandQuery(ip, port, accountNo, password, keyUrl);
	}
	
	
	public String restoreUser(String accountNo) throws Exception {
		 String cmd = "passwd -u "+accountNo;
//		 String ret = execCommand(cmd);
//		 if(null!= ret && "".equals(ret)){
//			 return execCommand(cmd);
//		 }
		 return execCommand(cmd);
	}

	public String suppendUser(String accountNo) throws Exception {
		 String cmd ="passwd -l "+accountNo;
//		 String ret = execCommand(cmd);
//		 if(null!= ret && "".equals(ret)){
//			 return execCommand(cmd);
//		 }
		 return execCommand(cmd);
	}
	
	public String modifyUserPwd(String name, String pwd) throws Exception {
	
		//echo "mysq:1234" | chpasswd 兼容版本的修改密码命令   之前的--stdin在suse中不会被识别
		String cmd="echo "+name+":"+pwd +"| chpasswd";
		return execCommand(cmd);
	}
	
	public static void main(String[] arg) {
		CommandQuery obj = CommandQuery.getInstance("192.168.1.33",22, "root", "Paraview");
//		List<Account> list = obj.queryAllAccount();
//		for(Account account : list){
//			System.out.println(account.getAccountNo());
//		}
		
		
//		List<Group> list = obj.queryGroupByNo("test");
		
//		System.out.println(obj.queryAccountByNo("test12344"));
		
		
//		List<String> list = obj.queryAccountByGroup("system");
//		for(String str : list){
//			System.out.println(str);
//		}
//		System.out.print(list);
//		obj.queryAccountGroup();
		
			
//				System.out.println(obj.queryAccountByUID("pengy"));
			
		
		System.out.println(obj.queryAccountByGoupName("bin"));
	
//		System.out.println(list.size());
//		System.out.println(obj.execCommand("finger eric1"));
		
		
	}

}

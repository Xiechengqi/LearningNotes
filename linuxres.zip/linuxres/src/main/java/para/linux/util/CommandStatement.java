/**
 *
 */
package para.linux.util;

import ch.ethz.ssh2.Connection;
import ch.ethz.ssh2.Session;
import ch.ethz.ssh2.StreamGobbler;
import com.paraview.base.jar.core.common.log.AppLog;
import com.paraview.base.jar.core.common.log.AppLogFactory;
import para.util.LogUtil;

import java.io.InputStream;

public class CommandStatement {

    private static AppLog log = AppLogFactory.getLog(CommandStatement.class);
    public Connection conn;

    public String command;

    private String sudoDir = PropertiesUtils.getResourceValue("sudo.homdDir");

    public String execCommand() throws Exception {
        return execCommand(command);
    }

    public CommandStatement(Connection conn) {
        this.conn = conn;
    }


    private String execCommand(String cmd) throws Exception {
        LogUtil.printCommandMsg("", "", cmd);
        if (conn == null) {
            return "Connection Object is Null";
        } else {
            String rs = "0";
            Session sess = null;
            InputStream sErr = null;
            try {
                sess = conn.openSession();

                sess.execCommand(cmd);
                sErr = new StreamGobbler(sess.getStderr());
				/*
				byte[] buffer = new byte[5000];
				int length = 0;
				length = sErr.read(buffer);
				if (length > 0) {
					rs = new String(buffer, 0, length);
					if(rs!=null && "0".equals(rs.trim())){
						return "SUCCESS";
					}
					return rs;
				}*/
                StringBuffer retSb = new StringBuffer();
                byte[] buffer = new byte[1024];
                int length = 0;
                while ((length = sErr.read(buffer)) != -1) {
                    log.debug("执行命令:" + cmd + "  ");
                    log.info("执行后的buffer长度:" + length + "  ");
                    if (length > 0) {
                        rs = new String(buffer, 0, length);
                        log.info("每次字符长度：" + rs);
                        if (rs != null && "0".equals(rs.trim())) {
                            return "SUCCESS";
                        }
                        retSb.append(rs);
                    } else {
                        break;
                    }
                }
                log.info("总共字符长度:" + retSb.toString());
                if (retSb.length() == 0) {
                    retSb.append("SUCCESS");
                }
                return retSb.toString();
            } finally {

                if (sErr != null) {
                    try {
                        sErr.close();
                    } catch (Exception e) {
                        log.error("close inputStream error:" + e);
                    } finally {
                        sErr = null;
                    }
                }
                log.info("close session");
                if (sess != null) {
                    sess.close();
                    sess = null;
                }

            }
        }
        //return "SUCCESS";
    }

    //add User
    public String addUser(String name, String pwd, String groups, boolean isSudo, boolean isPrimaryGroupExist) throws Exception {
        if (conn == null) {
            return "Connection Object is Null";
        } else {
            String newPassword = convertPwd(pwd);
            String cmd = PropertiesUtils.getResourceValue("cmd.addUser", newPassword, name);
            log.debug("addUser:" + cmd);
            if (isSudo) {
                cmd = sudoDir + " " + cmd;
            }
            if (groups != null && !"".equals(groups)) {
                cmd += " -G " + groups;
            }
            if (isPrimaryGroupExist) {
                cmd += " -g " + name;
            }
            return execCommand(cmd);
        }
    }

    /**
     * 转化密码里面包含的特殊字符这
     *
     * @param pwd
     * @return
     */
    public String convertPwd(String pwd) {
        String specialChar = "~!@#$%^&*()_+`-=[]\\{}|;':\",./<>?";
        if (pwd == null || "".equals(pwd)) {
            log.info("pwd is null ,that's error");
            return pwd;
        }
        StringBuffer ret = new StringBuffer();
        for (int i = 0; i < pwd.length(); i++) {
            char ch = pwd.charAt(i);
            if (specialChar.indexOf(ch) != -1) {
                log.debug("that's a special char[" + ch + "]");
                String hexString = "\\x" + Integer.toHexString(ch);
                log.debug(ch + " " + hexString);
                ret.append(hexString);
            } else {
                ret.append(ch);
            }
        }
        log.debug(" password after converted [" + ret.toString() + "]  old password[" + pwd + "]");
        return ret.toString();
    }

    //update user pwd
    public String modifyUserPwd(String name, String pwd, boolean isSudo) throws Exception {
        if (conn == null) {
            return "Connection Object is Null";
        } else {
            String cmd = "";
            String cmd1 = "";
            if (pwd.indexOf("\\") > -1 || pwd.indexOf("'") > -1) {
                pwd = pwd.replaceAll("\\\\", "\\\\\\\\");
                pwd = pwd.replaceAll("'", "\\\\0047");
                pwd = "'" + pwd + "'";
                cmd = PropertiesUtils.getResourceValue("cmd.changePwd.open", pwd, name);
                cmd1 = PropertiesUtils.getResourceValue("cmd.sudo.changePwd.open", pwd, name);
            } else {
                pwd = "'" + pwd + "'";
                cmd = PropertiesUtils.getResourceValue("cmd.changePwd", pwd, name);
                cmd1 = PropertiesUtils.getResourceValue("cmd.sudo.changePwd", pwd, name);
            }
            if (!isSudo) {
                return execCommand(cmd);
            } else {
                return execCommand(cmd1);
            }
        }
    }

    public String execCommand2(String cmd) throws Exception {
        if (conn == null) {
            return "Connection Object is Null";
        } else {
            String rs = "0";
            Session sess = null;
            InputStream sErr = null;
            InputStream sSu = null;
            try {
                sess = conn.openSession();
                sess.execCommand(cmd);
                sSu = new StreamGobbler(sess.getStdout());
                StringBuffer Sb = new StringBuffer();
                byte[] buffer1 = new byte[1024];
                int lengths = 0;
                while ((lengths = sSu.read(buffer1)) != -1) {
                    if (lengths > 0) {
                        rs = new String(buffer1, 0, lengths);
                        Sb.append(rs);
                    } else {
                        break;
                    }
                }

                System.out.println("正确：" + Sb.toString());

                sErr = new StreamGobbler(sess.getStderr());
                StringBuffer retSb = new StringBuffer();
                byte[] buffer = new byte[1024];
                int length = 0;
                while ((length = sErr.read(buffer)) != -1) {
                    log.debug("执行命令:" + cmd + "  ");
                    log.info("执行后的buffer长度:" + length + "  ");
                    if (length > 0) {
                        rs = new String(buffer, 0, length);
                        log.info("每次字符长度：" + rs);
                        if (rs != null && "0".equals(rs.trim())) {
                            return "SUCCESS";
                        }
                        retSb.append(rs);
                    } else {
                        break;
                    }
                }
                System.out.println("错误：" + retSb.toString());
                log.info("总共字符长度:" + retSb.toString());
                if (retSb.length() == 0) {
                    retSb.append("SUCCESS");
                }
                return retSb.toString();
            } finally {

                if (sErr != null) {
                    try {
                        sErr.close();
                    } catch (Exception e) {
                        log.error("close inputStream error:" + e);
                    } finally {
                        sErr = null;
                    }
                }
                log.info("close session");
                if (sess != null) {
                    sess.close();
                    sess = null;
                }

            }
        }
    }


    public String modifyUserPwd(String adminPassword, String name, String pwd, boolean isSudo) throws Exception {
        if (conn == null) {
            return "Connection Object is Null";
        } else {
            String cmd = "";
            String cmd1 = "";
            if (pwd.indexOf("\\") > -1 || pwd.indexOf("'") > -1) {
                cmd1 = PropertiesUtils.getResourceValue("cmd.sudo.changePwd.open.new", adminPassword, name, pwd);
                pwd = pwd.replaceAll("\\\\", "\\\\\\\\");
                pwd = pwd.replaceAll("'", "\\\\0047");
                pwd = "'" + pwd + "'";
                cmd = PropertiesUtils.getResourceValue("cmd.changePwd.open", pwd, name);
            } else {
                cmd1 = PropertiesUtils.getResourceValue("cmd.sudo.changePwd.new", adminPassword, name, pwd);
                pwd = "'" + pwd + "'";
                cmd = PropertiesUtils.getResourceValue("cmd.changePwd", pwd, name);
            }
            if (!isSudo) {
                return execCommand(cmd);
            } else {
                return execCommand(cmd1);
            }
        }
    }

    //update user group
    public String modifyUserGroup(String name, String groups, boolean isSudo) throws Exception {
        if (conn == null) {
            return "Connection Object is Null";
        } else {
            String cmd = PropertiesUtils.getResourceValue("cmd.changeUserGroup");
            log.debug("modifyUserGroup:" + cmd);
            if (isSudo) {
                if (groups == null || groups.equals("")) {
                    cmd = sudoDir + " " + cmd + " '' " + name;
                } else {
                    cmd = sudoDir + " " + cmd + " " + groups + " " + name;
                }
            } else {
                if (groups == null || groups.equals("")) {
                    cmd = cmd + " '' " + name;
                } else {
                    cmd = cmd + " " + groups + " " + name;
                }
            }
            return execCommand(cmd);
        }
    }

    //delete User
    public String deleteUser(String name, boolean isSudo) throws Exception {
        if (conn == null) {
            return "Connection Object is Null";
        } else {
            String cmd = PropertiesUtils.getResourceValue("cmd.deleteUser", name);
            log.debug("deleteUser:" + cmd);
            if (isSudo) {
                cmd = sudoDir + " " + cmd;
            }
            String rs = execCommand(cmd);
            if (rs == null || "".equals(rs.trim())) {
                rs = execCommand(cmd);
            } else {
                if (rs.toLowerCase().indexOf("userdel: unknown user") != -1 ||
                        rs.toLowerCase().indexOf("does not exist") != -1 ||
                        rs.toLowerCase().indexOf("successfully") != -1 ||
                        rs.toLowerCase().indexOf("no crontab") != -1) {
                    return "SUCCESS";
                }
            }
            return rs;
        }
    }

    //add group
    public String addGroup(String groupName, boolean isSudo) throws Exception {
        if (conn == null) {
            return "Connection Object is Null";
        } else {
            String cmd = PropertiesUtils.getResourceValue("cmd.addGroup", groupName);
            log.debug("addGroup:" + cmd);
            if (isSudo) {
                cmd = sudoDir + " " + cmd;
            }
            return execCommand(cmd);
        }
    }

    public String deleteGroup(String groupName, boolean isSudo) throws Exception {
        if (conn == null) {
            return "Connection Object is Null";
        } else {
            String cmd = PropertiesUtils.getResourceValue("cmd.deleteGroup", groupName);
            log.debug("deleteGroup:" + cmd);
            if (isSudo) {
                cmd = sudoDir + " " + cmd;
            }
            String rs = execCommand(cmd);
            if (rs == null || "".equals(rs.trim())) {
                rs = execCommand(cmd);
            } else {
                if (rs.toLowerCase().indexOf("groupdel: unknown group") != -1 || rs.toLowerCase().indexOf("does not exist") != -1 || rs.toLowerCase().indexOf("successfully") != -1) {
                    return "SUCCESS";
                }
            }
            return rs;
        }
    }


    public String suppendUser(String accountNo, boolean isSudo) throws Exception {
        if (conn == null) {
            return "Connection Object is Null";
        } else {
            String cmd = PropertiesUtils.getResourceValue("cmd.suppendUser", accountNo);
            if (isSudo) {
                cmd = sudoDir + " " + cmd;
            }
            String rs = execCommand(cmd);
            if (rs == null || "".equals(rs.trim())) {
                rs = execCommand(cmd);
            } else {
                if (rs.toLowerCase().indexOf("already locked") != -1) {
                    return "SUCCESS";
                }
            }
            return rs;
        }
    }

    public String restoreUser(String accountNo, boolean isSudo) throws Exception {
        String flag = null;
        if (conn == null) {
            return "Connection Object is Null";
        } else {
            String cmd = PropertiesUtils.getResourceValue("cmd.restoreUser", accountNo);
            if (isSudo) {
                cmd = sudoDir + " " + cmd;
            }
            String rs = execCommand(cmd);
            if (rs == null || "".equals(rs.trim())) {
                rs = execCommand(cmd);
            } else {
                if (rs.toLowerCase().indexOf("cannot unlock") != -1) {
                    return "SUCCESS";
                }
            }
            return rs;
        }
    }

    /**
     * @return the command
     */
    public String getCommand() {
        return command;
    }

    /**
     * @param command
     *            the command to set
     */
    public void setCommand(String command) {
        this.command = command;
    }

}

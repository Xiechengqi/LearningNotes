package para.linux.Impl;

import para.account.Interface.IResourceProcessor;
import para.account.bean.Account;
import para.account.bean.RemoteService;

public class Test {


    public static void main(String[] args) throws Exception {
        IResourceProcessor obj = new ResourceProcessor();
        //Redhat 101 root123 Suse 33 Paraview
//		RemoteService server = new RemoteService("192.168.1.101", 5100, "root", "root123", "ssh",false);
        //server.setOpenPage(true);
//		RemoteService server = new RemoteService("192.168.1.33", 22, "root", "Paraview", Const.serviceType.linux, "ssh",false);
//		RemoteService server = new RemoteService("192.168.1.57", 22, "root", "rootroot",  "telnet");

//		RemoteService server = new RemoteService("192.168.1.200", 23, "root", "rootroot", "telnet");
//		RemoteService server = new RemoteService("192.168.1.33", 23, "root", "tivoli", "telnet",false);
//		RemoteService server = new RemoteService("192.168.1.33", 23, "test", "tivoli",  "telnet",true);
//		RemoteService server = new RemoteService("192.168.1.41", 22, "root", "rootroot", "telnet",false);
        RemoteService server = new RemoteService();
        server.setConnType("ssh");
        server.setServerIp("192.168.7.24");
        server.setLoginName("juan");
        server.setLoginPwd("Parav1ew");
        server.setPort(22);
        server.setSudo(true);
//        server.setKeyUrl("C:\\Users\\Administrator\\Desktop\\id_rsa");
//        server.setKeyPwd("Parav1ew");
//        System.out.println(obj.testConnect4Key(server));
        System.out.println(obj.testConnect(server));
        server.setPageSize(1000);
        server.setOpenPage(true);

        Account account = new Account();
        account.setAccountNo("caoyu");
        account.setPwd("Parav1ew2");
        obj.changeAccountPwd(server, account);

//        Account account = new Account();
//        account.setAccountNo("luke13");
//        account.setPwd("Parav1ew2");
//        obj.addAccount(server, account);

//		List<Group> groups = obj.queryAllGroup(server);
//		System.out.println("size:"+groups.size());
//		for (int i = 0; i < groups.size(); i++) {
//			Group group = groups.get(i);
//			System.out.println(group.getGroupName());
//		}*/

       /* try {

            server.setPageSize(15);
            boolean isNext = true;
            int currentPageSize = server.getPageSize();
            while (isNext) {
                List<Account> list = obj.queryAllAccount4Key(server);
                if (list != null && list.size() > 0) {
                    System.out.println(list.size());
                    for (Account account : list) {
                        System.out.println(account.getAccountNo());
                    }
                    int listSize = list.size();
                    //当前开始页
                    //int startRow  = (server.getPageIndex() - 1)*currentPageSize +1;  //n*
                    //int endRow  =  (server.getPageIndex())*currentPageSize;  //n*
                    if (listSize >= currentPageSize) {//如果查询结果大于等于当前步长 其还有数据 则继续查询。
                        //下次执行起开始页
                        int nextPageIndex = server.getPageIndex();
                        server.setPageIndex(++nextPageIndex);
                        //下次执行当前查询每页结果数
                        //server.setPageSize(endRow);
                    } else if (listSize < currentPageSize) {//如果查询结果小于步长说明查询结束
                        isNext = false;
                        System.out.println("query complete!");
                    }
                } else {
                    isNext = false;
                    System.out.println("list is null");
                }

            }

        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
		*/
	/*	try {

				int currentPageSize  =server.getPageSize();
				boolean isNext  = true;
				while(isNext){
					List<Group> list = obj.queryAllGroup(server);
					if(list!=null && list.size()>0){
						System.out.println(list.size());
						for(Group group : list){
							System.out.println(group.getGroupName());
						}
						int listSize = list.size();
						if(listSize>=currentPageSize){
							int nextPageIndex = server.getPageIndex();
							server.setPageIndex(++nextPageIndex);
						}else{
							System.out.println("query complete!");
							isNext = false;
						}
					}else{
						isNext = false;
						System.out.println("list is null");
					}
					
					
				}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		*/
//		List<Group> list = obj.queryGroupByNo(server, "testPy002");
//		for(Group group : list){
//			System.out.println(group.getGroupName());
//		}

//		Account account = obj.queryAccountByNo(server, "root");
//		System.out.println(account.getAccountNo());

//		Group group = obj.queryAccountByGoupName(server, "users");
//		System.out.println(group.getAccounts().toString());

//		Account account = new Account();
//		account.setAccountNo("$aacc");
//		account.setPwd("adafdsafds");
//		List<Group> listGroup = new ArrayList<Group>();
//		listGroup.add(new Group("root"));
//		account.setGroups(listGroup);
//
//		try {
//			System.out.println(obj.addAccount(server, account));
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		/*try {
			long st = System.currentTimeMillis();
			System.out.println(obj.changeAccountPwd(server, account));
			long et = System.currentTimeMillis();
			System.out.println(et-st);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/

//		try {
//		System.out.println(obj.changeAccountGroup(server, account,0));
//	} catch (Exception e) {
//		// TODO Auto-generated catch block
//		e.printStackTrace();
//	}

//		try {
//			System.out.println(obj.deleteAccount(server, "testPy002"));
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}

//		try {
//			System.out.println(obj.stopAccount(server, "testPy002"));
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}

//		try {
//			System.out.println(obj.startAccount(server, "testPy002"));
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		/*Group group = new Group();
		group.setGroupName("wangmytest001");
		Account account1 = new Account();
		account1.setAccountNo("wangmytest001");
		//Account account2 = new Account();
		//account2.setAccountNo("testPy002");
		//Account account3 = new Account();
		//account3.setAccountNo("testPy003");
		List<Account> listAccount = new ArrayList();
		listAccount.add(account1);
		//listAccount.add(account2);
		//listAccount.add(account3);
		group.setAccounts(listAccount);
		try {
			System.out.println(obj.changeGroupMember(server, group, 1));
		} catch (Exception e) {
			e.printStackTrace();
		}*/
    }
}

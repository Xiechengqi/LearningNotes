package para.linux.Impl;

import ch.ethz.ssh2.Connection;
import com.paraview.base.jar.core.common.log.AppLog;
import com.paraview.base.jar.core.common.log.AppLogFactory;
import para.account.Interface.IResourceProcessor;
import para.account.bean.Account;
import para.account.bean.Group;
import para.account.bean.RemoteService;
import para.linux.util.CommandQuery;
import para.linux.util.CommandStatement;
import para.linux.util.ObjectCheck;
import para.linux.util.PropertiesUtils;
import para.linux.util.SshConnection;
import para.linux.util.TelnetConnection;
import para.linux.util.TelnetQuery;
import para.linux.util.TelnetStatement;
import para.util.LogUtil;
import para.util.StringUtil;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class ResourceProcessor implements IResourceProcessor {

    private static AppLog log = AppLogFactory.getLog(ResourceProcessor.class);
    private String rs = "NOT_STARTED";


    private boolean printMsg(RemoteService server, String method) {
        LogUtil.printServerParamMsg(server, "ResourceProcessor", method);
        if (!ObjectCheck.checkParam(server)) {
            LogUtil.printMsg("ResourceProcessor", method, server.getServerIp(), "RemoteService对象参数不全.");
            return false;
        }
        return true;
    }

    private boolean printMsg4Key(RemoteService server, String method) {
        LogUtil.printServerParamMsg(server, "ResourceProcessor", method);
        if (StringUtil.isEmptyOrNullStr(server.getServerIp()) || StringUtil.isEmptyOrNullStr(server.getLoginName()) ||
                StringUtil.isEmptyOrNullStr(server.getKeyUrl())) {
            LogUtil.printMsg("ResourceProcessor", method, server.getServerIp(), "RemoteService对象参数不全.");
            return false;
        }
        return true;
    }

    /*
     * (non-Javadoc) test connect
     * @see para.account.Interface.IResourceProcessor#testConnect(para.account.bean.RemoteService)
     */
    @Override
    public boolean testConnect(RemoteService server) {
        log.info("testConnect...");
        if (!printMsg(server, "testConnect")) {
            LogUtil.printMsg("ResourceProcessor", "testConnect", server.getServerIp(), "RemoteService对象参数不全.");
            LogUtil.printResult("testConnect", server.getServerIp(), "由于RemoteService对象参数不全,返回false");
            return false;
        }
        if (server.getConnType() == null
                || server.getConnType().trim().equals("")
                || server.getConnType().trim().toLowerCase().equals("ssh")) {
            SshConnection ssh = null;
            Connection conn = null;
            boolean bAuthSuccess = false;
            try {
                ssh = new SshConnection(server.getServerIp().trim(),
                        server.getPort(), server.getLoginName().trim(), server.getLoginPwd());
                conn = ssh.getSSHConnectionInteractive();
                LogUtil.printResult("testConnect", server.getServerIp(), String.valueOf(ssh.isAuthSuccess()));
                bAuthSuccess = ssh.isAuthSuccess();
                return bAuthSuccess;
            } catch (Exception e) {
                LogUtil.printMsg("ResourceProcessor", "testConnect", server.getServerIp(), "SSH协议测试:" + e.getLocalizedMessage());
                LogUtil.printResult("testConnect", server.getServerIp(), "false");
                return false;
            } finally {
                if (ssh != null) {
                    ssh.closeConnection();
                    ssh = null;
                }
                if (conn != null) {
                    conn.close();
                    conn = null;
                }
            }

        } else {
            TelnetConnection obj = new TelnetConnection(server.getServerIp().trim(), server
                    .getPort(), server.getLoginName().trim(), server
                    .getLoginPwd());
            String rs = obj.execCommand("whoami");
            LogUtil.printResult("testConnect", server.getServerIp(), "telnet协议执行whoami:" + rs);
            if (rs != null && !"".equals(rs.trim()) && rs.length() > 1) {
                rs = rs.substring(1);
                String[] strArr = rs.split("\n");
                if (strArr != null && strArr.length > 0) {
                    for (String str : strArr) {
                        if (str.trim().indexOf(server.getLoginName().trim()) != -1) {
                            LogUtil.printResult("testConnect", server.getServerIp(), "true");
                            return true;
                        } else {
                            continue;
                        }
                    }
                }
            }
            LogUtil.printResult("testConnect", server.getServerIp(), "false");
            return false;
        }
    }


    /*
     * (non-Javadoc)query All Accounts
     * @see para.account.Interface.IResourceProcessor#queryAllAccount(para.account.bean.RemoteService)
     */
    @Override
    public List<Account> queryAllAccount(RemoteService server) throws Exception {
        log.info("start queryAllAccount...");
        if (!printMsg(server, "queryAllAccount")) {
            LogUtil.printMsg("ResourceProcessor", "queryAllAccount", server.getServerIp(), "RemoteService对象参数不全.");
            LogUtil.printResult("queryAllAccount", server.getServerIp(), "由于RemoteService对象参数不全,集合为空");
            return null;
        }
        List<Account> list = null;
        if (server.getConnType() == null || server.getConnType().trim().equals("") || server.getConnType().trim().toLowerCase().equals("ssh")) {
            log.info("connType is null or ssh mode");
            CommandQuery cmdQuery = CommandQuery.getInstance(server.getServerIp().trim(), server.getPort(), server.getLoginName().trim(), server.getLoginPwd());
            if (server.openPage()) {
                log.info("query for page query reouce Account");
                list = cmdQuery.queryAllAccount(server);
            } else {
                log.info("query query All resource Account");
                list = cmdQuery.queryAllAccount();
            }
        } else {
            log.info("connType is not null or Non-ssh mode");
            TelnetQuery cmdQuery = TelnetQuery.getInstance(server.getServerIp().trim(), server.getPort(), server.getLoginName().trim(), server.getLoginPwd());
            if (server.openPage()) {
                log.info("query for page query reouce Account");
                list = cmdQuery.queryAllAccount(server);
            } else {
                log.info("query query All resource Account");
                list = cmdQuery.queryAllAccount();
            }
        }
        if (list == null) {
            log.info("query result is null");
            list = new ArrayList<Account>();
        }
        LogUtil.printResult("queryAllAccount", server.getServerIp(), "查询集合大小：" + list.size());
        log.info("end queryAllAccount...");
        return list;
    }

    /*
     * (non-Javadoc)query all Groups
     * @see para.account.Interface.IResourceProcessor#queryAllGroup(para.account.bean.RemoteService)
     */
    @Override
    public List<Group> queryAllGroup(RemoteService server) throws Exception {
        log.info("start query resource group!");
        if (!printMsg(server, "queryAllGroup")) {
            LogUtil.printMsg("ResourceProcessor", "queryAllGroup", server.getServerIp(), "RemoteService对象参数不全.");
            LogUtil.printResult("queryAllGroup", server.getServerIp(), "由于RemoteService对象参数不全,集合为空");
            return null;
        }
        List<Group> list = null;
        if (server.getConnType() == null || server.getConnType().trim().equals("") || server.getConnType().trim().toLowerCase().equals("ssh")) {
            log.info("query mode ssh");
            CommandQuery cmdQuery = CommandQuery.getInstance(server.getServerIp().trim(), server.getPort(), server.getLoginName().trim(), server.getLoginPwd());
            if (server.openPage()) {
                log.info("query mode ssh for page");
                list = cmdQuery.queryAllGroup(server);
            } else {
                log.info("query mode ssh no page!");
                list = cmdQuery.queryAllGroup();
            }
        } else {
            log.info("query mode telnet");
            TelnetQuery cmdQuery = TelnetQuery.getInstance(server.getServerIp().trim(), server.getPort(), server.getLoginName().trim(), server.getLoginPwd());
            if (server.openPage()) {
                log.info("query mode telnet for page!");
                list = cmdQuery.queryAllGroup(server);
            } else {
                log.info("query mode telnet not page!");
                list = cmdQuery.queryAllGroup();
            }
        }
        if (list == null) {
            list = new ArrayList<Group>();
        }
        LogUtil.printResult("queryAllGroup", server.getServerIp(), "查询集合大小：" + list.size());
        log.info("end query resource group!");
        return list;
    }


    /*
     * (non-Javadoc)query account's Group Collection  by AccountNo
     * @see para.account.Interface.IResourceProcessor#queryGroupByNo(para.account.bean.RemoteService, java.lang.String)
     */
    @Override
    public List<Group> queryGroupByNo(RemoteService server, String accountNo) {
        LogUtil.printTermParamMsg("ResourceProcessor", "queryGroupByNo", "accountNo", accountNo);
        if (!printMsg(server, "queryGroupByNo")) {
            LogUtil.printMsg("ResourceProcessor", "queryGroupByNo", server.getServerIp(), "RemoteService对象参数不全.");
            LogUtil.printResult("queryAllGroup", server.getServerIp(), "由于RemoteService对象参数不全,集合为空");
            return null;
        } else if (StringUtil.isNullOrBlank(accountNo)) {
            LogUtil.printMsg("ResourceProcessor", "queryGroupByNo", server.getServerIp(), "查询参数accountNo为空.");
            LogUtil.printResult("queryAllGroup", server.getServerIp(), "由于查询参数accountNo,集合为空");
            return null;
        }
        List<Group> list = null;
        if (server.getConnType() == null
                || server.getConnType().trim().equals("")
                || server.getConnType().trim().toLowerCase().equals("ssh")) {
            CommandQuery cmdQuery = CommandQuery.getInstance(server
                    .getServerIp().trim(), server.getPort(), server
                    .getLoginName().trim(), server.getLoginPwd());
            list = cmdQuery.queryGroupByNo(accountNo.trim());
        } else {
            TelnetQuery cmdQuery = TelnetQuery.getInstance(server.getServerIp()
                            .trim(), server.getPort(), server.getLoginName().trim(),
                    server.getLoginPwd());
            list = cmdQuery.queryGroupByNo(accountNo.trim());
        }
        if (list == null) {
            list = new ArrayList<Group>();
        }
        LogUtil.printResult("queryGroupByNo", server.getServerIp(), "查询集合大小：" + list.size());
        return list;
    }


    /*
     * (non-Javadoc)query Account Object by accountNo
     * @see para.account.Interface.IResourceProcessor#findAccountByNo(para.account.bean.RemoteService, java.lang.String)
     */
    @Override
    public Account findAccountByNo(RemoteService server, String accountNo) {
        LogUtil.printTermParamMsg("ResourceProcessor", "findAccountByNo", "accountNo", accountNo);
        if (!printMsg(server, "findAccountByNo")) {
            LogUtil.printMsg("ResourceProcessor", "findAccountByNo", server.getServerIp(), "RemoteService对象参数不全.");
            LogUtil.printResult("findAccountByNo", server.getServerIp(), "由于RemoteService对象参数不全,返回null");
            return null;
        } else if (StringUtil.isNullOrBlank(accountNo)) {
            LogUtil.printMsg("ResourceProcessor", "findAccountByNo", server.getServerIp(), "查询参数accountNo为空.");
            LogUtil.printResult("findAccountByNo", server.getServerIp(), "由于查询参数accountNo为空,返回null");
            return null;
        }
        if (server.getConnType() == null
                || server.getConnType().trim().equals("")
                || server.getConnType().trim().toLowerCase().equals("ssh")) {
            CommandQuery cmdQuery = CommandQuery.getInstance(server
                    .getServerIp().trim(), server.getPort(), server
                    .getLoginName().trim(), server.getLoginPwd());
            rs = cmdQuery.queryAccountByNo(accountNo.trim());
        } else {
            TelnetQuery cmdQuery = TelnetQuery.getInstance(server.getServerIp()
                            .trim(), server.getPort(), server.getLoginName().trim(),
                    server.getLoginPwd());
            rs = cmdQuery.queryAccountByNo(accountNo.trim());
        }
        if (rs == null || "".equals(rs.trim())) {
            LogUtil.printResult("findAccountByNo", server.getServerIp(), "依据accountNo:" + accountNo + "查询Account,由于查询结果rs为空,返回null");
            return null;
        } else {
            List<Group> listGroup = new ArrayList<Group>();
            String[] rsArr = rs.split(" ");
            if (rsArr != null && rsArr.length > 0) {
                for (String str : rsArr) {
                    Group group = new Group();
                    group.setGroupName(str);
                    if (!listGroup.contains(group)) {
                        listGroup.add(group);
                    }
                }
            }
            Account account = new Account();
            account.setAccountNo(accountNo);
            account.setGroups(listGroup);
            return account;
        }
    }

    /*
     * (non-Javadoc)query Group Object By groupName
     * @see para.account.Interface.IResourceProcessor#findGroupByName(para.account.bean.RemoteService, java.lang.String)
     */
    @Override
    public Group findGroupByName(RemoteService server, String groupName) {
        LogUtil.printTermParamMsg("ResourceProcessor", "findGroupByName", "groupName", groupName);
        if (!printMsg(server, "findGroupByName")) {
            LogUtil.printMsg("ResourceProcessor", "findGroupByName", server.getServerIp(), "RemoteService对象参数不全.");
            LogUtil.printResult("findGroupByName", server.getServerIp(), "由于RemoteService对象参数不全,返回null");
            return null;
        } else if (StringUtil.isNullOrBlank(groupName)) {
            LogUtil.printMsg("ResourceProcessor", "findGroupByName", server.getServerIp(), "查询参数groupName为空.");
            LogUtil.printResult("findGroupByName", server.getServerIp(), "由于查询参数groupName为空,返回null");
            return null;
        }
        if (server.getConnType() == null
                || server.getConnType().trim().equals("")
                || server.getConnType().trim().toLowerCase().equals("ssh")) {
            CommandQuery cmdQuery = CommandQuery.getInstance(server
                    .getServerIp().trim(), server.getPort(), server
                    .getLoginName().trim(), server.getLoginPwd());
            rs = cmdQuery.queryAccountByGoupName(groupName.trim());
        } else {
            TelnetQuery cmdQuery = TelnetQuery.getInstance(server.getServerIp()
                            .trim(), server.getPort(), server.getLoginName().trim(),
                    server.getLoginPwd());
            rs = cmdQuery.queryAccountByGoupName(groupName.trim());
        }
        if (rs == null || "".equals(rs.trim())) {
            LogUtil.printResult("findGroupByName", server.getServerIp(), "依据groupName:" + groupName + "查询Group,由于查询结果rs为空,返回null");
            return null;
        } else if (CommandQuery.EXITBUTNOACCOUNT__.equals(rs.trim())) {   //有组但是改组没有帐号
            Group group = new Group();
            group.setGroupName(groupName.trim());
            return group;
        } else {
            Group group = new Group();
            group.setGroupName(groupName.trim());
            List<Account> listAccount = new ArrayList<Account>();
            List<String> listStr = StringUtil.strToList(rs, ",");
            for (String str : listStr) {
                if (str == null || "".equals(str.trim())) {
                    continue;
                }
                Account account = new Account();
                account.setAccountNo(str.trim());
                listAccount.add(account);
            }
            group.setAccounts(listAccount);
            return group;
        }
    }


    /*
     * (non-Javadoc) add User
     * @see para.account.Interface.IResourceProcessor#addAccount(para.account.bean.RemoteService, para.account.bean.Account)
     */
    private String checkDollarInAccountNo(String accountNo) {
        if (StringUtil.isNullOrBlank(accountNo)) {
            return " accountNo is null,can not create the account";
        }
        String tempAccountNo = accountNo.substring(0, accountNo.length() - 1);
        if (StringUtil.isNullOrBlank(tempAccountNo)) {
            return null;
        }
        if (tempAccountNo.indexOf("$") != -1) {
            return "The dollar($) can not exist in accountNo except end position as for Linux resource";
        }
        return null;
    }

    @Override
    public String addAccount(RemoteService server, Account account) {
        log.info("Linux 资源开始新增加帐号[" + account.getAccountNo() + "]");
        log.debug("Linux 资源开始新增加帐号[" + account.getAccountNo() + "] 密码[" + account.getPwd() + "]");
        LogUtil.printTermParamMsg("ResourceProcessor", "addAccount", account, null);
        if (!printMsg(server, "addAccount")) {
            LogUtil.printMsg("ResourceProcessor", "addAccount", server.getServerIp(), "RemoteService对象参数不全.");
            LogUtil.printResult("addAccount", server.getServerIp(), "由于RemoteService对象参数不全,返回Invalid Parameter");
            return "Invalid parameter:RemoteServer Parameters incomplete";
        } else if (account == null || StringUtil.isNullOrBlank(account.getAccountNo())) {
            LogUtil.printMsg("ResourceProcessor", "addAccount", server.getServerIp(), "Account对象为空或accountNo为空.");
            LogUtil.printResult("addAccount", server.getServerIp(), "由于Account对象为空或accountNo为空,返回Invalid Parameter");
            return "Invalid parameter:Account Parameters incomplete";
        }
        String checkMsg = checkDollarInAccountNo(account.getAccountNo().trim());
        if (!StringUtil.isNullOrBlank(checkMsg)) {
            return checkMsg;
        }

        String groups = "";
        if (account.getGroups() != null && account.getGroups().size() > 0) {
            for (Group group : account.getGroups()) {
                if (!account.getAccountNo().trim().equalsIgnoreCase(group.getGroupName())) {
                    groups += group.getGroupName() + ",";
                } else {
                    log.info("新增加帐号[" + account.getAccountNo() + "]时，手工选择了增加一个组[" + group.getGroupName() + "] 这个是错误，该组会自动添加，无需手工添加");
                }

            }
            if (groups != null && groups.length() > 0) {
                groups = groups.substring(0, groups.length() - 1);
            }
        }
        boolean isPrimaryGroupExist = false;
        log.info("增加帐号前，先判断该帐号[" + account.getAccountNo() + "]的默认组是否存在");
        if (this.isExitGroup(server, account.getAccountNo().trim())) {
            log.info("该帐号组[" + account.getAccountNo().trim() + "]存在，增加帐号时需要-g参数");
            isPrimaryGroupExist = true;
        } else {
            log.info("该帐号组[" + account.getAccountNo().trim() + "]不存在");
            isPrimaryGroupExist = false;
        }
        SshConnection ssh = null;
        try {
            if (server.getConnType() == null
                    || server.getConnType().trim().equals("")
                    || server.getConnType().trim().toLowerCase().equals("ssh")) {
                ssh = new SshConnection(server.getServerIp().trim(),
                        server.getPort(), server.getLoginName().trim(), server
                        .getLoginPwd());
                CommandStatement stat = ssh.createCommandInteractive();
                rs = stat.addUser(account.getAccountNo().trim(), account.getPwd(), groups, server.isSudo(), isPrimaryGroupExist);
                log.info("ssh mode addAccount complete " + rs);
            } else {
                TelnetConnection obj = new TelnetConnection(server.getServerIp().trim(), server.getPort(), server.getLoginName().trim(), server.getLoginPwd());
                TelnetStatement stat = obj.createCommand();
                rs = stat.addUser(account.getAccountNo().trim(), account.getPwd(), groups, server.isSudo(), isPrimaryGroupExist);
                log.info("telnet mode addAccount complete " + rs);
            }
            if (rs != null && "".equals(rs.trim())) {
                rs = "Finished: no return value";
            }
        } catch (Exception e) {
            LogUtil.printMsg("ResourceProcessor", "addAccount", server.getServerIp(), "添加帐号" + account.getAccountNo() + "发生异常:" + e);
            rs = e.getLocalizedMessage();
        } finally {
            if (ssh != null) {
                ssh.closeConnection();
                ssh = null;
            }
        }
        LogUtil.printResult("addAccount", server.getServerIp(), "添加帐号:" + account.getAccountNo() + ",返回结果" + rs);
        if (rs != null && rs.equalsIgnoreCase("SUCCESS")) {
            log.info("addAccount success!");
            log.info("addAccount success after testConnect...");
            RemoteService testServer = new RemoteService(server.getServerIp(), server.getPort(), account.getAccountNo().trim(), account.getPwd(), server.getConnType(), server.isSudo());
            log.info("start testConnect...");
            boolean ret = this.testConnect(testServer);
            if (ret) {
                log.info("testConnect successfull!");
                rs = "SUCCESS";
            } else {
                rs = "Add account success after testConnect fFailure,please check!";
            }
            log.info("end testConnect");
        }
        return rs;
    }

    /*
     * (non-Javadoc) change Account's Password
     * @see para.account.Interface.IResourceProcessor#changeAccountPwd(para.account.bean.RemoteService, para.account.bean.Account)
     */
    @Override
    public String changeAccountPwd(RemoteService server, Account account) {
        LogUtil.printTermParamMsg("ResourceProcessor", "changeAccountPwd", account, null);
        if (!printMsg(server, "changeAccountPwd")) {
            LogUtil.printMsg("ResourceProcessor", "changeAccountPwd", server.getServerIp(), "RemoteService对象参数不全.");
            LogUtil.printResult("changeAccountPwd", server.getServerIp(), "由于RemoteService对象参数为空,返回Invalid Parameter");
            return "Invalid parameter:RemoteServer Parameters incomplete";
        } else if (account == null || StringUtil.isNullOrBlank(account.getAccountNo())) {
            LogUtil.printMsg("ResourceProcessor", "changeAccountPwd", server.getServerIp(), "Account对象为空或accountNo为空.");
            LogUtil.printResult("changeAccountPwd", server.getServerIp(), "由于Account对象为空或accountNo为空,返回Invalid Parameter");
            return "Invalid parameter:Account Parameters incomplete";
        }
        SshConnection ssh = null;
        TelnetConnection obj = null;
        try {
            if (server.getConnType() == null || server.getConnType().trim().equals("") || server.getConnType().trim().toLowerCase().equals("ssh")) {
                ssh = new SshConnection(server.getServerIp().trim(), server.getPort(), server.getLoginName().trim(), server.getLoginPwd());
                CommandStatement stat = ssh.createCommandInteractive();
//                rs = stat.modifyUserPwd(account.getAccountNo().trim(), account.getPwd(), server.isSudo());
                rs = stat.modifyUserPwd(server.getLoginPwd(), account.getAccountNo().trim(), account.getPwd(), server.isSudo());
                log.info("ssh mode changeAccountPwd complete!");
            } else {
                obj = new TelnetConnection(server.getServerIp().trim(), server.getPort(), server.getLoginName().trim(), server.getLoginPwd());
                TelnetStatement stat = obj.createCommand();
                rs = stat.modifyUserPwd(account.getAccountNo().trim(), account.getPwd(), server.isSudo());
                log.info("telnet mode changeAccountPwd complete!");
            }
            if (rs != null && "".equals(rs.trim())) {
                rs = "Finished: no return value.The reason may be is network congestion.Password may be not synchronized, print or export password, then manualy testing";
                log.info(rs);
                RemoteService testServer = new RemoteService(server.getServerIp(), server.getPort(), account.getAccountNo().trim(), account.getPwd(), server.getConnType(), server.isSudo());
                log.info("start changeAccountPwd after testConnect");
                boolean testFlag = this.testConnect(testServer);
                if (testFlag) {
                    log.info("testConnect successfull!");
                    rs = "SUCCESS";
                }
                log.info("end changeAccountPwd after testConnect");
            }
            if (rs != null && rs.equalsIgnoreCase("success")) {
                RemoteService testServer = new RemoteService(server.getServerIp(), server.getPort(), account.getAccountNo().trim(), account.getPwd(), server.getConnType(), server.isSudo());
                log.info("start changeAccountPwd after testConnect");
                boolean testFlag = this.testConnect(testServer);
                if (testFlag) {
                    log.info("testConnect successfull!");
                    rs = "SUCCESS";
                }
                log.info("end changeAccountPwd after testConnect");
            }
        } catch (Exception e) {
            LogUtil.printMsg("ResourceProcessor", "changeAccountPwd", server.getServerIp(), "修改帐号密码" + account.getAccountNo() + "发生异常:" + e);
            rs = e.getLocalizedMessage();
            log.error(rs);
        } finally {
            log.error("开始关闭ssh链接");
            if (ssh != null) {
                ssh.closeConnection();
                ssh = null;
            }
            if (obj != null) {
                obj = null;
            }

        }
        LogUtil.printResult("changeAccountPwd", server.getServerIp(), "修改帐号密码" + account.getAccountNo() + ",返回结果" + rs);
        return rs;
    }

    /*
     * (non-Javadoc)change user's groups member
     * @see para.account.Interface.IResourceProcessor#changeAccountGroup(para.account.bean.RemoteService, para.account.bean.Account)
     */
    @Override
    public String changeAccountGroup(RemoteService server, Account account) {
        LogUtil.printTermParamMsg("ResourceProcessor", "changeAccountGroup", account, null);
        if (!printMsg(server, "changeAccountGroup")) {
            LogUtil.printMsg("ResourceProcessor", "changeAccountGroup", server.getServerIp(), "RemoteService对象参数不全.");
            LogUtil.printResult("changeAccountGroup", server.getServerIp(), "由于RemoteService对象参数不全,返回Invalid Parameter");
            return "Invalid parameter:RemoteServer Parameters incomplete";
        } else if (account == null || StringUtil.isNullOrBlank(account.getAccountNo())) {
            LogUtil.printMsg("ResourceProcessor", "changeAccountGroup", server.getServerIp(), "Account对象为空或accountNo为空.");
            LogUtil.printResult("changeAccountGroup", server.getServerIp(), "由于Account对象为空或accountNo为空,返回Invalid Parameter");
            return "Invalid parameter:Account Parameters incomplete";
        }
        StringBuilder groups = new StringBuilder();
        if (account.getGroups() != null && account.getGroups().size() > 0) {
            for (Group group : account.getGroups()) {
                if (group.getGroupName().equalsIgnoreCase("users")) {
                    continue;
                }
                if (groups.length() == 0) {
                    groups.append(group.getGroupName());
                } else {
                    groups.append(",").append(group.getGroupName());
                }
                //groups += group.getGroupName() + ",";
            }
            //if (groups != null && (!"".equals(groups))) {
            //	groups = groups.substring(0, groups.length() - 1);
            //}
        }
        SshConnection ssh = null;
        try {
            if (server.getConnType() == null
                    || server.getConnType().trim().equals("")
                    || server.getConnType().trim().toLowerCase().equals("ssh")) {
                ssh = new SshConnection(server.getServerIp().trim(),
                        server.getPort(), server.getLoginName().trim(), server
                        .getLoginPwd());
                CommandStatement stat = ssh.createCommandInteractive();
                rs = stat.modifyUserGroup(account.getAccountNo().trim(), groups.toString(), server.isSudo());
            } else {
                TelnetConnection obj = new TelnetConnection(server.getServerIp().trim(), server.getPort(), server.getLoginName().trim(), server.getLoginPwd());
                TelnetStatement stat = obj.createCommand();
                rs = stat.modifyUserGroup(account.getAccountNo().trim(), groups.toString(), server.isSudo());
            }
            if (rs != null && "".equals(rs.trim())) {
                rs = "Finished: no return value";
                log.info(rs);
            }
        } catch (Exception e) {
            LogUtil.printMsg("ResourceProcessor", "changeAccountGroup", server.getServerIp(), "修改帐号" + account.getAccountNo() + "的组成员发生异常:" + e);
            rs = e.getLocalizedMessage();
        } finally {
            if (ssh != null) {
                ssh.closeConnection();
                ssh = null;
            }
        }
        LogUtil.printResult("changeAccountGroup", server.getServerIp(), "修改帐号" + account.getAccountNo() + "的组成员,返回结果" + rs);
        return rs;
    }

    /*
     * (non-Javadoc) change Group's account member
     * @see para.account.Interface.IResourceProcessor#changeGroupMember(para.account.bean.RemoteService, para.account.bean.Group, int)
     */
    @Override
    public String changeGroupMember(RemoteService server, Group group, int type) throws Exception {
        LogUtil.printTermParamMsg("ResourceProcessor", "changeGroupMember", null, group);
        if (!printMsg(server, "changeGroupMember")) {
            LogUtil.printMsg("ResourceProcessor", "changeGroupMember", server.getServerIp(), "RemoteService对象参数不全.");
            LogUtil.printResult("changeGroupMember", server.getServerIp(), "由于RemoteService对象参数不全,返回Invalid Parameter");
            return "Invalid parameter:RemoteServer Parameters incomplete";

        } else if (group == null || StringUtil.isNullOrBlank(group.getGroupName())) {
            LogUtil.printMsg("ResourceProcessor", "changeGroupMember", server.getServerIp(), "Group对象为空或groupName为空.");
            LogUtil.printResult("changeGroupMember", server.getServerIp(), "Group对象为空或groupName为空,返回Invalid Parameter");
            return "Invalid parameter:Group Parameters incomplete";
        }
        String msg = "";
        List<Account> listAccount = group.getAccounts();
        if (listAccount != null && listAccount.size() > 0) {
            for (Account account : listAccount) {
                Account accountObj = this.findAccountByNo(server, account.getAccountNo());
                if (accountObj == null) {
                    continue;
                }
                String groups = "";
                if (accountObj.getGroups() != null && accountObj.getGroups().size() > 0) {
                    for (Group groupObj : accountObj.getGroups()) {
                        if (type != 0 && groupObj.getGroupName().equals(group.getGroupName())) {
                            continue;
                        } else if (groupObj.getGroupName().equalsIgnoreCase("users")) {
                            continue;
                        } else {
                            if (groupObj.getGroupName().equals(group.getGroupName())) {
                                continue;
                            }
                        }
                        groups += groupObj.getGroupName() + ",";
                    }
                }

                if (type == 0) {
                    groups += group.getGroupName();
                } else {
                    if (!StringUtil.isNullOrBlank(groups)) {
                        groups = groups.substring(0, groups.length() - 1);
                    }
                }

                String rs = "";
                SshConnection ssh = null;
                try {
                    if (server.getConnType() == null || server.getConnType().trim().equals("") || server.getConnType().trim().toLowerCase().equals("ssh")) {
                        ssh = new SshConnection(server.getServerIp().trim(), server.getPort(), server.getLoginName().trim(), server.getLoginPwd());
                        CommandStatement stat = ssh.createCommandInteractive();
                        rs = stat.modifyUserGroup(account.getAccountNo().trim(), groups, server.isSudo());
                    } else {
                        TelnetConnection obj = new TelnetConnection(server.getServerIp().trim(), server.getPort(), server.getLoginName().trim(), server.getLoginPwd());
                        TelnetStatement stat = obj.createCommand();
                        rs = stat.modifyUserGroup(account.getAccountNo().trim(), groups, server.isSudo());
                    }
                } catch (Exception e) {
                    log.error("para.linux.Impl.ResourceProcessor->changeGroupMember() type:" + server.getConnType() + ",IP:" + server.getServerIp() + ",AccountNo:" + account.getAccountNo() + " Error:" + e);
                    throw e;
                } finally {
                    if (ssh != null) {
                        ssh.closeConnection();
                        ssh = null;
                    }
                }
                if (rs != null && rs.equals("SUCCESS")) {
                    continue;
                } else {
                    if (rs != null && "".equals(rs.trim())) {
                        rs = "Finished: no return value";
                        log.info(rs);
                    }
                    msg += account.getAccountNo() + "'s group change fail:" + rs + "";
                }
            }
        }
        LogUtil.printResult("changeGroupMember", server.getServerIp(), "修改组" + group.getGroupName() + "的帐号成员,返回结果" + msg);
        if (msg == "") {
            return "SUCCESS";
        }
        return msg;
    }

    /*
     * (non-Javadoc)delete Account
     * @see para.account.Interface.IResourceProcessor#deleteAccount(para.account.bean.RemoteService, java.lang.String)
     */
    @Override
    public String deleteAccount(RemoteService server, String accountNo) {
        LogUtil.printTermParamMsg("ResourceProcessor", "deleteAccount", "accountNo", accountNo);
        if (!printMsg(server, "deleteAccount")) {
            LogUtil.printMsg("ResourceProcessor", "deleteAccount", server.getServerIp(), "RemoteService对象参数不全.");
            LogUtil.printResult("deleteAccount", server.getServerIp(), "由于RemoteService对象参数不全,返回Invalid Parameter");
            return "Invalid parameter:RemoteServer Parameters incomplete";

        } else if (StringUtil.isNullOrBlank(accountNo)) {
            LogUtil.printMsg("ResourceProcessor", "deleteAccount", server.getServerIp(), "删除条件accountNo为空.");
            LogUtil.printResult("deleteAccount", server.getServerIp(), "由于accountNo为空,返回Invalid Parameter");
            return "Invalid parameter:account's No Parameters incomplete";
        }
        SshConnection ssh = null;
        try {
            if (server.getConnType() == null || server.getConnType().trim().equals("") || server.getConnType().trim().toLowerCase().equals("ssh")) {
                ssh = new SshConnection(server.getServerIp().trim(), server.getPort(), server.getLoginName().trim(), server.getLoginPwd());
                CommandStatement stat = ssh.createCommandInteractive();
                rs = stat.deleteUser(accountNo.trim(), server.isSudo());
            } else {
                TelnetConnection obj = new TelnetConnection(server.getServerIp().trim(), server.getPort(), server.getLoginName().trim(), server.getLoginPwd());
                TelnetStatement stat = obj.createCommand();
                rs = stat.deleteUser(accountNo.trim(), server.isSudo());
            }
            if (rs != null && "".equals(rs.trim())) {
                rs = "Finished: no return value";
                log.info(rs);
            }
        } catch (Exception e) {
            LogUtil.printMsg("ResourceProcessor", "deleteAccount", server.getServerIp(), "删除帐号" + accountNo + "发生异常:" + e);
            rs = e.getLocalizedMessage();
        } finally {
            if (ssh != null) {
                ssh.closeConnection();
                ssh = null;
            }
        }
        LogUtil.printResult("deleteAccount", server.getServerIp(), "删除帐号" + accountNo + ",返回结果" + rs);
        return rs;
    }

    /*
     * (non-Javadoc)suppend user
     * @see para.account.Interface.IResourceProcessor#stopAccount(para.account.bean.RemoteService, java.lang.String)
     */
    @Override
    public String stopAccount(RemoteService server, String accountNo) {
        LogUtil.printTermParamMsg("ResourceProcessor", "stopAccount", "accountNo", accountNo);
        if (!printMsg(server, "stopAccount")) {
            LogUtil.printMsg("ResourceProcessor", "stopAccount", server.getServerIp(), "RemoteService对象参数不全.");
            LogUtil.printResult("stopAccount", server.getServerIp(), "由于RemoteService对象参数不全,返回Invalid Parameter");
            return "Invalid parameter:RemoteServer Parameters incomplete";

        } else if (StringUtil.isNullOrBlank(accountNo)) {
            LogUtil.printMsg("ResourceProcessor", "stopAccount", server.getServerIp(), "冻结条件accountNo为空.");
            LogUtil.printResult("stopAccount", server.getServerIp(), "由于冻结条件accountNo为空,返回Invalid Parameter");
            return "Invalid parameter:account's No Parameters incomplete";
        }
        SshConnection ssh = null;
        try {
            if (server.getConnType() == null || server.getConnType().trim().equals("") || server.getConnType().trim().toLowerCase().equals("ssh")) {
                ssh = new SshConnection(server.getServerIp().trim(), server.getPort(), server.getLoginName().trim(), server.getLoginPwd());
                CommandStatement stat = ssh.createCommandInteractive();
                rs = stat.suppendUser(accountNo.trim(), server.isSudo());
            } else {
                TelnetConnection obj = new TelnetConnection(server.getServerIp().trim(), server.getPort(), server.getLoginName().trim(), server.getLoginPwd());
                TelnetStatement stat = obj.createCommand();
                rs = stat.suppendUser(accountNo.trim(), server.isSudo());
            }
            if (rs != null && "".equals(rs.trim())) {
                rs = "Finished: no return value";
                log.info(rs);
            }
        } catch (Exception e) {
            LogUtil.printMsg("ResourceProcessor", "stopAccount", server.getServerIp(), "冻结帐号" + accountNo + "发生异常:" + e);
            rs = e.getLocalizedMessage();
        } finally {
            if (ssh != null) {
                ssh.closeConnection();
                ssh = null;
            }
        }
        LogUtil.printResult("stopAccount", server.getServerIp(), "冻结帐号" + accountNo + ",返回结果" + rs);
        return rs;

    }

    /*
     * (non-Javadoc)restore user
     * @see para.account.Interface.IResourceProcessor#startAccount(para.account.bean.RemoteService, java.lang.String, java.lang.String)
     */
    @Override
    public String startAccount(RemoteService server, String accountNo, String oldPwd) {
        LogUtil.printTermParamMsg("ResourceProcessor", "startAccount", "accountNo", accountNo);
        if (!printMsg(server, "startAccount")) {
            LogUtil.printMsg("ResourceProcessor", "startAccount", server.getServerIp(), "RemoteService对象参数不全.");
            LogUtil.printResult("startAccount", server.getServerIp(), "由于RemoteService对象参数不全,返回Invalid Parameter");
            return "Invalid parameter:RemoteServer Parameters incomplete";

        } else if (StringUtil.isNullOrBlank(accountNo)) {
            LogUtil.printMsg("ResourceProcessor", "startAccount", server.getServerIp(), "恢复条件accountNo为空.");
            LogUtil.printResult("startAccount", server.getServerIp(), "由于恢复条件accountNo为空,返回Invalid Parameter");
            return "Invalid parameter:account's No Parameters incomplete";
        }
        SshConnection ssh = null;
        try {
            if (server.getConnType() == null || server.getConnType().trim().equals("") || server.getConnType().trim().toLowerCase().equals("ssh")) {
                ssh = new SshConnection(server.getServerIp().trim(), server.getPort(), server.getLoginName().trim(), server.getLoginPwd());
                CommandStatement stat = ssh.createCommandInteractive();
                rs = stat.restoreUser(accountNo.trim(), server.isSudo());
            } else {
                TelnetConnection obj = new TelnetConnection(server.getServerIp().trim(), server.getPort(), server.getLoginName().trim(), server.getLoginPwd());
                TelnetStatement stat = obj.createCommand();
                rs = stat.restoreUser(accountNo.trim(), server.isSudo());
            }
            if (rs != null && "".equals(rs.trim())) {
                rs = "Finished: no return value";
                log.info(rs);
            }
        } catch (Exception e) {
            LogUtil.printMsg("ResourceProcessor", "startAccount", server.getServerIp(), "恢复帐号" + accountNo + "发生异常:" + e);
            rs = e.getLocalizedMessage();
        } finally {
            if (ssh != null) {
                ssh.closeConnection();
                ssh = null;
            }
        }
        LogUtil.printResult("startAccount", server.getServerIp(), "恢复帐号" + accountNo + ",返回结果" + rs);
        return rs;
    }

    /*
     * (non-Javadoc)add Group
     * @see para.account.Interface.IResourceProcessor#addGroup(para.account.bean.RemoteService, para.account.bean.Group)
     */
    @Override
    public String addGroup(RemoteService server, Group group) {
        LogUtil.printTermParamMsg("ResourceProcessor", "addGroup", null, group);
        if (!printMsg(server, "addGroup")) {
            LogUtil.printMsg("ResourceProcessor", "addGroup", server.getServerIp(), "RemoteService对象参数不全.");
            LogUtil.printResult("addGroup", server.getServerIp(), "由于RemoteService对象参数不全,返回Invalid Parameter");
            return "Invalid parameter:RemoteServer Parameters incomplete";
        } else if (group == null || StringUtil.isNullOrBlank(group.getGroupName())) {
            LogUtil.printMsg("ResourceProcessor", "addGroup", server.getServerIp(), "Group对象为空或groupName为空.");
            LogUtil.printResult("addGroup", server.getServerIp(), "由于Group对象为空或groupName为空,返回Invalid Parameter");
            return "Invalid parameter:Group Parameters incomplete";
        }
        SshConnection ssh = null;
        try {
            if (server.getConnType() == null
                    || server.getConnType().trim().equals("")
                    || server.getConnType().trim().toLowerCase().equals("ssh")) {
                ssh = new SshConnection(server.getServerIp().trim(),
                        server.getPort(), server.getLoginName().trim(), server
                        .getLoginPwd());
                CommandStatement stat = ssh.createCommandInteractive();
                rs = stat.addGroup(group.getGroupName().trim(), server.isSudo());
            } else {
                TelnetConnection obj = new TelnetConnection(server.getServerIp()
                        .trim(), server.getPort(), server.getLoginName().trim(),
                        server.getLoginPwd());
                TelnetStatement stat = obj.createCommand();
                rs = stat.addGroup(group.getGroupName().trim(), server.isSudo());
            }
            if (rs != null && "".equals(rs.trim())) {
                rs = "Finished: no return value";
            }
        } catch (Exception e) {
            LogUtil.printMsg("ResourceProcessor", "addGroup", server.getServerIp(), "添加帐号组" + group.getGroupName() + "发生异常:" + e);
            rs = e.getLocalizedMessage();
        } finally {
            if (ssh != null) {
                ssh.closeConnection();
                ssh = null;
            }
        }
        LogUtil.printResult("addGroup", server.getServerIp(), "添加帐号组" + group.getGroupName() + ",返回结果" + rs);
        return rs;
    }

    /*
     * (non-Javadoc)delete Group
     * @see para.account.Interface.IResourceProcessor#deleteGroup(para.account.bean.RemoteService, para.account.bean.Group)
     */
    @Override
    public String deleteGroup(RemoteService server, Group group) {
        LogUtil.printTermParamMsg("ResourceProcessor", "deleteGroup", null, group);
        if (!printMsg(server, "deleteGroup")) {
            LogUtil.printMsg("ResourceProcessor", "deleteGroup", server.getServerIp(), "RemoteService对象参数不全.");
            LogUtil.printResult("deleteGroup", server.getServerIp(), "由于RemoteService对象参数不全,返回Invalid Parameter");
            return "Invalid parameter:RemoteServer Parameters incomplete";
        } else if (group == null || StringUtil.isNullOrBlank(group.getGroupName())) {
            LogUtil.printMsg("ResourceProcessor", "deleteGroup", server.getServerIp(), "Group对象为空或groupName为空.");
            LogUtil.printResult("deleteGroup", server.getServerIp(), "由于Group对象为空或groupName为空,返回Invalid Parameter");
            return "Invalid parameter:Group Parameters incomplete";
        }
        SshConnection ssh = null;
        try {
            if (server.getConnType() == null
                    || server.getConnType().trim().equals("")
                    || server.getConnType().trim().toLowerCase().equals("ssh")) {
                ssh = new SshConnection(server.getServerIp().trim(),
                        server.getPort(), server.getLoginName().trim(), server
                        .getLoginPwd());
                CommandStatement stat = ssh.createCommandInteractive();
                rs = stat.deleteGroup(group.getGroupName().trim(), server
                        .isSudo());
            } else {
                TelnetConnection obj = new TelnetConnection(server.getServerIp()
                        .trim(), server.getPort(), server.getLoginName().trim(),
                        server.getLoginPwd());
                TelnetStatement stat = obj.createCommand();
                rs = stat.deleteGroup(group.getGroupName().trim(), server
                        .isSudo());
            }
            if (rs != null && "".equals(rs.trim())) {
                rs = "Finished: no return value";
                log.info(rs);
            }
        } catch (Exception e) {
            LogUtil.printMsg("ResourceProcessor", "deleteGroup", server.getServerIp(), "删除帐号组" + group.getGroupName() + "发生异常:" + e);
            return e.getLocalizedMessage();
        } finally {
            if (ssh != null) {
                ssh.closeConnection();
                ssh = null;
            }
        }
        LogUtil.printResult("deleteGroup", server.getServerIp(), "删除帐号组" + group.getGroupName() + ",返回结果" + rs);
        return rs;

    }


    @Override
    public boolean isExitAccount(RemoteService server, String accountNo) {
        if (!ObjectCheck.checkParam(server)) {
            log.error("ResourceProcessor->isExitAccount(): invalid parameter:parameter is missing");
            return false;
        }
        String rs = "";
        try {
            if (server.getConnType() == null
                    || server.getConnType().trim().equals("")
                    || server.getConnType().trim().toLowerCase().equals("ssh")) {
                CommandQuery cmdQuery = CommandQuery.getInstance(server
                        .getServerIp().trim(), server.getPort(), server
                        .getLoginName().trim(), server.getLoginPwd());
                return cmdQuery.isExitAccount(accountNo.trim());
            } else {
                TelnetQuery cmdQuery = TelnetQuery.getInstance(server.getServerIp()
                                .trim(), server.getPort(), server.getLoginName().trim(),
                        server.getLoginPwd());
                return cmdQuery.isExitAccount(accountNo.trim());
            }
        } catch (Exception e) {
            log.error("ResourceProcessor->isExitAccount() type:" + server.getConnType() + ",IP:" + server.getServerIp() + ",accountNo:" + accountNo + " Error:" + e);
            return false;
        }
    }


    @Override
    public boolean isExitGroup(RemoteService server, String groupName) {
        if (!ObjectCheck.checkParam(server)) {
            log.error("ResourceProcessor->isExitGroup(): invalid parameter:parameter is missing");
            return false;
        }
        String rs = "";
        try {
            if (server.getConnType() == null
                    || server.getConnType().trim().equals("")
                    || server.getConnType().trim().toLowerCase().equals("ssh")) {
                CommandQuery cmdQuery = CommandQuery.getInstance(server
                        .getServerIp().trim(), server.getPort(), server
                        .getLoginName().trim(), server.getLoginPwd());
                return cmdQuery.isExitGroup(groupName.trim());
            } else {
                TelnetQuery cmdQuery = TelnetQuery.getInstance(server.getServerIp()
                                .trim(), server.getPort(), server.getLoginName().trim(),
                        server.getLoginPwd());
                return cmdQuery.isExitGroup(groupName.trim());
            }
        } catch (Exception e) {
            log.error("ResourceProcessor->isExitGroup() type:" + server.getConnType() + ",IP:" + server.getServerIp() + ",groupName:" + groupName + " Error:" + e);
            return false;
        }
    }


    @Override
    public List<String> queryAllDB(RemoteService arg0) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getNameSpecialStr() {
        return PropertiesUtils.getResourceValue("nameSpecialStr");
    }


    @Override
    public String getPwdSpecialStr() {
        // TODO Auto-generated method stub
        return PropertiesUtils.getResourceValue("pwdSpecialStr");
    }

    @Override
    public String addAccount4Key(RemoteService server, Account account) {
        log.info("Linux 资源开始新增加帐号[" + account.getAccountNo() + "]");
        log.debug("Linux 资源开始新增加帐号[" + account.getAccountNo() + "] 密码[" + account.getPwd() + "]");
        LogUtil.printTermParamMsg("ResourceProcessor", "addAccount4Key", account, null);
        if (!printMsg4Key(server, "addAccount4Key")) {
            LogUtil.printMsg("ResourceProcessor", "addAccount4Key", server.getServerIp(), "RemoteService对象参数不全.");
            LogUtil.printResult("addAccount4Key", server.getServerIp(), "由于RemoteService对象参数不全,返回Invalid Parameter");
            return "Invalid parameter:RemoteServer Parameters incomplete";
        } else if (account == null || StringUtil.isNullOrBlank(account.getAccountNo())) {
            LogUtil.printMsg("ResourceProcessor", "addAccount4Key", server.getServerIp(), "Account对象为空或accountNo为空.");
            LogUtil.printResult("addAccount4Key", server.getServerIp(), "由于Account对象为空或accountNo为空,返回Invalid Parameter");
            return "Invalid parameter:Account Parameters incomplete";
        }
        String checkMsg = checkDollarInAccountNo(account.getAccountNo().trim());
        if (!StringUtil.isNullOrBlank(checkMsg)) {
            return checkMsg;
        }

        String groups = "";
        if (account.getGroups() != null && account.getGroups().size() > 0) {
            for (Group group : account.getGroups()) {
                if (!account.getAccountNo().trim().equalsIgnoreCase(group.getGroupName())) {
                    groups += group.getGroupName() + ",";
                } else {
                    log.info("新增加帐号[" + account.getAccountNo() + "]时，手工选择了增加一个组[" + group.getGroupName() + "] 这个是错误，该组会自动添加，无需手工添加");
                }

            }
            if (groups != null && groups.length() > 0) {
                groups = groups.substring(0, groups.length() - 1);
            }
        }
        boolean isPrimaryGroupExist = false;
        log.info("增加帐号前，先判断该帐号[" + account.getAccountNo() + "]的默认组是否存在");
        if (this.isExitGroup(server, account.getAccountNo().trim())) {
            log.info("该帐号组[" + account.getAccountNo().trim() + "]存在，增加帐号时需要-g参数");
            isPrimaryGroupExist = true;
        } else {
            log.info("该帐号组[" + account.getAccountNo().trim() + "]不存在");
            isPrimaryGroupExist = false;
        }
        SshConnection ssh = null;
        try {
            ssh = new SshConnection(server
                    .getServerIp().trim(), server.getPort(), server
                    .getLoginName().trim(), server.getKeyPwd(), server
                    .getKeyUrl());
            CommandStatement stat = ssh.createCommandInteractive4Key();
            rs = stat.addUser(account.getAccountNo().trim(), account.getPwd(), groups, server.isSudo(), isPrimaryGroupExist);
            log.info("ssh mode addAccount complete " + rs);
            if (rs != null && "".equals(rs.trim())) {
                rs = "Finished: no return value";
            }
        } catch (Exception e) {
            LogUtil.printMsg("ResourceProcessor", "addAccount", server.getServerIp(), "添加帐号" + account.getAccountNo() + "发生异常:" + e);
            rs = e.getLocalizedMessage();
        } finally {
            if (ssh != null) {
                ssh.closeConnection();
                ssh = null;
            }
        }
        LogUtil.printResult("addAccount", server.getServerIp(), "添加帐号:" + account.getAccountNo() + ",返回结果" + rs);
//		if(rs!=null && rs.equalsIgnoreCase("SUCCESS")){
//			log.info("addAccount success!");
//			log.info("addAccount success after testConnect...");
//			RemoteService testServer = new RemoteService(server.getServerIp(),server.getPort(),account.getAccountNo().trim(),account.getPwd(),server.getConnType(),server.isSudo());
//			log.info("start testConnect...");
//			boolean ret = this.testConnect(testServer);
//			if(ret){
//				log.info("testConnect successfull!");
//				rs = "SUCCESS";
//			}else{
//				rs = "Add account success after testConnect fFailure,please check!";
//			}
//			log.info("end testConnect");
//		}
        return rs;
    }

    @Override
    public String addGroup4Key(RemoteService server, Group group) {
        LogUtil.printTermParamMsg("ResourceProcessor", "addGroup4Key", null, group);
        if (!printMsg4Key(server, "addGroup4Key")) {
            LogUtil.printMsg("ResourceProcessor", "addGroup4Key", server.getServerIp(), "RemoteService对象参数不全.");
            LogUtil.printResult("addGroup4Key", server.getServerIp(), "由于RemoteService对象参数不全,返回Invalid Parameter");
            return "Invalid parameter:RemoteServer Parameters incomplete";
        } else if (group == null || StringUtil.isNullOrBlank(group.getGroupName())) {
            LogUtil.printMsg("ResourceProcessor", "addGroup4Key", server.getServerIp(), "Group对象为空或groupName为空.");
            LogUtil.printResult("addGroup4Key", server.getServerIp(), "由于Group对象为空或groupName为空,返回Invalid Parameter");
            return "Invalid parameter:Group Parameters incomplete";
        }
        SshConnection ssh = null;
        try {
            ssh = new SshConnection(server
                    .getServerIp().trim(), server.getPort(), server
                    .getLoginName().trim(), server.getKeyPwd(), server
                    .getKeyUrl());
            CommandStatement stat = ssh.createCommandInteractive4Key();
            rs = stat.addGroup(group.getGroupName().trim(), server.isSudo());
            if (rs != null && "".equals(rs.trim())) {
                rs = "Finished: no return value";
            }
        } catch (Exception e) {
            LogUtil.printMsg("ResourceProcessor", "addGroup", server.getServerIp(), "添加帐号组" + group.getGroupName() + "发生异常:" + e);
            rs = e.getLocalizedMessage();
        } finally {
            if (ssh != null) {
                ssh.closeConnection();
                ssh = null;
            }
        }
        LogUtil.printResult("addGroup", server.getServerIp(), "添加帐号组" + group.getGroupName() + ",返回结果" + rs);
        return rs;
    }

    @Override
    public String changeAccountGroup4Key(RemoteService server, Account account) {
        LogUtil.printTermParamMsg("ResourceProcessor", "changeAccountGroup4Key", account, null);
        if (!printMsg4Key(server, "changeAccountGroup4Key")) {
            LogUtil.printMsg("ResourceProcessor", "changeAccountGroup4Key", server.getServerIp(), "RemoteService对象参数不全.");
            LogUtil.printResult("changeAccountGroup4Key", server.getServerIp(), "由于RemoteService对象参数不全,返回Invalid Parameter");
            return "Invalid parameter:RemoteServer Parameters incomplete";
        } else if (account == null || StringUtil.isNullOrBlank(account.getAccountNo())) {
            LogUtil.printMsg("ResourceProcessor", "changeAccountGroup4Key", server.getServerIp(), "Account对象为空或accountNo为空.");
            LogUtil.printResult("changeAccountGroup4Key", server.getServerIp(), "由于Account对象为空或accountNo为空,返回Invalid Parameter");
            return "Invalid parameter:Account Parameters incomplete";
        }
        StringBuilder groups = new StringBuilder();
        if (account.getGroups() != null && account.getGroups().size() > 0) {
            for (Group group : account.getGroups()) {
                if (group.getGroupName().equalsIgnoreCase("users")) {
                    continue;
                }
                if (groups.length() == 0) {
                    groups.append(group.getGroupName());
                } else {
                    groups.append(",").append(group.getGroupName());
                }
                //groups += group.getGroupName() + ",";
            }
            //if (groups != null && (!"".equals(groups))) {
            //	groups = groups.substring(0, groups.length() - 1);
            //}
        }
        SshConnection ssh = null;
        try {
            ssh = new SshConnection(server
                    .getServerIp().trim(), server.getPort(), server
                    .getLoginName().trim(), server.getKeyPwd(), server
                    .getKeyUrl());
            CommandStatement stat = ssh.createCommandInteractive4Key();
            rs = stat.modifyUserGroup(account.getAccountNo().trim(), groups.toString(), server.isSudo());
            if (rs != null && "".equals(rs.trim())) {
                rs = "Finished: no return value";
                log.info(rs);
            }
        } catch (Exception e) {
            LogUtil.printMsg("ResourceProcessor", "changeAccountGroup", server.getServerIp(), "修改帐号" + account.getAccountNo() + "的组成员发生异常:" + e);
            rs = e.getLocalizedMessage();
        } finally {
            if (ssh != null) {
                ssh.closeConnection();
                ssh = null;
            }
        }
        LogUtil.printResult("changeAccountGroup", server.getServerIp(), "修改帐号" + account.getAccountNo() + "的组成员,返回结果" + rs);
        return rs;
    }

    @Override
    public String changeAccountPwd4Key(RemoteService server, Account account) {
        LogUtil.printTermParamMsg("RemoteProcessor", "changeAccountPwd4Key",
                account, null);
        if (!printMsg4Key(server, "changeAccountPwd4Key")) {
            LogUtil.printMsg("RemoteProcessor", "changeAccountPwd4Key", server
                    .getServerIp(), "RemoteService对象参数不全.");
            LogUtil.printResult("changeAccountPwd4Key", server.getServerIp(),
                    "由于RemoteService对象参数为空,返回Invalid Parameter");
            return "Invalid parameter:RemoteServer Parameters incomplete";
        }
        if ((account == null)
                || (StringUtil.isNullOrBlank(account.getAccountNo()))) {
            LogUtil.printMsg("RemoteProcessor", "changeAccountPwd4Key", server
                    .getServerIp(), "Account对象为空或accountNo为空.");
            LogUtil.printResult("changeAccountPwd4Key", server.getServerIp(),
                    "由于Account对象为空或accountNo为空,返回Invalid Parameter");
            return "Invalid parameter:Account Parameters incomplete";
        }
        try {
            CommandQuery cmdQuery = CommandQuery.getInstance(server
                    .getServerIp().trim(), server.getPort(), server
                    .getLoginName().trim(), server.getKeyPwd(), server
                    .getKeyUrl());
            this.rs = cmdQuery.modifyUserPwd(account.getAccountNo().trim(),
                    account.getPwd());
            //Changing password for user ert.
            //passwd: all authentication tokens updated successfully.
            //echo "mysq:1234" | chpasswd 兼容版本的修改密码命令   之前的--stdin在suse中不会被识别  无返回值
//			if (this.rs != null) {
//				if(rs.contains("Changing password") || rs.contains("successfully") ||(rs.contains("所有的身份验证令牌已经成功更新")&&rs.contains("密码"))){
//					this.rs = "SUCCESS";
//					log.info(this.rs);
//				}
//				
//			}
            //echo "mysq:1234" | chpasswd 兼容版本的修改密码命令   之前的--stdin在suse中不会被识别  无返回值
            if ((this.rs != null) && ("".equals(this.rs.trim()))) {
                this.rs = "SUCCESS";
                log.info(this.rs);
            }
        } catch (Exception e) {
            LogUtil.printMsg("PartitionProcessor", "changeAccountPwd", server
                    .getServerIp(), "修改帐号密码" + account.getAccountNo() + "发生异常:"
                    + e);
            this.rs = e.getMessage();
            log.error(this.rs);
        }

        LogUtil.printResult("changeAccountPwd", server.getServerIp(), "修改帐号密码"
                + account.getAccountNo() + ",返回结果" + this.rs);

        return this.rs;
    }

    @Override
    public String changeGroupMember4Key(RemoteService server, Group group, int type)
            throws Exception {
        LogUtil.printTermParamMsg("ResourceProcessor", "changeGroupMember4Key", null, group);
        if (!printMsg4Key(server, "changeGroupMember4Key")) {
            LogUtil.printMsg("ResourceProcessor", "changeGroupMember4Key", server.getServerIp(), "RemoteService对象参数不全.");
            LogUtil.printResult("changeGroupMember4Key", server.getServerIp(), "由于RemoteService对象参数不全,返回Invalid Parameter");
            return "Invalid parameter:RemoteServer Parameters incomplete";

        } else if (group == null || StringUtil.isNullOrBlank(group.getGroupName())) {
            LogUtil.printMsg("ResourceProcessor", "changeGroupMember4Key", server.getServerIp(), "Group对象为空或groupName为空.");
            LogUtil.printResult("changeGroupMember4Key", server.getServerIp(), "Group对象为空或groupName为空,返回Invalid Parameter");
            return "Invalid parameter:Group Parameters incomplete";
        }
        String msg = "";
        List<Account> listAccount = group.getAccounts();
        if (listAccount != null && listAccount.size() > 0) {
            for (Account account : listAccount) {
                Account accountObj = this.findAccountByNo4Key(server, account.getAccountNo());
                if (accountObj == null) {
                    continue;
                }
                String groups = "";
                if (accountObj.getGroups() != null && accountObj.getGroups().size() > 0) {
                    for (Group groupObj : accountObj.getGroups()) {
                        if (type != 0 && groupObj.getGroupName().equals(group.getGroupName())) {
                            continue;
                        } else if (groupObj.getGroupName().equalsIgnoreCase("users")) {
                            continue;
                        } else {
                            if (groupObj.getGroupName().equals(group.getGroupName())) {
                                continue;
                            }
                        }
                        groups += groupObj.getGroupName() + ",";
                    }
                }

                if (type == 0) {
                    groups += group.getGroupName();
                } else {
                    if (!StringUtil.isNullOrBlank(groups)) {
                        groups = groups.substring(0, groups.length() - 1);
                    }
                }

                String rs = "";
                SshConnection ssh = null;
                try {
                    ssh = new SshConnection(server
                            .getServerIp().trim(), server.getPort(), server
                            .getLoginName().trim(), server.getKeyPwd(), server
                            .getKeyUrl());
                    CommandStatement stat = ssh.createCommandInteractive4Key();
                    rs = stat.modifyUserGroup(account.getAccountNo().trim(), groups, server.isSudo());
                } catch (Exception e) {
                    log.error("para.linux.Impl.ResourceProcessor->changeGroupMember() type:" + server.getConnType() + ",IP:" + server.getServerIp() + ",AccountNo:" + account.getAccountNo() + " Error:" + e);
                    throw e;
                } finally {
                    if (ssh != null) {
                        ssh.closeConnection();
                        ssh = null;
                    }
                }
                if (rs != null && rs.equals("SUCCESS")) {
                    continue;
                } else {
                    if (rs != null && "".equals(rs.trim())) {
                        rs = "Finished: no return value";
                        log.info(rs);
                    }
                    msg += account.getAccountNo() + "'s group change fail:" + rs + "";
                }
            }
        }
        LogUtil.printResult("changeGroupMember", server.getServerIp(), "修改组" + group.getGroupName() + "的帐号成员,返回结果" + msg);
        if (msg == "") {
            return "SUCCESS";
        }
        return msg;
    }

    @Override
    public String deleteAccount4Key(RemoteService server, String accountNo) {
        LogUtil.printTermParamMsg("ResourceProcessor", "deleteAccount4Key", "accountNo", accountNo);
        if (!printMsg4Key(server, "deleteAccount4Key")) {
            LogUtil.printMsg("ResourceProcessor", "deleteAccount4Key", server.getServerIp(), "RemoteService对象参数不全.");
            LogUtil.printResult("deleteAccount4Key", server.getServerIp(), "由于RemoteService对象参数不全,返回Invalid Parameter");
            return "Invalid parameter:RemoteServer Parameters incomplete";

        } else if (StringUtil.isNullOrBlank(accountNo)) {
            LogUtil.printMsg("ResourceProcessor", "deleteAccount4Key", server.getServerIp(), "删除条件accountNo为空.");
            LogUtil.printResult("deleteAccount4Key", server.getServerIp(), "由于accountNo为空,返回Invalid Parameter");
            return "Invalid parameter:account's No Parameters incomplete";
        }
        SshConnection ssh = null;
        try {
            ssh = new SshConnection(server
                    .getServerIp().trim(), server.getPort(), server
                    .getLoginName().trim(), server.getKeyPwd(), server
                    .getKeyUrl());
            CommandStatement stat = ssh.createCommandInteractive4Key();
            rs = stat.deleteUser(accountNo.trim(), server.isSudo());
            if (rs != null && "".equals(rs.trim())) {
                rs = "Finished: no return value";
                log.info(rs);
            }
        } catch (Exception e) {
            LogUtil.printMsg("ResourceProcessor", "deleteAccount", server.getServerIp(), "删除帐号" + accountNo + "发生异常:" + e);
            rs = e.getLocalizedMessage();
        } finally {
            if (ssh != null) {
                ssh.closeConnection();
                ssh = null;
            }
        }
        LogUtil.printResult("deleteAccount", server.getServerIp(), "删除帐号" + accountNo + ",返回结果" + rs);
        return rs;
    }

    @Override
    public String deleteGroup4Key(RemoteService server, Group group) {
        LogUtil.printTermParamMsg("ResourceProcessor", "deleteGroup4Key", null, group);
        if (!printMsg4Key(server, "deleteGroup4Key")) {
            LogUtil.printMsg("ResourceProcessor", "deleteGroup4Key", server.getServerIp(), "RemoteService对象参数不全.");
            LogUtil.printResult("deleteGroup4Key", server.getServerIp(), "由于RemoteService对象参数不全,返回Invalid Parameter");
            return "Invalid parameter:RemoteServer Parameters incomplete";
        } else if (group == null || StringUtil.isNullOrBlank(group.getGroupName())) {
            LogUtil.printMsg("ResourceProcessor", "deleteGroup4Key", server.getServerIp(), "Group对象为空或groupName为空.");
            LogUtil.printResult("deleteGroup4Key", server.getServerIp(), "由于Group对象为空或groupName为空,返回Invalid Parameter");
            return "Invalid parameter:Group Parameters incomplete";
        }
        SshConnection ssh = null;
        try {
            ssh = new SshConnection(server
                    .getServerIp().trim(), server.getPort(), server
                    .getLoginName().trim(), server.getKeyPwd(), server
                    .getKeyUrl());
            CommandStatement stat = ssh.createCommandInteractive4Key();
            rs = stat.deleteGroup(group.getGroupName().trim(), server
                    .isSudo());
            if (rs != null && "".equals(rs.trim())) {
                rs = "Finished: no return value";
                log.info(rs);
            }
        } catch (Exception e) {
            LogUtil.printMsg("ResourceProcessor", "deleteGroup", server.getServerIp(), "删除帐号组" + group.getGroupName() + "发生异常:" + e);
            return e.getLocalizedMessage();
        } finally {
            if (ssh != null) {
                ssh.closeConnection();
                ssh = null;
            }
        }
        LogUtil.printResult("deleteGroup", server.getServerIp(), "删除帐号组" + group.getGroupName() + ",返回结果" + rs);
        return rs;

    }

    @Override
    public Account findAccountByNo4Key(RemoteService server, String accountNo) {
        LogUtil.printTermParamMsg("ResourceProcessor", "findAccountByNo4Key", "accountNo", accountNo);
        if (!printMsg4Key(server, "findAccountByNo4Key")) {
            LogUtil.printMsg("ResourceProcessor", "findAccountByNo4Key", server.getServerIp(), "RemoteService对象参数不全.");
            LogUtil.printResult("findAccountByNo", server.getServerIp(), "由于RemoteService对象参数不全,返回null");
            return null;
        } else if (StringUtil.isNullOrBlank(accountNo)) {
            LogUtil.printMsg("ResourceProcessor", "findAccountByNo4Key", server.getServerIp(), "查询参数accountNo为空.");
            LogUtil.printResult("findAccountByNo4Key", server.getServerIp(), "由于查询参数accountNo为空,返回null");
            return null;
        }
        CommandQuery cmdQuery = CommandQuery.getInstance(server
                .getServerIp().trim(), server.getPort(), server
                .getLoginName().trim(), server.getKeyPwd(), server
                .getKeyUrl());
        try {
            rs = cmdQuery.queryAccountByNo4Key(accountNo.trim());
        } catch (Exception e) {
            rs = null;
        }
        if (rs == null || "".equals(rs.trim())) {
            LogUtil.printResult("findAccountByNo", server.getServerIp(), "依据accountNo:" + accountNo + "查询Account,由于查询结果rs为空,返回null");
            return null;
        } else {
            List<Group> listGroup = new ArrayList<Group>();
            String[] rsArr = rs.split(" ");
            if (rsArr != null && rsArr.length > 0) {
                for (String str : rsArr) {
                    Group group = new Group();
                    group.setGroupName(str);
                    if (!listGroup.contains(group)) {
                        listGroup.add(group);
                    }
                }
            }
            Account account = new Account();
            account.setAccountNo(accountNo);
            account.setGroups(listGroup);
            return account;
        }
    }

    @Override
    public Group findGroupByName4Key(RemoteService server, String groupName) {
        LogUtil.printTermParamMsg("ResourceProcessor", "findGroupByName4Key", "groupName", groupName);
        if (!printMsg4Key(server, "findGroupByName")) {
            LogUtil.printMsg("ResourceProcessor", "findGroupByName4Key", server.getServerIp(), "RemoteService对象参数不全.");
            LogUtil.printResult("findGroupByName4Key", server.getServerIp(), "由于RemoteService对象参数不全,返回null");
            return null;
        } else if (StringUtil.isNullOrBlank(groupName)) {
            LogUtil.printMsg("ResourceProcessor", "findGroupByName4Key", server.getServerIp(), "查询参数groupName为空.");
            LogUtil.printResult("findGroupByName4Key", server.getServerIp(), "由于查询参数groupName为空,返回null");
            return null;
        }
        CommandQuery cmdQuery = CommandQuery.getInstance(server
                .getServerIp().trim(), server.getPort(), server
                .getLoginName().trim(), server.getKeyPwd(), server
                .getKeyUrl());
        try {
            rs = cmdQuery.queryAccountByGoupName4Key(groupName.trim());
        } catch (Exception e) {
            return null;
        }
        if (rs == null || "".equals(rs.trim())) {
            LogUtil.printResult("findGroupByName", server.getServerIp(), "依据groupName:" + groupName + "查询Group,由于查询结果rs为空,返回null");
            return null;
        } else if (CommandQuery.EXITBUTNOACCOUNT__.equals(rs.trim())) {   //有组但是改组没有帐号
            Group group = new Group();
            group.setGroupName(groupName.trim());
            return group;
        } else {
            Group group = new Group();
            group.setGroupName(groupName.trim());
            List<Account> listAccount = new ArrayList<Account>();
            List<String> listStr = StringUtil.strToList(rs, ",");
            for (String str : listStr) {
                if (str == null || "".equals(str.trim())) {
                    continue;
                }
                Account account = new Account();
                account.setAccountNo(str.trim());
                listAccount.add(account);
            }
            group.setAccounts(listAccount);
            return group;
        }
    }

    @Override
    public boolean isExitAccount4Key(RemoteService server, String accountNo) {
        if (!printMsg4Key(server, "isExitGroup4Key")) {
            log.error("ResourceProcessor->isExitAccount(): invalid parameter:parameter is missing");
            return false;
        }
        try {
            CommandQuery cmdQuery = CommandQuery.getInstance(server
                    .getServerIp().trim(), server.getPort(), server
                    .getLoginName().trim(), server.getKeyPwd(), server
                    .getKeyUrl());
            return cmdQuery.isExitAccount4Key(accountNo.trim());
        } catch (Exception e) {
            log.error("ResourceProcessor->isExitAccount() type:" + server.getConnType() + ",IP:" + server.getServerIp() + ",accountNo:" + accountNo + " Error:" + e);
            return false;
        }
    }

    @Override
    public boolean isExitGroup4Key(RemoteService server, String groupName) {
        if (!printMsg4Key(server, "isExitGroup4Key")) {
            log.error("ResourceProcessor->isExitGroup(): invalid parameter:parameter is missing");
            return false;
        }
        try {
            CommandQuery cmdQuery = CommandQuery.getInstance(server
                    .getServerIp().trim(), server.getPort(), server
                    .getLoginName().trim(), server.getKeyPwd(), server
                    .getKeyUrl());
            return cmdQuery.isExitGroup4Key(groupName.trim());
        } catch (Exception e) {
            log.error("ResourceProcessor->isExitGroup() type:" + server.getConnType() + ",IP:" + server.getServerIp() + ",groupName:" + groupName + " Error:" + e);
            return false;
        }
    }

    @Override
    public List<Account> queryAllAccount4Key(RemoteService server) throws Exception {
        log.info("start queryAllAccount4Key...");
        if (!printMsg4Key(server, "queryAllAccount4Key")) {
            LogUtil.printMsg("ResourceProcessor", "queryAllAccount4Key", server.getServerIp(), "RemoteService对象参数不全.");
            LogUtil.printResult("queryAllAccount4Key", server.getServerIp(), "由于RemoteService对象参数不全,集合为空");
            return null;
        }
        List<Account> list = null;
        CommandQuery cmdQuery = CommandQuery.getInstance(server
                .getServerIp().trim(), server.getPort(), server
                .getLoginName().trim(), server.getKeyPwd(), server
                .getKeyUrl());
        if (server.openPage()) {
            log.info("query for page query reouce Account");
            list = cmdQuery.queryAllAccount4Key(server);
        } else {
            log.info("query query All resource Account");
            list = cmdQuery.queryAllAccount4Key();
        }
        if (list == null) {
            log.info("query result is null");
            list = new ArrayList<Account>();
        }
        LogUtil.printResult("queryAllAccount", server.getServerIp(), "查询集合大小：" + list.size());
        log.info("end queryAllAccount...");
        return list;
    }

    @Override
    public List<String> queryAllDB4Key(RemoteService arg0) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public List<Group> queryAllGroup4Key(RemoteService server) throws Exception {
        log.info("start query resource group!");
        if (!printMsg4Key(server, "queryAllGroup4Key")) {
            LogUtil.printMsg("ResourceProcessor", "queryAllGroup4Key", server.getServerIp(), "RemoteService对象参数不全.");
            LogUtil.printResult("queryAllGroup4Key", server.getServerIp(), "由于RemoteService对象参数不全,集合为空");
            return null;
        }
        List<Group> list = null;
        log.info("query mode ssh");
        CommandQuery cmdQuery = CommandQuery.getInstance(server
                .getServerIp().trim(), server.getPort(), server
                .getLoginName().trim(), server.getKeyPwd(), server
                .getKeyUrl());
        if (server.openPage()) {
            log.info("query mode ssh for page");
            list = cmdQuery.queryAllGroup4Key(server);
        } else {
            log.info("query mode ssh no page!");
            list = cmdQuery.queryAllGroup4Key();
        }
        if (list == null) {
            list = new ArrayList<Group>();
        }
        LogUtil.printResult("queryAllGroup", server.getServerIp(), "查询集合大小：" + list.size());
        log.info("end query resource group!");
        return list;
    }

    @Override
    public List<Group> queryGroupByNo4Key(RemoteService server, String accountNo) {
        LogUtil.printTermParamMsg("ResourceProcessor", "queryGroupByNo4Key", "accountNo", accountNo);
        if (!printMsg4Key(server, "queryGroupByNo")) {
            LogUtil.printMsg("ResourceProcessor", "queryGroupByNo4Key", server.getServerIp(), "RemoteService对象参数不全.");
            LogUtil.printResult("queryGroupByNo4Key", server.getServerIp(), "由于RemoteService对象参数不全,集合为空");
            return null;
        } else if (StringUtil.isNullOrBlank(accountNo)) {
            LogUtil.printMsg("ResourceProcessor", "queryGroupByNo", server.getServerIp(), "查询参数accountNo为空.");
            LogUtil.printResult("queryGroupByNo4Key", server.getServerIp(), "由于查询参数accountNo,集合为空");
            return null;
        }
        List<Group> list = null;
        CommandQuery cmdQuery = CommandQuery.getInstance(server
                .getServerIp().trim(), server.getPort(), server
                .getLoginName().trim(), server.getKeyPwd(), server
                .getKeyUrl());
        try {
            list = cmdQuery.queryGroupByNo4Key(accountNo.trim());
        } catch (Exception e) {
            list = null;
        }
        if (list == null) {
            list = new ArrayList<Group>();
        }
        LogUtil.printResult("queryGroupByNo", server.getServerIp(), "查询集合大小：" + list.size());
        return list;
    }

    @Override
    public String startAccount4Key(RemoteService server, String accountNo, String param) {
        LogUtil.printTermParamMsg("ResourceProcessor", "startAccount4Key",
                "accountNo", accountNo);
        if (!printMsg4Key(server, "startAccount4Key")) {
            LogUtil.printMsg("ResourceProcessor", "startAccount4Key", server
                    .getServerIp(), "RemoteService对象参数不全.");
            LogUtil.printResult("startAccount4Key", server.getServerIp(),
                    "由于RemoteService对象参数不全,返回Invalid Parameter");
            return "Invalid parameter:RemoteServer Parameters incomplete";
        }
        if (StringUtil.isNullOrBlank(accountNo)) {
            LogUtil.printMsg("ResourceProcessor", "startAccount4Key", server
                    .getServerIp(), "恢复条件accountNo为空.");
            LogUtil.printResult("startAccount4Key", server.getServerIp(),
                    "由于恢复条件accountNo为空,返回Invalid Parameter");
            return "Invalid parameter:account's No Parameters incomplete";
        }
        try {
            CommandQuery cmdQuery = CommandQuery.getInstance(server
                    .getServerIp().trim(), server.getPort(), server
                    .getLoginName().trim(), server.getKeyPwd(), server
                    .getKeyUrl());
            // passwd -u test445
            //Unlocking password for user test445.
            //passwd: Success.
            //[root@localhost ~]# passwd -S test445
            //test445 PS 2015-09-01 0 99999 7 -1 (Password set, MD5 crypt.)

            this.rs = cmdQuery.restoreUser(accountNo.trim());
            if (null != rs && !"".equals(rs)) {
                if ((rs.contains("Unlocking password for user " + accountNo) && rs.contains("passwd: Success")) ||
                        rs.toLowerCase().contains("password changed")) {
                    this.rs = "SUCCESS";
                }
            }
        } catch (Exception e) {
            LogUtil.printMsg("PartitionProcessor", "startAccount", server
                    .getServerIp(), "恢复帐号" + accountNo + "发生异常:" + e);
            this.rs = e.getLocalizedMessage();
        }
        LogUtil.printResult("startAccount", server.getServerIp(), "恢复帐号"
                + accountNo + ",返回结果" + this.rs);
        if (!StringUtil.isEmptyOrNullStr(rs)) {
            rs = rs.replaceAll("[\\t\\n\\r]", "");
            if (rs.contains("'")) {
                rs = rs.replaceAll("'", "");
            }
            if (rs.contains("`")) {
                rs = rs.replaceAll("`", "");
            }
        }
        return this.rs;
    }

    @Override
    public String stopAccount4Key(RemoteService server, String accountNo) {
        LogUtil.printTermParamMsg("ResourceProcessor", "stopAccount4Key",
                "accountNo", accountNo);
        if (!printMsg4Key(server, "stopAccount4Key")) {
            LogUtil.printMsg("ResourceProcessor", "stopAccount4Key", server
                    .getServerIp(), "RemoteService对象参数不全.");
            LogUtil.printResult("stopAccount4Key", server.getServerIp(),
                    "由于RemoteService对象参数不全,返回Invalid Parameter");
            return "Invalid parameter:RemoteServer Parameters incomplete";
        }
        if (StringUtil.isNullOrBlank(accountNo)) {
            LogUtil.printMsg("ResourceProcessor", "stopAccount4Key", server
                    .getServerIp(), "冻结条件accountNo为空.");
            LogUtil.printResult("stopAccount4Key", server.getServerIp(),
                    "由于冻结条件accountNo为空,返回Invalid Parameter");
            return "Invalid parameter:account's No Parameters incomplete";
        }
        try {
            CommandQuery cmdQuery = CommandQuery.getInstance(server
                    .getServerIp().trim(), server.getPort(), server
                    .getLoginName().trim(), server.getKeyPwd(), server
                    .getKeyUrl());
            //]# passwd -l test445
            //Locking password for user test445.
            //passwd: Success
            this.rs = cmdQuery.suppendUser(accountNo.trim());
            if (null != rs && !"".equals(rs)) {
                if ((rs.contains("Locking password for user " + accountNo) && rs.contains("passwd: Success")) ||
                        rs.toLowerCase().contains("password changed")) {
                    this.rs = "SUCCESS";
                }
            }
        } catch (Exception e) {
            LogUtil.printMsg("ResourceProcessor", "stopAccount", server
                    .getServerIp(), "冻结帐号" + accountNo + "发生异常:" + e);
            this.rs = e.getLocalizedMessage();
        }
        LogUtil.printResult("stopAccount", server.getServerIp(), "冻结帐号"
                + accountNo + ",返回结果" + this.rs);
        if (!StringUtil.isEmptyOrNullStr(rs)) {
            rs = rs.replaceAll("[\\t\\n\\r]", "");
            if (rs.contains("'")) {
                rs = rs.replaceAll("'", "");
            }
            if (rs.contains("`")) {
                rs = rs.replaceAll("`", "");
            }
        }
        return this.rs;
    }

    @Override
    public boolean testConnect4Key(RemoteService server) {
        if (!printMsg4Key(server, "testConnect4Key")) {
            LogUtil.printMsg("ResourceProcessor", "testConnect4Key", server
                    .getServerIp(), "RemoteService对象参数不全.");
            LogUtil.printResult("testConnect4Key", server.getServerIp(),
                    "由于RemoteService对象参数不全,返回false");
            return false;
        }

        Connection conn = null;
        boolean isAuthenticated = false;
        try {
            conn = new Connection(server.getServerIp(), server.getPort());

            conn.connect();

            if ((server.getKeyPwd() == null) || ("".equals(server.getKeyPwd()))) {
                log.info("Trying to auth partition" + server.getServerIp()
                        + " by private key without password encoded......");
                isAuthenticated = conn.authenticateWithPublicKey(server
                        .getLoginName(), new File(server.getKeyUrl()), null);
            } else {
                log.info("Trying to auth partition" + server.getServerIp()
                        + " by private key with password encoded......");
                isAuthenticated = conn.authenticateWithPublicKey(server
                        .getLoginName(), new File(server.getKeyUrl()), server
                        .getKeyPwd());
            }
            return isAuthenticated;
        } catch (Exception e) {
            e.printStackTrace(System.err);
            log.error("Connect or Auth for remote resource by private key failed, close connection. The exception is " + e.getMessage());
            return false;
        } finally {
            if (conn != null) {
                conn.close();
            }
        }
    }

}

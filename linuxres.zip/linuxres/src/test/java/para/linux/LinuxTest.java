package para.linux;

import org.junit.Test;
import para.account.Interface.IResourceProcessor;
import para.account.bean.RemoteService;
import para.linux.Impl.ResourceProcessor;
import para.linux.util.CommandStatement;
import para.linux.util.SshConnection;

/**
 * @author 廖水生
 * @date 2020/9/15 11:39
 * @desc
 */
public class LinuxTest {
    IResourceProcessor obj = new ResourceProcessor();

    @Test
    public void testCommand() {

//        SshConnection ssh = new SshConnection("139.219.13.40", 22, "paraosc", "Parav1ew@2020");
        SshConnection ssh = new SshConnection("39.100.198.12", 22, "juanjuan", "Parav1ew");
        try {
            CommandStatement stat = ssh.createCommandInteractive();
            String ret = stat.execCommand2("echo 'Parav1ew@2020' | sudo -S ls &>/dev/null && echo 'shui1:124' | sudo chpasswd");
//            String ret = stat.execCommand2("echo 'Parav1ew' | sudo -S ls&>/dev/null && echo 'hello' && sudo echo");
//            String ret = stat.execCommand2("echo 'Parav1ew' | sudo -S ls &>/dev/null && sudo useradd shui1 && echo 'shui1:123' | sudo chpasswd");

            System.out.println(ret);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Test
    public void test2() {
        RemoteService server = new RemoteService();
        server.setConnType("ssh");
        server.setServerIp("192.168.1.111");
        server.setLoginName("xiechengqi");
        server.setLoginPwd("Parav1ew");
        server.setPort(22);
        server.setSudo(false);

        System.out.println(obj.testConnect(server));
    }


}
